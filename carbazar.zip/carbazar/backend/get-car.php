<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $conn = getDBConnection();
    
    // Get query parameters for filtering
    $brand = $_GET['brand'] ?? '';
    $min_price = $_GET['min_price'] ?? 0;
    $max_price = $_GET['max_price'] ?? 9999999;
    $fuel_type = $_GET['fuel_type'] ?? '';
    $transmission = $_GET['transmission'] ?? '';
    
    // Build query with filters
    $query = "
        SELECT c.*, 
               (SELECT image_path FROM car_images WHERE car_id = c.id AND is_primary = TRUE LIMIT 1) as primary_image
        FROM cars c 
        WHERE c.status = 'approved' 
        AND c.expected_price BETWEEN ? AND ?
    ";
    
    $params = [$min_price, $max_price];
    $types = "ii";
    
    if (!empty($brand)) {
        $query .= " AND c.brand = ?";
        $params[] = $brand;
        $types .= "s";
    }
    
    if (!empty($fuel_type)) {
        $query .= " AND c.fuel_type = ?";
        $params[] = $fuel_type;
        $types .= "s";
    }
    
    if (!empty($transmission)) {
        $query .= " AND c.transmission = ?";
        $params[] = $transmission;
        $types .= "s";
    }
    
    $query .= " ORDER BY c.created_at DESC LIMIT 50";
    
    $stmt = $conn->prepare($query);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $cars = [];
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'cars' => $cars,
        'count' => count($cars)
    ]);
    
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>