<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Extract car data
    $brand = $input['brand'] ?? '';
    $model = $input['model'] ?? '';
    $year = $input['year'] ?? '';
    $variant = $input['variant'] ?? '';
    $fuel_type = $input['fuelType'] ?? '';
    $transmission = $input['transmission'] ?? '';
    $mileage = $input['mileage'] ?? '';
    $owners = $input['owners'] ?? 1;
    $expected_price = $input['expectedPrice'] ?? '';
    $negotiable = $input['negotiable'] ?? 'yes';
    $description = $input['description'] ?? '';
    $seller_name = $input['sellerName'] ?? '';
    $seller_email = $input['sellerEmail'] ?? '';
    $seller_phone = $input['sellerPhone'] ?? '';
    $seller_city = $input['sellerCity'] ?? '';
    $user_id = $input['userId'] ?? null;
    
    // Validate required fields
    $required_fields = [
        'brand', 'model', 'year', 'fuel_type', 'transmission', 
        'mileage', 'expected_price', 'seller_name', 'seller_email', 
        'seller_phone', 'seller_city'
    ];
    
    foreach ($required_fields as $field) {
        if (empty($$field)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "Field $field is required"]);
            exit;
        }
    }
    
    $conn = getDBConnection();
    
    // Insert car listing
    $stmt = $conn->prepare("
        INSERT INTO cars (
            user_id, brand, model, year, variant, fuel_type, transmission, 
            mileage, owners, expected_price, negotiable, description,
            seller_name, seller_email, seller_phone, seller_city
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
        "ississsiisdsssss",
        $user_id, $brand, $model, $year, $variant, $fuel_type, $transmission,
        $mileage, $owners, $expected_price, $negotiable, $description,
        $seller_name, $seller_email, $seller_phone, $seller_city
    );
    
    if ($stmt->execute()) {
        $car_id = $stmt->insert_id;
        
        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Car listing created successfully',
            'car_id' => $car_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create car listing']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>