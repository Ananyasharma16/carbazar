<?php
// Test MongoDB connection
header('Content-Type: application/json');

echo "<h2>MongoDB Connection Test</h2>";

// Check if MongoDB extension is loaded
if (extension_loaded('mongodb')) {
    echo "<p style='color: green;'>✓ MongoDB PHP extension is loaded</p>";
} else {
    echo "<p style='color: red;'>✗ MongoDB PHP extension is NOT loaded</p>";
    echo "<p>Install MongoDB PHP extension: <code>composer require mongodb/mongodb</code></p>";
}

// Check if MongoDB service is running
try {
    $context = stream_context_create([
        "http" => [
            "timeout" => 1
        ]
    ]);
    
    $connection = @fsockopen('localhost', 27017, $errno, $errstr, 1);
    if ($connection) {
        echo "<p style='color: green;'>✓ MongoDB service is running on port 27017</p>";
        fclose($connection);
    } else {
        echo "<p style='color: red;'>✗ MongoDB service is NOT running on port 27017</p>";
        echo "<p>Start MongoDB service: <code>mongod</code></p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Cannot connect to MongoDB: " . $e->getMessage() . "</p>";
}

// Test basic connection
try {
    if (class_exists('MongoDB\Client')) {
        $client = new MongoDB\Client("mongodb://localhost:27017");
        $database = $client->carbazar;
        $collection = $database->users;
        
        // Try to ping the database
        $result = $client->selectDatabase('admin')->command(['ping' => 1]);
        echo "<p style='color: green;'>✓ MongoDB connection successful</p>";
        
        // Test data insertion
        $testDoc = ['test' => 'data', 'timestamp' => new MongoDB\BSON\UTCDateTime()];
        $insertResult = $collection->insertOne($testDoc);
        
        if ($insertResult->getInsertedCount() === 1) {
            echo "<p style='color: green;'>✓ Data insertion test successful</p>";
            
            // Clean up test data
            $collection->deleteOne(['_id' => $insertResult->getInsertedId()]);
            echo "<p style='color: blue;'>ℹ Test data cleaned up</p>";
        }
        
    } else {
        echo "<p style='color: red;'>✗ MongoDB\\Client class not found</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ MongoDB connection failed: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>If MongoDB extension is missing: <code>composer require mongodb/mongodb</code></li>";
echo "<li>If MongoDB service is not running: Start MongoDB service</li>";
echo "<li>If connection works: <a href='init_mongodb.php'>Initialize Database</a></li>";
echo "</ol>";
?>