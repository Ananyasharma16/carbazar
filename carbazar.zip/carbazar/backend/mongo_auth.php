<?php
require_once 'mongodb_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    
    // Validate input
    if (empty($email) || empty($password)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }
    
    try {
        $mongo = new MongoDBConnection();
        $users = $mongo->getCollection('users');
        
        // Fetch user by email from MongoDB
        $user = $users->findOne(['email' => $email]);
        
        if (!$user) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
            exit;
        }
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Update last login timestamp
            $users->updateOne(
                ['_id' => $user['_id']],
                ['$set' => ['last_login' => new MongoDB\BSON\UTCDateTime()]]
            );
            
            // Return user data (excluding password)
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Login successful - Data fetched from MongoDB',
                'user' => [
                    'id' => (string)$user['_id'],
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'avatar' => $user['avatar'] ?? 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
                    'created_at' => $user['created_at']->toDateTime()->format('Y-m-d H:i:s'),
                    'last_login' => 'Just now'
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database connection error']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>