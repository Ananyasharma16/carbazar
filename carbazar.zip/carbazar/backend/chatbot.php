<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $user_message = $input['message'] ?? '';
    
    if (empty($user_message)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Message is required']);
        exit;
    }
    
    $response = generateChatbotResponse($user_message);
    
    echo json_encode([
        'success' => true,
        'response' => $response
    ]);
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

function generateChatbotResponse($user_message) {
    $message = strtolower(trim($user_message));
    
    // Car brands knowledge base
    $brand_responses = [
        'mercedes' => "Mercedes-Benz offers luxury vehicles known for comfort and technology. Popular models: S-Class, E-Class, C-Class, GLE. Would you like details on a specific model?",
        'bmw' => "BMW is renowned for sporty driving dynamics. Key models: 3 Series, 5 Series, 7 Series, X3, X5. Also check out their iSeries electric vehicles.",
        'audi' => "Audi combines luxury with Quattro all-wheel drive. Popular: A4, A6, A8, Q5, Q7. Their e-tron lineup leads in electric mobility.",
        'toyota' => "Toyota is known for reliability and value. Popular: Camry, Corolla, RAV4, Highlander. Their hybrid technology is industry-leading.",
        'honda' => "Honda offers reliable, fuel-efficient vehicles. Key models: Civic, Accord, CR-V, Pilot. Known for excellent resale value.",
        'ford' => "Ford provides durable American vehicles. Popular: F-150, Mustang, Explorer, Escape. Their truck lineup is particularly strong.",
        'tesla' => "Tesla leads in electric vehicles. Models: Model S, 3, X, Y, Cybertruck. Known for autopilot and over-the-air updates.",
        'porsche' => "Porsche delivers exceptional performance and luxury. Key models: 911, Cayenne, Panamera, Macan. German engineering at its finest."
    ];
    
    // Check for brand mentions
    foreach ($brand_responses as $brand => $response) {
        if (strpos($message, $brand) !== false) {
            return $response;
        }
    }
    
    // Feature-based responses
    if (strpos($message, 'fuel') !== false || strpos($message, 'mileage') !== false) {
        return "Fuel efficiency varies: Hybrids (45-60 MPG), EVs (200-400 mile range), Petrol cars (20-40 MPG). Need specific data for a car?";
    }
    
    if (strpos($message, 'price') !== false || strpos($message, 'cost') !== false) {
        return "Car prices range from $20,000 for economy to $100,000+ for luxury. Luxury brands start around $40,000. Looking for a specific price range?";
    }
    
    if (strpos($message, 'electric') !== false || strpos($message, 'ev') !== false) {
        return "Electric vehicles offer lower running costs and zero emissions. Popular EVs: Tesla Model 3, Ford Mustang Mach-E, Hyundai Ioniq 5. Charging typically takes 30 mins (fast) to 8 hours (home).";
    }
    
    if (strpos($message, 'maintenance') !== false) {
        return "Maintenance costs: European luxury ($800-1200/year), Japanese ($400-600/year), Electric ($300-500/year). Regular maintenance extends vehicle life.";
    }
    
    if (strpos($message, 'buy') !== false) {
        return "When buying, consider: budget, fuel type, size needs, features, and resale value. Test drive multiple options and check vehicle history reports.";
    }
    
    if (strpos($message, 'sell') !== false) {
        return "To sell effectively: clean thoroughly, take quality photos, gather maintenance records, price competitively, and be transparent about condition.";
    }
    
    if (strpos($message, 'best') !== false && strpos($message, 'car') !== false) {
        return "Best car depends on needs: Luxury - Mercedes S-Class, Reliability - Toyota, Performance - Porsche, Electric - Tesla, Value - Honda. What's your priority?";
    }
    
    // General responses
    $general_responses = [
        "I specialize in car information! Ask me about brands, models, features, pricing, or buying/selling advice.",
        "As your car expert, I can help compare vehicles, explain features, or provide market insights. What would you like to know?",
        "I'm here to assist with all car-related questions. Feel free to ask about specific models, technologies, or car shopping tips.",
        "Need car advice? I can help with brand comparisons, feature explanations, pricing information, and more. What's on your mind?"
    ];
    
    return $general_responses[array_rand($general_responses)];
}
?>