<?php
require_once 'mongodb_config.php';

$mongo = new MongoDBConnection();
$cars = $mongo->getCollection('cars');

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        // Get all cars or specific car
        $carId = $_GET['id'] ?? null;
        
        if ($carId) {
            try {
                $car = $cars->findOne(['_id' => new MongoDB\BSON\ObjectId($carId)]);
                if ($car) {
                    $car['id'] = (string)$car['_id'];
                    unset($car['_id']);
                    echo json_encode(['success' => true, 'car' => $car]);
                } else {
                    http_response_code(404);
                    echo json_encode(['success' => false, 'message' => 'Car not found']);
                }
            } catch (Exception $e) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Invalid car ID']);
            }
        } else {
            // Get all cars
            $allCars = $cars->find()->toArray();
            foreach ($allCars as &$car) {
                $car['id'] = (string)$car['_id'];
                unset($car['_id']);
            }
            echo json_encode(['success' => true, 'cars' => $allCars]);
        }
        break;
        
    case 'POST':
        // Add new car
        $input = json_decode(file_get_contents('php://input'), true);
        
        $required = ['brand', 'model', 'year', 'price'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => "Field $field is required"]);
                exit;
            }
        }
        
        $carDocument = [
            'brand' => $input['brand'],
            'model' => $input['model'],
            'year' => (int)$input['year'],
            'price' => (float)$input['price'],
            'mileage' => $input['mileage'] ?? null,
            'fuel_type' => $input['fuel_type'] ?? null,
            'transmission' => $input['transmission'] ?? null,
            'description' => $input['description'] ?? null,
            'image_url' => $input['image_url'] ?? null,
            'status' => 'available',
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ];
        
        try {
            $result = $cars->insertOne($carDocument);
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Car added successfully',
                'car_id' => (string)$result->getInsertedId()
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Failed to add car']);
        }
        break;
        
    case 'PUT':
        // Update car
        $input = json_decode(file_get_contents('php://input'), true);
        $carId = $input['id'] ?? null;
        
        if (!$carId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Car ID is required']);
            exit;
        }
        
        try {
            unset($input['id']);
            $input['updated_at'] = new MongoDB\BSON\UTCDateTime();
            
            $result = $cars->updateOne(
                ['_id' => new MongoDB\BSON\ObjectId($carId)],
                ['$set' => $input]
            );
            
            if ($result->getModifiedCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Car updated successfully']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Car not found']);
            }
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid car ID']);
        }
        break;
        
    case 'DELETE':
        // Delete car
        $input = json_decode(file_get_contents('php://input'), true);
        $carId = $input['id'] ?? null;
        
        if (!$carId) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Car ID is required']);
            exit;
        }
        
        try {
            $result = $cars->deleteOne(['_id' => new MongoDB\BSON\ObjectId($carId)]);
            
            if ($result->getDeletedCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Car deleted successfully']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Car not found']);
            }
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid car ID']);
        }
        break;
        
    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>