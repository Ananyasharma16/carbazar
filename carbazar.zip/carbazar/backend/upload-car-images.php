<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate car_id
if (!isset($_POST['car_id']) || empty($_POST['car_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Car ID is required']);
    exit;
}

$car_id = intval($_POST['car_id']);

// Validate that car exists
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT id FROM cars WHERE id = ?");
$stmt->bind_param("i", $car_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Car not found']);
    exit;
}

// Create uploads directory if it doesn't exist
$uploadDir = '../uploads/cars/' . $car_id . '/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Allowed image extensions and MIME types
$allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
$maxFileSize = 5 * 1024 * 1024; // 5MB

$uploadedImages = [];
$errors = [];

// Handle file uploads
if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
    $fileCount = count($_FILES['images']['name']);
    
    for ($i = 0; $i < $fileCount; $i++) {
        $fileName = $_FILES['images']['name'][$i];
        $fileTmpName = $_FILES['images']['tmp_name'][$i];
        $fileSize = $_FILES['images']['size'][$i];
        $fileError = $_FILES['images']['error'][$i];
        $fileType = $_FILES['images']['type'][$i];
        
        // Check for upload errors
        if ($fileError !== UPLOAD_ERR_OK) {
            $errors[] = "Error uploading $fileName: Upload error code $fileError";
            continue;
        }
        
        // Validate file size
        if ($fileSize > $maxFileSize) {
            $errors[] = "$fileName: File size exceeds 5MB limit";
            continue;
        }
        
        // Validate MIME type
        if (!in_array($fileType, $allowedMimeTypes)) {
            $errors[] = "$fileName: Invalid file type. Only JPG, PNG, and WebP are allowed";
            continue;
        }
        
        // Get file extension
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        // Validate extension
        if (!in_array($fileExtension, $allowedExtensions)) {
            $errors[] = "$fileName: Invalid file extension";
            continue;
        }
        
        // Generate unique filename
        $newFileName = 'car_' . $car_id . '_' . uniqid() . '.' . $fileExtension;
        $destination = $uploadDir . $newFileName;
        
        // Move uploaded file
        if (move_uploaded_file($fileTmpName, $destination)) {
            // Store relative path in database
            $relativePath = 'uploads/cars/' . $car_id . '/' . $newFileName;
            
            // Determine if this should be the primary image (first image uploaded)
            $isPrimary = ($i === 0 && empty($uploadedImages)) ? 1 : 0;
            
            // Insert into database
            $stmt = $conn->prepare("INSERT INTO car_images (car_id, image_path, is_primary) VALUES (?, ?, ?)");
            $stmt->bind_param("isi", $car_id, $relativePath, $isPrimary);
            
            if ($stmt->execute()) {
                $uploadedImages[] = [
                    'id' => $stmt->insert_id,
                    'path' => $relativePath,
                    'is_primary' => $isPrimary
                ];
            } else {
                $errors[] = "$fileName: Failed to save to database";
                // Delete the uploaded file if database insert fails
                unlink($destination);
            }
        } else {
            $errors[] = "$fileName: Failed to move uploaded file";
        }
    }
}

$stmt->close();
$conn->close();

// Prepare response
$response = [
    'success' => !empty($uploadedImages),
    'uploaded_count' => count($uploadedImages),
    'images' => $uploadedImages
];

if (!empty($errors)) {
    $response['errors'] = $errors;
    $response['message'] = 'Some images failed to upload';
} else if (!empty($uploadedImages)) {
    $response['message'] = 'Images uploaded successfully';
} else {
    $response['message'] = 'No images were uploaded';
}

echo json_encode($response);
?>
