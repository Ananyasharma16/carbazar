<?php
// MongoDB Configuration for CarBazar

class MongoDBConnection {
    private $client;
    private $database;
    private $useFileStorage = false;
    private $dataDir;
    
    public function __construct() {
        $this->dataDir = __DIR__ . '/data';
        
        try {
            // Try MongoDB connection
            if (class_exists('MongoDB\Client')) {
                $this->client = new MongoDB\Client("mongodb://localhost:27017");
                $this->database = $this->client->carbazar;
                // Test connection
                $this->database->listCollections();
            } else {
                throw new Exception('MongoDB Client not available');
            }
        } catch (Exception $e) {
            // Fallback to file-based storage
            $this->useFileStorage = true;
            if (!is_dir($this->dataDir)) {
                mkdir($this->dataDir, 0777, true);
            }
        }
    }
    
    public function getCollection($collectionName) {
        if ($this->useFileStorage) {
            return new FileCollection($collectionName, $this->dataDir);
        }
        return $this->database->selectCollection($collectionName);
    }
    
    public function getDatabase() {
        return $this->database;
    }
}

// Simple file-based collection for fallback
class FileCollection {
    private $collectionName;
    private $filePath;
    
    public function __construct($collectionName, $dataDir) {
        $this->collectionName = $collectionName;
        $this->filePath = $dataDir . '/' . $collectionName . '.json';
        
        if (!file_exists($this->filePath)) {
            file_put_contents($this->filePath, json_encode([]));
        }
    }
    
    public function findOne($filter) {
        $data = json_decode(file_get_contents($this->filePath), true);
        foreach ($data as $doc) {
            $match = true;
            foreach ($filter as $key => $value) {
                if (!isset($doc[$key]) || $doc[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) return $doc;
        }
        return null;
    }
    
    public function insertOne($document) {
        $data = json_decode(file_get_contents($this->filePath), true);
        $document['_id'] = uniqid();
        $data[] = $document;
        file_put_contents($this->filePath, json_encode($data));
        return (object)['getInsertedCount' => function() { return 1; }, 'getInsertedId' => function() use ($document) { return $document['_id']; }];
    }
    
    public function updateOne($filter, $update) {
        $data = json_decode(file_get_contents($this->filePath), true);
        foreach ($data as &$doc) {
            $match = true;
            foreach ($filter as $key => $value) {
                if (!isset($doc[$key]) || $doc[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) {
                foreach ($update['$set'] as $key => $value) {
                    $doc[$key] = $value;
                }
                break;
            }
        }
        file_put_contents($this->filePath, json_encode($data));
        return true;
    }
    
    public function createIndex($keys, $options = []) {
        // No-op for file storage
        return true;
    }
}

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
?>