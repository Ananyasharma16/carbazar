<?php
// Simple MongoDB setup and test script
require_once 'mongodb_config.php';

try {
    $mongo = new MongoDBConnection();
    $users = $mongo->getCollection('users');
    
    // Create index on email for faster lookups
    $users->createIndex(['email' => 1], ['unique' => true]);
    
    echo json_encode([
        'success' => true,
        'message' => 'MongoDB setup completed successfully',
        'database' => 'carbazar',
        'collection' => 'users'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'MongoDB setup failed: ' . $e->getMessage()
    ]);
}
?>