<?php
require_once 'mongodb_config.php';

// Initialize MongoDB with sample data
try {
    $mongo = new MongoDBConnection();
    
    // Create users collection with sample data
    $users = $mongo->getCollection('users');
    $users->insertOne([
        'name' => 'Ananya Sharma',
        'email' => 'ananya.sharma@email.com',
        'password' => password_hash('password', PASSWORD_DEFAULT),
        'avatar' => 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
        'created_at' => new MongoDB\BSON\UTCDateTime(),
        'last_login' => null
    ]);
    
    // Create cars collection with sample data
    $cars = $mongo->getCollection('cars');
    $sampleCars = [
        [
            'brand' => 'Mercedes-Benz',
            'model' => 'S-Class',
            'year' => 2023,
            'price' => 95000.00,
            'mileage' => 15000,
            'fuel_type' => 'Petrol',
            'transmission' => 'Automatic',
            'description' => 'Luxury sedan with premium features',
            'image_url' => 'images/cars/mercedes-s-class.jpg',
            'status' => 'available',
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ],
        [
            'brand' => 'BMW',
            'model' => '7 Series',
            'year' => 2022,
            'price' => 87000.00,
            'mileage' => 22000,
            'fuel_type' => 'Petrol',
            'transmission' => 'Automatic',
            'description' => 'Executive luxury car',
            'image_url' => 'images/cars/bmw-7-series.jpg',
            'status' => 'available',
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ],
        [
            'brand' => 'Tesla',
            'model' => 'Model S',
            'year' => 2023,
            'price' => 95000.00,
            'mileage' => 12000,
            'fuel_type' => 'Electric',
            'transmission' => 'Automatic',
            'description' => 'Electric luxury sedan',
            'image_url' => 'images/cars/tesla-model-s.jpg',
            'status' => 'available',
            'created_at' => new MongoDB\BSON\UTCDateTime()
        ]
    ];
    
    $cars->insertMany($sampleCars);
    
    echo json_encode([
        'success' => true,
        'message' => 'MongoDB setup completed successfully',
        'collections' => ['users', 'cars'],
        'sample_data' => [
            'users' => 1,
            'cars' => count($sampleCars)
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Setup failed: ' . $e->getMessage()
    ]);
}
?>