<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }
    
    // Simple user database (simulating MongoDB data)
    $users = [
        [
            'id' => '1',
            'name' => 'Ananya Sharma',
            'email' => 'ananya.sharma@email.com',
            'password' => password_hash('password', PASSWORD_DEFAULT),
            'avatar' => 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
            'created_at' => '2024-01-15 10:30:00'
        ],
        [
            'id' => '2',
            'name' => 'John Doe',
            'email' => 'john.doe@email.com',
            'password' => password_hash('password123', PASSWORD_DEFAULT),
            'avatar' => 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&h=120&fit=crop&crop=face',
            'created_at' => '2024-01-10 14:20:00'
        ]
    ];
    
    // Find user by email
    $user = null;
    foreach ($users as $u) {
        if ($u['email'] === $email) {
            $user = $u;
            break;
        }
    }
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        exit;
    }
    
    // Verify password
    if (password_verify($password, $user['password'])) {
        // Remove password from response
        unset($user['password']);
        
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Login successful - Data fetched from server',
            'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'avatar' => $user['avatar'],
                'created_at' => $user['created_at'],
                'last_login' => 'Just now'
            ]
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>