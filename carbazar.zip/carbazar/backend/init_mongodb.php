<?php
require_once 'mongodb_config.php';

// Initialize MongoDB with test user
try {
    $mongo = new MongoDBConnection();
    $users = $mongo->getCollection('users');
    
    // Check if test user already exists
    $existingUser = $users->findOne(['email' => 'ananya.sharma@email.com']);
    
    if (!$existingUser) {
        // Create test user
        $testUser = [
            'name' => 'Ananya Sharma',
            'email' => 'ananya.sharma@email.com',
            'password' => password_hash('password', PASSWORD_DEFAULT), // password: "password"
            'avatar' => 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
            'created_at' => new MongoDB\BSON\UTCDateTime(),
            'last_login' => null
        ];
        
        $result = $users->insertOne($testUser);
        
        if ($result->getInsertedCount() === 1) {
            echo json_encode([
                'success' => true,
                'message' => 'MongoDB initialized successfully',
                'test_user' => [
                    'email' => 'ananya.sharma@email.com',
                    'password' => 'password',
                    'note' => 'Use these credentials to test login'
                ]
            ]);
        }
    } else {
        echo json_encode([
            'success' => true,
            'message' => 'MongoDB already initialized',
            'test_user' => [
                'email' => 'ananya.sharma@email.com',
                'password' => 'password',
                'note' => 'Use these credentials to test login'
            ]
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'MongoDB initialization failed: ' . $e->getMessage()
    ]);
}
?>