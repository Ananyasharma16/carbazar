<?php
require_once 'mongodb_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $name = $input['name'] ?? '';
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    
    // Validate input
    if (empty($name) || empty($email) || empty($password)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    try {
        $mongo = new MongoDBConnection();
        $users = $mongo->getCollection('users');
        
        // Check if email already exists
        $existingUser = $users->findOne(['email' => $email]);
        if ($existingUser) {
            http_response_code(409);
            echo json_encode(['success' => false, 'message' => 'Email already registered']);
            exit;
        }
        
        // Create new user document
        $userDocument = [
            'name' => $name,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'avatar' => 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
            'created_at' => new MongoDB\BSON\UTCDateTime(),
            'last_login' => null
        ];
        
        // Save to MongoDB
        $result = $users->insertOne($userDocument);
        
        if ($result->getInsertedCount() === 1) {
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'User registered successfully in MongoDB',
                'user' => [
                    'id' => (string)$result->getInsertedId(),
                    'name' => $name,
                    'email' => $email,
                    'avatar' => $userDocument['avatar']
                ]
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Registration failed']);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>