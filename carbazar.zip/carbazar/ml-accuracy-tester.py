from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import random
import math

app = Flask(__name__)
CORS(app)

car_data = None

def load_car_data():
    """Load car data with accuracy tracking"""
    global car_data
    try:
        df = pd.read_csv('cars.csv')
        df.columns = df.columns.str.strip()
        df['Car Brand'] = df['Car Brand'].str.strip()
        
        # Brand price mapping
        brand_prices = {
            'Toyota': 1200000, 'Honda': 1100000, 'Mercedes-Benz': 4500000, 'BMW': 4000000,
            'Audi': 3800000, 'Hyundai': 800000, 'Ford': 900000, 'Chevrolet': 850000,
            'Nissan': 1000000, 'Mazda': 950000, 'Volkswagen': 1300000, 'Lexus': 3500000
        }
        
        # Calculate realistic prices
        prices = []
        for _, row in df.iterrows():
            brand = row['Car Brand']
            year = int(row['Year of Manufacture'])
            base_price = brand_prices.get(brand, 800000)
            age_factor = max(0.2, 1 - (2024 - year) * 0.08)
            price_variation = random.uniform(0.8, 1.2)
            final_price = base_price * age_factor * price_variation
            prices.append(max(200000, int(final_price)))
        
        df['Price'] = prices
        df['Mileage'] = df.apply(lambda row: 
            max(5000, (2024 - row['Year of Manufacture']) * 15000 + random.randint(-20000, 20000)), axis=1)
        
        car_data = df
        print(f"✅ Loaded {len(car_data)} records")
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def predict_price_algorithm(brand, year, mileage):
    """Core price prediction algorithm"""
    if car_data is None:
        load_car_data()
    
    # Find similar cars
    brand_cars = car_data[car_data['Car Brand'] == brand]
    
    if len(brand_cars) > 0:
        avg_price = brand_cars['Price'].mean()
        year_factor = max(0.3, 1 - (2024 - year) * 0.08)
        mileage_factor = max(0.5, 1 - (mileage / 200000) * 0.4)
        predicted_price = avg_price * year_factor * mileage_factor
    else:
        # Fallback
        base_prices = {'Toyota': 1200000, 'BMW': 4000000, 'Mercedes-Benz': 4500000}
        base_price = base_prices.get(brand, 1000000)
        year_factor = max(0.3, 1 - (2024 - year) * 0.08)
        mileage_factor = max(0.5, 1 - (mileage / 200000) * 0.4)
        predicted_price = base_price * year_factor * mileage_factor
    
    return int(predicted_price)

@app.route('/test-accuracy', methods=['POST'])
def test_accuracy():
    """Test prediction accuracy using cross-validation"""
    try:
        if car_data is None:
            load_car_data()
        
        # Take sample for testing
        test_sample = car_data.sample(n=min(100, len(car_data)), random_state=42)
        
        predictions = []
        actual_prices = []
        errors = []
        
        for _, row in test_sample.iterrows():
            brand = row['Car Brand']
            year = int(row['Year of Manufacture'])
            mileage = int(row['Mileage'])
            actual_price = row['Price']
            
            # Predict price
            predicted_price = predict_price_algorithm(brand, year, mileage)
            
            # Calculate error
            error = abs(predicted_price - actual_price)
            error_percentage = (error / actual_price) * 100
            
            predictions.append(predicted_price)
            actual_prices.append(actual_price)
            errors.append(error_percentage)
        
        # Calculate accuracy metrics
        mean_error = np.mean(errors)
        median_error = np.median(errors)
        accuracy = max(0, 100 - mean_error)
        
        # Categorize accuracy
        if accuracy >= 85:
            accuracy_grade = "Excellent"
        elif accuracy >= 75:
            accuracy_grade = "Good"
        elif accuracy >= 65:
            accuracy_grade = "Fair"
        else:
            accuracy_grade = "Needs Improvement"
        
        # Find best and worst predictions
        best_prediction_idx = np.argmin(errors)
        worst_prediction_idx = np.argmax(errors)
        
        return jsonify({
            'success': True,
            'accuracy_metrics': {
                'overall_accuracy': f"{accuracy:.1f}%",
                'accuracy_grade': accuracy_grade,
                'mean_error': f"{mean_error:.1f}%",
                'median_error': f"{median_error:.1f}%",
                'total_tests': len(test_sample)
            },
            'sample_results': {
                'best_prediction': {
                    'brand': test_sample.iloc[best_prediction_idx]['Car Brand'],
                    'year': int(test_sample.iloc[best_prediction_idx]['Year of Manufacture']),
                    'actual': int(actual_prices[best_prediction_idx]),
                    'predicted': int(predictions[best_prediction_idx]),
                    'error': f"{errors[best_prediction_idx]:.1f}%"
                },
                'worst_prediction': {
                    'brand': test_sample.iloc[worst_prediction_idx]['Car Brand'],
                    'year': int(test_sample.iloc[worst_prediction_idx]['Year of Manufacture']),
                    'actual': int(actual_prices[worst_prediction_idx]),
                    'predicted': int(predictions[worst_prediction_idx]),
                    'error': f"{errors[worst_prediction_idx]:.1f}%"
                }
            },
            'recommendations': generate_accuracy_recommendations(accuracy, mean_error)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def generate_accuracy_recommendations(accuracy, mean_error):
    """Generate recommendations to improve accuracy"""
    recommendations = []
    
    if accuracy < 70:
        recommendations.append("Consider adding more features like fuel type, transmission")
        recommendations.append("Increase training data size for better predictions")
    
    if mean_error > 20:
        recommendations.append("Fine-tune depreciation factors for different brands")
        recommendations.append("Add regional price variations")
    
    if accuracy >= 85:
        recommendations.append("Excellent accuracy! Model is production-ready")
        recommendations.append("Consider A/B testing with real users")
    
    return recommendations

@app.route('/brand-accuracy', methods=['POST'])
def brand_accuracy():
    """Test accuracy for specific brand"""
    try:
        data = request.json
        brand = data.get('brand', 'Toyota')
        
        if car_data is None:
            load_car_data()
        
        brand_cars = car_data[car_data['Car Brand'] == brand]
        
        if len(brand_cars) < 5:
            return jsonify({'success': False, 'error': f'Not enough data for {brand}'})
        
        # Test on brand-specific data
        test_cars = brand_cars.sample(n=min(20, len(brand_cars)), random_state=42)
        
        errors = []
        for _, row in test_cars.iterrows():
            actual = row['Price']
            predicted = predict_price_algorithm(brand, int(row['Year of Manufacture']), int(row['Mileage']))
            error = abs(predicted - actual) / actual * 100
            errors.append(error)
        
        brand_accuracy = max(0, 100 - np.mean(errors))
        
        return jsonify({
            'success': True,
            'brand': brand,
            'brand_accuracy': f"{brand_accuracy:.1f}%",
            'mean_error': f"{np.mean(errors):.1f}%",
            'tests_performed': len(test_cars),
            'confidence_level': "High" if brand_accuracy > 80 else "Medium" if brand_accuracy > 65 else "Low"
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/predict-price', methods=['POST'])
def predict_price():
    """Price prediction with accuracy indicators"""
    try:
        data = request.json
        brand = data.get('brand', 'Toyota')
        year = int(data.get('year', 2020))
        mileage = int(data.get('mileage', 50000))
        
        predicted_price = predict_price_algorithm(brand, year, mileage)
        
        # Calculate confidence based on similar cars
        similar_cars = car_data[
            (car_data['Car Brand'] == brand) & 
            (abs(car_data['Year of Manufacture'] - year) <= 3)
        ]
        
        # Confidence calculation
        base_confidence = 60
        data_confidence = min(30, len(similar_cars) * 3)  # More similar cars = higher confidence
        age_confidence = max(0, 10 - abs(2024 - year - 5))  # Sweet spot around 5 years old
        
        total_confidence = min(95, base_confidence + data_confidence + age_confidence)
        
        # Accuracy indicator
        if len(similar_cars) >= 10:
            accuracy_indicator = "High accuracy (10+ similar cars)"
        elif len(similar_cars) >= 5:
            accuracy_indicator = "Good accuracy (5+ similar cars)"
        elif len(similar_cars) >= 2:
            accuracy_indicator = "Moderate accuracy (2+ similar cars)"
        else:
            accuracy_indicator = "Low accuracy (limited data)"
        
        return jsonify({
            'success': True,
            'predicted_price': predicted_price,
            'confidence': int(total_confidence),
            'accuracy_indicator': accuracy_indicator,
            'similar_cars_count': len(similar_cars),
            'price_range': {
                'low': int(predicted_price * 0.9),
                'high': int(predicted_price * 1.1)
            },
            'algorithm': 'Statistical Analysis with Accuracy Tracking'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'data_loaded': car_data is not None,
        'total_records': len(car_data) if car_data is not None else 0,
        'message': 'ML Server with Accuracy Testing'
    })

if __name__ == '__main__':
    print("🚗 Starting ML Server with Accuracy Testing...")
    print("📊 Loading car data...")
    load_car_data()
    print("\n🎯 Accuracy Testing Endpoints:")
    print("   • /test-accuracy - Overall model accuracy")
    print("   • /brand-accuracy - Brand-specific accuracy")
    print("   • /predict-price - Price prediction with confidence")
    print("\n🚀 Server running on http://localhost:5000")
    app.run(debug=True, port=5000)