const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');

const app = express();
const PORT = 3001;

// MongoDB connection
const MONGO_URI = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';

let db;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Connect to MongoDB
MongoClient.connect(MONGO_URI)
  .then(client => {
    console.log('✅ Connected to MongoDB');
    db = client.db(DB_NAME);
  })
  .catch(error => {
    console.log('⚠️ MongoDB not available');
    db = null;
  });

// Login API
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (db) {
      const users = db.collection('users');
      const user = await users.findOne({ email, password });
      
      if (user) {
        res.json({
          success: true,
          message: 'Login successful',
          user: {
            id: user._id,
            name: user.name,
            email: user.email
          }
        });
        return;
      }
    }
    
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Signup API
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    if (db) {
      const users = db.collection('users');
      const existingUser = await users.findOne({ email });
      
      if (existingUser) {
        return res.status(400).json({ success: false, message: 'User already exists' });
      }
      
      const result = await users.insertOne({
        name,
        email,
        password,
        createdAt: new Date()
      });
      
      res.status(201).json({
        success: true,
        message: 'User created successfully',
        userId: result.insertedId
      });
    } else {
      res.status(500).json({ success: false, message: 'Database not available' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Sell car API
app.post('/api/sell-car', async (req, res) => {
  try {
    const { brand, model, year, price, mileage, fuelType, transmission, description, sellerEmail } = req.body;
    
    if (db) {
      const cars = db.collection('cars');
      const result = await cars.insertOne({
        brand,
        model,
        year: parseInt(year),
        price: parseFloat(price),
        mileage: parseInt(mileage),
        fuelType,
        transmission,
        description,
        sellerEmail,
        status: 'available',
        createdAt: new Date()
      });
      
      res.status(201).json({
        success: true,
        message: 'Car listed successfully',
        carId: result.insertedId
      });
    } else {
      res.status(500).json({ success: false, message: 'Database not available' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get cars (hardcoded for marketplace)
app.get('/api/cars', (req, res) => {
  const cars = [
    {
      id: '1',
      brand: 'Mercedes-Benz',
      model: 'S-Class',
      year: 2023,
      price: 95000,
      mileage: 15000,
      fuelType: 'Petrol',
      transmission: 'Automatic',
      description: 'Luxury sedan',
      imageUrl: 'images/cars/mercedes-s-class.jpg'
    },
    {
      id: '2',
      brand: 'BMW',
      model: '7 Series',
      year: 2022,
      price: 87000,
      mileage: 22000,
      fuelType: 'Petrol',
      transmission: 'Automatic',
      description: 'Executive luxury car',
      imageUrl: 'images/cars/bmw-7-series.jpg'
    }
  ];
  
  res.json({ success: true, cars });
});

app.listen(PORT, () => {
  console.log(`🚀 CarBazar server running on http://localhost:${PORT}`);
});