// Enhanced Sell Car with Backend Integration

// Store uploaded images temporarily
let uploadedCarImages = [];

// Submit car listing to backend
async function submitCarListing() {
    if (!validateForm()) {
        showMessage('Please fill in all required fields', 'error');
        return;
    }

    const form = document.getElementById('sellCarForm');
    const formData = new FormData(form);
    
    // Add uploaded images to formData
    uploadedCarImages.forEach((file, index) => {
        formData.append('images', file);
    });
    
    // Get user ID if logged in
    const user = localStorage.getItem('userData');
    if (user) {
        const userData = JSON.parse(user);
        formData.append('userId', userData.id || userData._id);
    }

    const submitBtn = document.querySelector('#step4 button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Submitting...';
    submitBtn.disabled = true;

    try {
        // Submit car details with images
        const carResponse = await fetch('http://localhost:3000/api/cars', {
            method: 'POST',
            body: formData // Send FormData directly (don't set Content-Type header)
        });

        const carResult = await carResponse.json();

        if (carResult.success) {
            showMessage('Car listing submitted successfully!', 'success');
            
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 2000);
        } else {
            showMessage(carResult.message || 'Submission failed', 'error');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Submission error:', error);
        showMessage('Network error. Please try again.', 'error');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Load cars from backend
async function loadFeaturedCars() {
    const carsGrid = document.getElementById('featured-cars-grid');
    
    if (!carsGrid) return;
    
    try {
        const response = await fetch('http://localhost:3000/api/cars');
        const data = await response.json();

        if (data.success) {
            displayCars(data.cars, carsGrid);
        } else {
            carsGrid.innerHTML = '<p>Error loading cars. Please try again later.</p>';
        }
    } catch (error) {
        carsGrid.innerHTML = '<p>Network error. Please check your connection.</p>';
    }
}

function displayCars(cars, container) {
    container.innerHTML = '';
    
    if (cars.length === 0) {
        container.innerHTML = '<p>No cars available at the moment.</p>';
        return;
    }
    
    cars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        carCard.innerHTML = `
            <div class="car-image">
                <img src="${car.primary_image || 'images/cars/default-car.jpg'}" alt="${car.brand} ${car.model}">
            </div>
            <div class="car-info">
                <h3 class="car-title">${car.brand} ${car.model} ${car.year}</h3>
                <div class="car-price">$${parseInt(car.expected_price).toLocaleString()}</div>
                <div class="car-features">
                    <span><i class="fas fa-calendar-alt"></i> ${car.year}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${car.mileage} km</span>
                    <span><i class="fas fa-gas-pump"></i> ${car.fuel_type}</span>
                </div>
                <a href="car-details.html?id=${car.id}" class="btn-primary">View Details</a>
            </div>
        `;
        container.appendChild(carCard);
    });
}

// Image Upload Handling
function initImageUpload() {
    const photoInput = document.getElementById('carPhotos');
    const photoPreview = document.getElementById('photoPreview');
    
    if (photoInput) {
        photoInput.addEventListener('change', handleImageSelection);
    }
    
    // Enable drag and drop
    const uploadArea = document.getElementById('photoUpload');
    if (uploadArea) {
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#007bff';
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.style.borderColor = '#ddd';
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#ddd';
            
            const files = Array.from(e.dataTransfer.files).filter(file => 
                file.type.startsWith('image/')
            );
            
            if (files.length > 0) {
                addImagesToUpload(files);
            }
        });
    }
}

function handleImageSelection(event) {
    const files = Array.from(event.target.files);
    addImagesToUpload(files);
}

function addImagesToUpload(files) {
    const photoPreview = document.getElementById('photoPreview');
    const maxImages = 10;
    
    // Check if we exceed max images
    if (uploadedCarImages.length + files.length > maxImages) {
        showMessage(`You can only upload up to ${maxImages} images`, 'error');
        return;
    }
    
    files.forEach(file => {
        // Validate file type
        if (!file.type.startsWith('image/')) {
            showMessage(`${file.name} is not a valid image file`, 'error');
            return;
        }
        
        // Validate file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            showMessage(`${file.name} exceeds 5MB size limit`, 'error');
            return;
        }
        
        uploadedCarImages.push(file);
        
        // Create preview
        const reader = new FileReader();
        reader.onload = (e) => {
            const previewItem = document.createElement('div');
            previewItem.className = 'preview-item';
            previewItem.innerHTML = `
                <img src="${e.target.result}" alt="Preview">
                <button type="button" class="remove-image" onclick="removeImage(${uploadedCarImages.length - 1})">
                    <i class="fas fa-times"></i>
                </button>
                <span class="image-label">${uploadedCarImages.length === 1 ? 'Primary' : 'Image ' + uploadedCarImages.length}</span>
            `;
            photoPreview.appendChild(previewItem);
        };
        reader.readAsDataURL(file);
    });
    
    updateImageCount();
}

function removeImage(index) {
    uploadedCarImages.splice(index, 1);
    refreshImagePreview();
    updateImageCount();
}

function refreshImagePreview() {
    const photoPreview = document.getElementById('photoPreview');
    photoPreview.innerHTML = '';
    
    uploadedCarImages.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const previewItem = document.createElement('div');
            previewItem.className = 'preview-item';
            previewItem.innerHTML = `
                <img src="${e.target.result}" alt="Preview">
                <button type="button" class="remove-image" onclick="removeImage(${index})">
                    <i class="fas fa-times"></i>
                </button>
                <span class="image-label">${index === 0 ? 'Primary' : 'Image ' + (index + 1)}</span>
            `;
            photoPreview.appendChild(previewItem);
        };
        reader.readAsDataURL(file);
    });
}

function updateImageCount() {
    const uploadArea = document.getElementById('photoUpload');
    if (uploadArea && uploadedCarImages.length > 0) {
        const countText = uploadArea.querySelector('p');
        if (countText) {
            countText.textContent = `${uploadedCarImages.length} image(s) selected`;
        }
    }
}

// Form validation
function validateForm() {
    const requiredFields = [
        'brand', 'model', 'year', 'fuelType', 'transmission',
        'mileage', 'expectedPrice', 'sellerName', 'sellerEmail',
        'sellerPhone', 'sellerCity'
    ];
    
    for (const field of requiredFields) {
        const input = document.getElementById(field);
        if (!input || !input.value.trim()) {
            return false;
        }
    }
    
    return true;
}

// Message display helper
function showMessage(message, type) {
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add to page
    document.body.appendChild(messageDiv);
    
    // Animate in
    setTimeout(() => messageDiv.classList.add('show'), 10);
    
    // Remove after 4 seconds
    setTimeout(() => {
        messageDiv.classList.remove('show');
        setTimeout(() => messageDiv.remove(), 300);
    }, 4000);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initImageUpload();
    populateYearDropdown();
    initFormNavigation();
    
    // Attach form submit handler
    const form = document.getElementById('sellCarForm');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            submitCarListing();
        });
    }
});

// Populate year dropdown
function populateYearDropdown() {
    const yearSelect = document.getElementById('year');
    if (!yearSelect) return;
    
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 1990; year--) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }
}

// Form navigation
function initFormNavigation() {
    const nextButtons = document.querySelectorAll('.btn-next');
    const prevButtons = document.querySelectorAll('.btn-prev');
    
    nextButtons.forEach(button => {
        button.addEventListener('click', () => {
            const nextStep = button.dataset.next;
            navigateToStep(nextStep);
        });
    });
    
    prevButtons.forEach(button => {
        button.addEventListener('click', () => {
            const prevStep = button.dataset.prev;
            navigateToStep(prevStep);
        });
    });
}

function navigateToStep(stepId) {
    // Hide all steps
    document.querySelectorAll('.form-step').forEach(step => {
        step.classList.remove('active');
    });
    
    // Show target step
    const targetStep = document.getElementById(stepId);
    if (targetStep) {
        targetStep.classList.add('active');
    }
    
    // Update progress indicators
    const steps = document.querySelectorAll('.sell-steps .step');
    const stepNumber = parseInt(stepId.replace('step', ''));
    
    steps.forEach((step, index) => {
        if (index < stepNumber) {
            step.classList.add('completed');
            step.classList.remove('active');
        } else if (index === stepNumber - 1) {
            step.classList.add('active');
            step.classList.remove('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
