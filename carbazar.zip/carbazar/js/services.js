// Services Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeServices();
    loadFeaturedServices();
    initializeBookingModal();
});

const servicesData = [
    {
        id: 1,
        title: '150-Point Inspection',
        description: 'Comprehensive vehicle assessment covering all major systems',
        price: '$199',
        icon: 'fas fa-search-plus',
        features: ['Engine diagnostics', 'Brake system check', 'Transmission analysis', 'Safety systems review'],
        category: 'inspection'
    },
    {
        id: 2,
        title: 'Mobile Oil Change',
        description: 'Professional oil change service at your location',
        price: '$89',
        icon: 'fas fa-wrench',
        features: ['Premium oil & filter', 'Multi-point inspection', 'Fluid top-offs', 'Service reminder'],
        category: 'maintenance'
    },
    {
        id: 3,
        title: 'Premium Detailing',
        description: 'Complete interior and exterior detailing service',
        price: '$299',
        icon: 'fas fa-spray-can',
        features: ['Exterior wash & wax', 'Interior deep clean', 'Leather conditioning', 'Paint protection'],
        category: 'detailing'
    },
    {
        id: 4,
        title: 'Virtual Test Drive',
        description: 'Experience your dream car with VR technology',
        price: 'Free',
        icon: 'fas fa-vr-cardboard',
        features: ['360° interior view', 'Realistic driving simulation', 'Multiple car models', 'Expert guidance'],
        category: 'digital'
    },
    {
        id: 5,
        title: 'Insurance Comparison',
        description: 'Compare quotes from top insurance providers',
        price: 'Free',
        icon: 'fas fa-shield-alt',
        features: ['Multiple quotes', 'Best rate guarantee', 'Expert consultation', 'Instant approval'],
        category: 'insurance'
    },
    {
        id: 6,
        title: 'Home Delivery',
        description: 'Vehicle delivered safely to your doorstep',
        price: '$199',
        icon: 'fas fa-truck',
        features: ['Professional drivers', 'Insured transport', 'Flexible scheduling', 'Real-time tracking'],
        category: 'delivery'
    },
    {
        id: 7,
        title: 'AI Car Valuation',
        description: 'Instant market value assessment using AI',
        price: '$29',
        icon: 'fas fa-calculator',
        features: ['Market analysis', 'Condition assessment', 'Price trends', 'Detailed report'],
        category: 'digital'
    },
    {
        id: 8,
        title: 'Ceramic Coating',
        description: 'Premium paint protection with ceramic coating',
        price: '$899',
        icon: 'fas fa-shield-alt',
        features: ['5-year warranty', 'UV protection', 'Scratch resistance', 'Enhanced shine'],
        category: 'detailing'
    }
];

function initializeServices() {
    // Category card click handlers
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            filterServicesByCategory(category);
            
            // Smooth scroll to services section
            document.querySelector('.featured-services').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    });

    // Set minimum date for booking
    const dateInput = document.getElementById('serviceDate');
    if (dateInput) {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        dateInput.min = tomorrow.toISOString().split('T')[0];
    }
}

function loadFeaturedServices() {
    const servicesGrid = document.getElementById('servicesGrid');
    if (!servicesGrid) return;

    servicesGrid.innerHTML = '';
    
    servicesData.forEach(service => {
        const serviceCard = createServiceCard(service);
        servicesGrid.appendChild(serviceCard);
    });
}

function createServiceCard(service) {
    const card = document.createElement('div');
    card.className = 'service-card';
    card.innerHTML = `
        <div class="service-header">
            <div class="service-icon">
                <i class="${service.icon}"></i>
            </div>
            <h3 class="service-title">${service.title}</h3>
        </div>
        <p class="service-description">${service.description}</p>
        <ul class="service-features">
            ${service.features.map(feature => `<li>${feature}</li>`).join('')}
        </ul>
        <div class="service-footer">
            <div class="service-price">
                ${service.price}
                ${service.price !== 'Free' && service.price !== 'Custom' ? '<span class="price-note">starting from</span>' : ''}
            </div>
            <button class="btn-primary" onclick="openBookingModal('${service.title}', '${service.price}')">
                Book Now
            </button>
        </div>
    `;
    return card;
}

function filterServicesByCategory(category) {
    const filteredServices = servicesData.filter(service => service.category === category);
    const servicesGrid = document.getElementById('servicesGrid');
    
    servicesGrid.innerHTML = '';
    
    if (filteredServices.length === 0) {
        servicesGrid.innerHTML = '<p class="no-services">No services found in this category.</p>';
        return;
    }
    
    filteredServices.forEach(service => {
        const serviceCard = createServiceCard(service);
        servicesGrid.appendChild(serviceCard);
    });
    
    // Update section title
    const sectionTitle = document.querySelector('.featured-services h2');
    const categoryNames = {
        'inspection': 'Vehicle Inspection Services',
        'maintenance': 'Maintenance & Repair Services',
        'detailing': 'Detailing & Care Services',
        'digital': 'Digital Services',
        'insurance': 'Insurance & Legal Services',
        'delivery': 'Delivery & Transport Services'
    };
    sectionTitle.textContent = categoryNames[category] || 'Featured Services';
    
    // Add back button
    if (!document.querySelector('.back-to-all')) {
        const backButton = document.createElement('button');
        backButton.className = 'btn-secondary back-to-all';
        backButton.innerHTML = '<i class="fas fa-arrow-left"></i> Show All Services';
        backButton.onclick = () => {
            loadFeaturedServices();
            sectionTitle.textContent = 'Most Popular Services';
            backButton.remove();
        };
        sectionTitle.parentNode.insertBefore(backButton, sectionTitle.nextSibling);
    }
}

function initializeBookingModal() {
    const form = document.getElementById('serviceBookingForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleServiceBooking();
        });
    }
}

function openBookingModal(serviceName, price) {
    const modal = document.getElementById('bookingModal');
    const serviceInput = document.getElementById('selectedService');
    const priceInput = document.getElementById('servicePrice');
    
    if (serviceInput) serviceInput.value = serviceName;
    if (priceInput) priceInput.value = price;
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
    
    // Reset form
    const form = document.getElementById('serviceBookingForm');
    if (form) form.reset();
}

function handleServiceBooking() {
    const formData = new FormData(document.getElementById('serviceBookingForm'));
    const bookingData = {
        service: document.getElementById('selectedService').value,
        price: document.getElementById('servicePrice').value,
        date: document.getElementById('serviceDate').value,
        time: document.getElementById('serviceTime').value,
        vehicle: formData.get('vehicle') || 'Not specified',
        notes: formData.get('notes') || 'None'
    };
    
    // Simulate booking process
    showBookingConfirmation(bookingData);
    closeBookingModal();
}

function showBookingConfirmation(bookingData) {
    const confirmation = document.createElement('div');
    confirmation.className = 'booking-confirmation';
    confirmation.innerHTML = `
        <div class="confirmation-content">
            <div class="confirmation-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Booking Confirmed!</h3>
            <p>Your ${bookingData.service} has been scheduled for ${formatDate(bookingData.date)} at ${bookingData.time}.</p>
            <p>We'll send you a confirmation email shortly with all the details.</p>
            <button class="btn-primary" onclick="this.parentElement.parentElement.remove()">
                Got it!
            </button>
        </div>
    `;
    
    document.body.appendChild(confirmation);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (confirmation.parentNode) {
            confirmation.remove();
        }
    }, 5000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('bookingModal');
    if (e.target === modal) {
        closeBookingModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeBookingModal();
    }
});

// Add booking confirmation styles
const confirmationStyles = `
.booking-confirmation {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3000;
    animation: fadeIn 0.3s ease;
}

.confirmation-content {
    background: white;
    padding: 3rem;
    border-radius: 20px;
    text-align: center;
    max-width: 500px;
    margin: 2rem;
}

.confirmation-icon {
    font-size: 4rem;
    color: #28a745;
    margin-bottom: 1rem;
}

.confirmation-content h3 {
    font-size: 1.8rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 1rem;
}

.confirmation-content p {
    color: #6c757d;
    margin-bottom: 1rem;
    line-height: 1.6;
}

.back-to-all {
    display: block;
    margin: 1rem auto 2rem;
    padding: 0.8rem 1.5rem;
    background: #6c757d;
    color: white;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.back-to-all:hover {
    background: #5a6268;
    transform: translateY(-2px);
}

.no-services {
    text-align: center;
    color: #6c757d;
    font-size: 1.2rem;
    padding: 3rem;
    grid-column: 1 / -1;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = confirmationStyles;
document.head.appendChild(styleSheet);