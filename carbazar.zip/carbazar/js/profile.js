// Profile Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeProfile();
    loadUserData();
});

function initializeProfile() {
    // Tab switching
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    // Settings form
    const settingsForm = document.querySelector('.settings-form');
    if (settingsForm) {
        settingsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveSettings();
        });
    }
}

function switchTab(tabName) {
    // Remove active class from all menu items and tabs
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    
    // Add active class to selected menu item and tab
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

function loadUserData() {
    // Load user data from localStorage or API
    const userData = JSON.parse(localStorage.getItem('userData')) || {
        name: 'Ananya Sharma',
        email: 'ananya.sharma@email.com',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face'
    };
    
    // Update profile information
    document.getElementById('profileName').textContent = userData.name;
    document.getElementById('profileEmail').textContent = userData.email;
    document.getElementById('userName').textContent = userData.name;
    document.getElementById('profileImage').src = userData.avatar;
    document.querySelector('.user-avatar').src = userData.avatar;
}

function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('active');
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.user-menu')) {
            dropdown.classList.remove('active');
        }
    });
}

function changeProfilePhoto() {
    // Simulate file upload
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const newAvatar = e.target.result;
                document.getElementById('profileImage').src = newAvatar;
                document.querySelector('.user-avatar').src = newAvatar;
                
                // Save to localStorage
                const userData = JSON.parse(localStorage.getItem('userData')) || {};
                userData.avatar = newAvatar;
                localStorage.setItem('userData', JSON.stringify(userData));
                
                showMessage('Profile photo updated successfully!', 'success');
            };
            reader.readAsDataURL(file);
        }
    };
    input.click();
}

function removeFavorite(button) {
    const favoriteItem = button.closest('.favorite-item');
    favoriteItem.style.transform = 'scale(0)';
    favoriteItem.style.opacity = '0';
    
    setTimeout(() => {
        favoriteItem.remove();
        showMessage('Removed from favorites', 'info');
    }, 300);
}

function saveSettings() {
    const formData = new FormData(document.querySelector('.settings-form'));
    
    // Simulate saving settings
    showMessage('Settings saved successfully!', 'success');
    
    // Update user data in localStorage
    const userData = JSON.parse(localStorage.getItem('userData')) || {};
    userData.name = formData.get('firstName') + ' ' + formData.get('lastName');
    userData.email = formData.get('email');
    localStorage.setItem('userData', JSON.stringify(userData));
    
    // Update displayed name
    loadUserData();
}

function logout() {
    // Clear user data
    localStorage.removeItem('userData');
    localStorage.removeItem('isLoggedIn');
    
    // Redirect to login page
    window.location.href = 'login.html';
}

function showMessage(text, type = 'info') {
    const message = document.createElement('div');
    message.className = `message message-${type} show`;
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.classList.remove('show');
        setTimeout(() => message.remove(), 300);
    }, 3000);
}

// Add message styles
const messageStyles = `
.message {
    position: fixed;
    top: 100px;
    right: 20px;
    padding: 1rem 1.5rem;
    border-radius: 10px;
    color: white;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.8rem;
    transform: translateX(400px);
    transition: all 0.3s ease;
    z-index: 2000;
    min-width: 300px;
}

.message.show {
    transform: translateX(0);
}

.message-success { background: #28a745; }
.message-error { background: #dc3545; }
.message-info { background: #17a2b8; }
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = messageStyles;
document.head.appendChild(styleSheet);