// Auction Platform Functionality

let currentAuctions = [];
let userBids = {};
let watchlist = [];

document.addEventListener('DOMContentLoaded', function() {
    initializeAuction();
    loadAuctions();
    startCountdowns();
    initializeBidModal();
});

function initializeAuction() {
    // Filter tabs
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            filterAuctions(filter);
        });
    });
    
    // Sort functionality
    const sortSelect = document.getElementById('auctionSort');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortAuctions(this.value);
        });
    }
    
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    const searchBtn = document.querySelector('.search-box button');
    
    if (searchBtn) {
        searchBtn.addEventListener('click', performAuctionSearch);
    }
    
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performAuctionSearch();
            }
        });
    }
}

function loadAuctions() {
    currentAuctions = [
        {
            id: 1,
            title: "2023 Mercedes-Benz S-Class",
            currentBid: 6950000,
            minimumBid: 6990000,
            bidCount: 23,
            endTime: new Date(Date.now() + 2 * 60 * 60 * 1000 + 45 * 60 * 1000), // 2h 45m from now
            image: "images/cars/mercedes-s-class.jpg.avif",
            mileage: "5,200 mi",
            fuel: "Petrol",
            transmission: "Automatic",
            status: "live",
            reserve: true
        },
        {
            id: 2,
            title: "2023 BMW 7 Series",
            startingBid: 5950000,
            startTime: new Date(Date.now() + 4 * 60 * 60 * 1000 + 20 * 60 * 1000), // 4h 20m from now
            image: "images/cars/bmw-7-series.jpg.avif",
            mileage: "3,800 mi",
            fuel: "Petrol",
            transmission: "Automatic",
            status: "upcoming",
            reserve: true
        },
        {
            id: 3,
            title: "2023 Audi A8 L",
            finalBid: 6230000,
            endTime: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
            image: "images/cars/audi-a8.jpg.avif",
            mileage: "4,500 mi",
            fuel: "Petrol",
            transmission: "Automatic",
            status: "ended",
            winner: "Bidder #156"
        }
    ];
    
    displayAuctions(currentAuctions);
    updateStats();
}

function displayAuctions(auctions) {
    const container = document.getElementById('auctionCards');
    if (!container) return;
    
    container.innerHTML = '';
    
    auctions.forEach(auction => {
        const card = createAuctionCard(auction);
        container.appendChild(card);
    });
}

function createAuctionCard(auction) {
    const card = document.createElement('div');
    card.className = `auction-card ${auction.status}`;
    
    let statusContent = '';
    let actionButtons = '';
    
    if (auction.status === 'live') {
        statusContent = `
            <span class="status-badge live">LIVE</span>
            <div class="countdown" data-end="${auction.endTime.toISOString()}">
                <span class="time-unit">
                    <span class="time-value">02</span>
                    <span class="time-label">H</span>
                </span>
                <span class="time-unit">
                    <span class="time-value">45</span>
                    <span class="time-label">M</span>
                </span>
                <span class="time-unit">
                    <span class="time-value">30</span>
                    <span class="time-label">S</span>
                </span>
            </div>
        `;
        
        actionButtons = `
            <button class="btn-primary bid-btn" onclick="openBidModal(${auction.id})">
                <i class="fas fa-gavel"></i> Place Bid
            </button>
            <button class="btn-secondary" onclick="watchLive(${auction.id})">
                <i class="fas fa-eye"></i> Watch Live
            </button>
        `;
    } else if (auction.status === 'upcoming') {
        const timeUntil = Math.floor((auction.startTime - new Date()) / (1000 * 60));
        const hours = Math.floor(timeUntil / 60);
        const minutes = timeUntil % 60;
        
        statusContent = `
            <span class="status-badge upcoming">UPCOMING</span>
            <div class="start-time">
                Starts in ${hours}h ${minutes}m
            </div>
        `;
        
        actionButtons = `
            <button class="btn-secondary" onclick="setReminder(${auction.id})">
                <i class="fas fa-bell"></i> Set Reminder
            </button>
            <button class="btn-primary" onclick="viewDetails(${auction.id})">
                <i class="fas fa-info-circle"></i> View Details
            </button>
        `;
    } else if (auction.status === 'ended') {
        statusContent = `
            <span class="status-badge ended">ENDED</span>
            <div class="final-result">
                Sold for ₹${auction.finalBid.toLocaleString()}
            </div>
        `;
        
        actionButtons = `
            <button class="btn-secondary" onclick="viewResults(${auction.id})">
                <i class="fas fa-trophy"></i> View Results
            </button>
        `;
    }
    
    card.innerHTML = `
        <div class="auction-status">
            ${statusContent}
        </div>
        
        <div class="auction-image">
            <img src="${auction.image}" alt="${auction.title}" onerror="this.src='images/cars/default-car.jpg.avif'">
            <div class="image-count">
                <i class="fas fa-camera"></i> ${Math.floor(Math.random() * 20) + 10} photos
            </div>
            <button class="watchlist-btn" onclick="toggleWatchlist(${auction.id})">
                <i class="${watchlist.includes(auction.id) ? 'fas' : 'far'} fa-heart"></i>
            </button>
        </div>
        
        <div class="auction-info">
            <h3>${auction.title}</h3>
            <div class="vehicle-details">
                <span><i class="fas fa-tachometer-alt"></i> ${auction.mileage}</span>
                <span><i class="fas fa-gas-pump"></i> ${auction.fuel}</span>
                <span><i class="fas fa-cogs"></i> ${auction.transmission}</span>
            </div>
            
            <div class="bid-info">
                <div class="current-bid">
                    <span class="bid-label">${auction.status === 'live' ? 'Current Bid' : auction.status === 'upcoming' ? 'Starting Bid' : 'Final Bid'}</span>
                    <span class="bid-amount">₹${(auction.currentBid || auction.startingBid || auction.finalBid).toLocaleString()}</span>
                </div>
                <div class="bid-count">
                    ${auction.status === 'live' ? `<i class="fas fa-gavel"></i> ${auction.bidCount} bids` : 
                      auction.status === 'upcoming' ? `<i class="fas fa-shield-alt"></i> Reserve ${auction.reserve ? 'Set' : 'Not Set'}` :
                      `<i class="fas fa-trophy"></i> Won by ${auction.winner}`}
                </div>
            </div>
            
            <div class="auction-actions">
                ${actionButtons}
            </div>
        </div>
    `;
    
    return card;
}

function startCountdowns() {
    setInterval(() => {
        document.querySelectorAll('.countdown').forEach(countdown => {
            const endTime = new Date(countdown.getAttribute('data-end'));
            const now = new Date();
            const timeLeft = endTime - now;
            
            if (timeLeft > 0) {
                const hours = Math.floor(timeLeft / (1000 * 60 * 60));
                const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
                
                const timeUnits = countdown.querySelectorAll('.time-value');
                if (timeUnits.length >= 3) {
                    timeUnits[0].textContent = hours.toString().padStart(2, '0');
                    timeUnits[1].textContent = minutes.toString().padStart(2, '0');
                    timeUnits[2].textContent = seconds.toString().padStart(2, '0');
                }
            } else {
                countdown.innerHTML = '<span class="ended">AUCTION ENDED</span>';
            }
        });
    }, 1000);
}

function initializeBidModal() {
    const modal = document.getElementById('bidModal');
    const closeBtn = modal?.querySelector('.close-modal');
    const submitBtn = document.getElementById('submitBid');
    const autoBidCheckbox = document.getElementById('autoBid');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }
    
    if (autoBidCheckbox) {
        autoBidCheckbox.addEventListener('change', function() {
            const settings = document.querySelector('.auto-bid-settings');
            settings.style.display = this.checked ? 'block' : 'none';
        });
    }
    
    if (submitBtn) {
        submitBtn.addEventListener('click', submitBid);
    }
    
    // Quick bid buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('quick-bid')) {
            const amount = e.target.getAttribute('data-amount');
            document.getElementById('bidAmount').value = amount;
        }
    });
}

function openBidModal(auctionId) {
    const auction = currentAuctions.find(a => a.id === auctionId);
    if (!auction) return;
    
    const modal = document.getElementById('bidModal');
    document.getElementById('currentBidAmount').textContent = `₹${auction.currentBid.toLocaleString()}`;
    document.getElementById('minimumBidAmount').textContent = `₹${auction.minimumBid.toLocaleString()}`;
    document.getElementById('bidAmount').min = auction.minimumBid;
    document.getElementById('bidAmount').value = auction.minimumBid;
    
    // Update quick bid buttons
    const quickBids = document.querySelectorAll('.quick-bid');
    quickBids.forEach((btn, index) => {
        const amount = auction.minimumBid + (index * 1000);
        btn.setAttribute('data-amount', amount);
        btn.textContent = `₹${amount.toLocaleString()}`;
    });
    
    modal.setAttribute('data-auction-id', auctionId);
    modal.style.display = 'flex';
}

function submitBid() {
    const modal = document.getElementById('bidModal');
    const auctionId = parseInt(modal.getAttribute('data-auction-id'));
    const bidAmount = parseInt(document.getElementById('bidAmount').value);
    const acceptTerms = document.getElementById('acceptTerms').checked;
    
    if (!acceptTerms) {
        showMessage('Please accept the auction terms to continue.', 'error');
        return;
    }
    
    const auction = currentAuctions.find(a => a.id === auctionId);
    if (bidAmount < auction.minimumBid) {
        showMessage(`Bid must be at least ₹${auction.minimumBid.toLocaleString()}`, 'error');
        return;
    }
    
    // Simulate bid submission
    showMessage('Placing your bid...', 'info');
    
    setTimeout(() => {
        auction.currentBid = bidAmount;
        auction.minimumBid = bidAmount + 500;
        auction.bidCount++;
        
        userBids[auctionId] = bidAmount;
        
        showMessage(`Bid placed successfully! You bid ₹${bidAmount.toLocaleString()}`, 'success');
        modal.style.display = 'none';
        
        // Refresh auction display
        displayAuctions(currentAuctions);
        updateActivity();
    }, 1500);
}

function toggleWatchlist(auctionId) {
    const index = watchlist.indexOf(auctionId);
    if (index > -1) {
        watchlist.splice(index, 1);
        showMessage('Removed from watchlist', 'info');
    } else {
        watchlist.push(auctionId);
        showMessage('Added to watchlist', 'success');
    }
    
    // Update heart icon
    const btn = document.querySelector(`button[onclick="toggleWatchlist(${auctionId})"] i`);
    if (btn) {
        btn.className = watchlist.includes(auctionId) ? 'fas fa-heart' : 'far fa-heart';
    }
}

function watchLive(auctionId) {
    const modal = document.getElementById('liveStreamModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function setReminder(auctionId) {
    showMessage('Reminder set! We\'ll notify you when the auction starts.', 'success');
}

function viewDetails(auctionId) {
    window.location.href = `car-details.html?id=${auctionId}`;
}

function viewResults(auctionId) {
    showMessage('Auction results displayed', 'info');
}

function filterAuctions(filter) {
    let filtered = currentAuctions;
    
    switch(filter) {
        case 'live':
            filtered = currentAuctions.filter(a => a.status === 'live');
            break;
        case 'upcoming':
            filtered = currentAuctions.filter(a => a.status === 'upcoming');
            break;
        case 'ended':
            filtered = currentAuctions.filter(a => a.status === 'ended');
            break;
        case 'watchlist':
            filtered = currentAuctions.filter(a => watchlist.includes(a.id));
            break;
    }
    
    displayAuctions(filtered);
}

function sortAuctions(sortBy) {
    let sorted = [...currentAuctions];
    
    switch(sortBy) {
        case 'ending-soon':
            sorted.sort((a, b) => {
                if (a.status === 'live' && b.status === 'live') {
                    return new Date(a.endTime) - new Date(b.endTime);
                }
                return 0;
            });
            break;
        case 'price-low':
            sorted.sort((a, b) => (a.currentBid || a.startingBid || 0) - (b.currentBid || b.startingBid || 0));
            break;
        case 'price-high':
            sorted.sort((a, b) => (b.currentBid || b.startingBid || 0) - (a.currentBid || a.startingBid || 0));
            break;
    }
    
    displayAuctions(sorted);
}

function performAuctionSearch() {
    const query = document.querySelector('.search-box input').value.toLowerCase();
    const filtered = currentAuctions.filter(auction => 
        auction.title.toLowerCase().includes(query)
    );
    displayAuctions(filtered);
}

function updateStats() {
    const liveCount = currentAuctions.filter(a => a.status === 'live').length;
    const totalBidders = new Set(Object.keys(userBids)).size + 247; // Base number + user bids
    
    document.getElementById('liveAuctions').textContent = liveCount;
    document.getElementById('activeBidders').textContent = totalBidders;
}

function updateActivity() {
    // Simulate activity updates
    const activities = [
        'New bid placed on Mercedes S-Class',
        'Audi A8 auction ended',
        'BMW 7 Series starting soon'
    ];
    
    // This would update the activity feed in a real application
}

function showMessage(text, type = 'success') {
    const message = document.createElement('div');
    message.className = `message message-${type}`;
    message.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        transform: translateX(400px);
        transition: transform 0.3s ease;
    `;
    
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span style="margin-left: 0.5rem;">${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        message.style.transform = 'translateX(400px)';
        setTimeout(() => message.remove(), 300);
    }, 4000);
}