// Dealers Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeDealers();
    loadDealers();
    initializeMap();
});

const dealersData = [
    {
        id: 1,
        name: "Premium Motors",
        rating: 4.9,
        reviews: 245,
        distance: 2.3,
        address: "123 Luxury Ave, Downtown",
        phone: "+1 (555) 123-4567",
        email: "info@premiummotors.com",
        website: "www.premiummotors.com",
        brands: ["Mercedes-Benz", "BMW", "Audi"],
        services: ["New Cars", "Used Cars", "Service", "Parts", "Financing"],
        hours: "Mon-Sat: 9AM-8PM, Sun: 10AM-6PM",
        image: "https://via.placeholder.com/300x200/667eea/ffffff?text=Premium+Motors",
        coordinates: { lat: 40.7128, lng: -74.0060 },
        featured: true,
        certified: true
    },
    {
        id: 2,
        name: "Auto World",
        rating: 4.7,
        reviews: 892,
        distance: 3.8,
        address: "456 Motor Blvd, Midtown",
        phone: "+1 (555) 234-5678",
        email: "sales@autoworld.com",
        website: "www.autoworld.com",
        brands: ["Tesla", "Porsche", "Lexus"],
        services: ["New Cars", "Used Cars", "Service", "Financing"],
        hours: "Mon-Fri: 8AM-9PM, Sat-Sun: 9AM-7PM",
        image: "https://via.placeholder.com/300x200/764ba2/ffffff?text=Auto+World",
        coordinates: { lat: 40.7589, lng: -73.9851 },
        featured: true,
        certified: true
    },
    {
        id: 3,
        name: "Elite Cars",
        rating: 4.8,
        reviews: 156,
        distance: 5.2,
        address: "789 Elite Street, Uptown",
        phone: "+1 (555) 345-6789",
        email: "contact@elitecars.com",
        website: "www.elitecars.com",
        brands: ["BMW", "Audi", "Mercedes-Benz"],
        services: ["New Cars", "Service", "Parts"],
        hours: "Mon-Sat: 9AM-7PM, Sun: Closed",
        image: "https://via.placeholder.com/300x200/28a745/ffffff?text=Elite+Cars",
        coordinates: { lat: 40.7831, lng: -73.9712 },
        featured: true,
        certified: true
    },
    {
        id: 4,
        name: "City Motors",
        rating: 4.5,
        reviews: 324,
        distance: 4.1,
        address: "321 City Center Dr, Central",
        phone: "+1 (555) 456-7890",
        email: "info@citymotors.com",
        website: "www.citymotors.com",
        brands: ["Tesla", "BMW", "Audi"],
        services: ["New Cars", "Used Cars", "Financing"],
        hours: "Mon-Sun: 9AM-8PM",
        image: "https://via.placeholder.com/300x200/17a2b8/ffffff?text=City+Motors",
        coordinates: { lat: 40.7505, lng: -73.9934 },
        featured: false,
        certified: true
    },
    {
        id: 5,
        name: "Luxury Auto Gallery",
        rating: 4.6,
        reviews: 198,
        distance: 6.7,
        address: "654 Gallery Way, Arts District",
        phone: "+1 (555) 567-8901",
        email: "sales@luxuryautogallery.com",
        website: "www.luxuryautogallery.com",
        brands: ["Porsche", "Mercedes-Benz", "Lexus"],
        services: ["New Cars", "Used Cars", "Service", "Parts"],
        hours: "Tue-Sat: 10AM-7PM, Sun-Mon: Closed",
        image: "https://via.placeholder.com/300x200/ffc107/ffffff?text=Luxury+Auto",
        coordinates: { lat: 40.7282, lng: -74.0776 },
        featured: false,
        certified: true
    },
    {
        id: 6,
        name: "Metro Car Center",
        rating: 4.4,
        reviews: 567,
        distance: 7.9,
        address: "987 Metro Plaza, Business District",
        phone: "+1 (555) 678-9012",
        email: "contact@metrocarcenter.com",
        website: "www.metrocarcenter.com",
        brands: ["BMW", "Tesla", "Audi"],
        services: ["New Cars", "Used Cars", "Service", "Financing"],
        hours: "Mon-Fri: 8AM-8PM, Sat-Sun: 9AM-6PM",
        image: "https://via.placeholder.com/300x200/dc3545/ffffff?text=Metro+Car"
        coordinates: { lat: 40.7614, lng: -73.9776 },
        featured: false,
        certified: true
    }
];

let filteredDealers = [...dealersData];
let currentView = 'list';

function initializeDealers() {
    // View toggle
    const viewBtns = document.querySelectorAll('.view-btn');
    viewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            viewBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const view = this.getAttribute('data-view');
            switchView(view);
        });
    });

    // Filters
    const filters = ['brandFilter', 'serviceFilter', 'ratingFilter', 'distanceFilter'];
    filters.forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', applyFilters);
        }
    });

    // Sort
    const sortSelect = document.getElementById('sortBy');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortDealers(this.value);
        });
    }

    // Search
    const locationSearch = document.getElementById('locationSearch');
    if (locationSearch) {
        locationSearch.addEventListener('input', function() {
            searchByLocation(this.value);
        });
    }
}

function switchView(view) {
    currentView = view;
    
    const listView = document.getElementById('listView');
    const mapView = document.getElementById('mapView');
    
    if (view === 'list') {
        listView.classList.add('active');
        mapView.classList.remove('active');
    } else {
        listView.classList.remove('active');
        mapView.classList.add('active');
        loadMapDealers();
    }
}

function loadDealers() {
    const dealersGrid = document.getElementById('dealersGrid');
    if (!dealersGrid) return;

    dealersGrid.innerHTML = '';
    
    filteredDealers.forEach(dealer => {
        const dealerCard = createDealerCard(dealer);
        dealersGrid.appendChild(dealerCard);
    });
    
    updateResultsCount();
}

function createDealerCard(dealer) {
    const card = document.createElement('div');
    card.className = 'dealer-card';
    card.innerHTML = `
        <div class="dealer-header">
            <div class="dealer-info">
                <h3>${dealer.name}</h3>
                <div class="dealer-rating">
                    <span class="stars">${'★'.repeat(Math.floor(dealer.rating))}${'☆'.repeat(5 - Math.floor(dealer.rating))}</span>
                    <span class="rating-text">${dealer.rating} (${dealer.reviews} reviews)</span>
                </div>
            </div>
            <div class="dealer-distance">${dealer.distance} miles</div>
        </div>
        
        <div class="dealer-details">
            <div class="dealer-detail">
                <i class="fas fa-map-marker-alt"></i>
                <span>${dealer.address}</span>
            </div>
            <div class="dealer-detail">
                <i class="fas fa-phone"></i>
                <span>${dealer.phone}</span>
            </div>
            <div class="dealer-detail">
                <i class="fas fa-clock"></i>
                <span>${dealer.hours}</span>
            </div>
        </div>
        
        <div class="dealer-brands">
            ${dealer.brands.map(brand => `<span class="brand-tag">${brand}</span>`).join('')}
        </div>
        
        <div class="dealer-services">
            ${dealer.services.map(service => `<span class="service-tag">${service}</span>`).join('')}
        </div>
        
        <div class="dealer-actions">
            <button class="btn-primary" onclick="contactDealer(${dealer.id})">
                <i class="fas fa-phone"></i> Contact
            </button>
            <button class="btn-outline" onclick="viewDealerDetails(${dealer.id})">
                <i class="fas fa-info-circle"></i> Details
            </button>
            <button class="btn-outline" onclick="getDirections(${dealer.id})">
                <i class="fas fa-directions"></i> Directions
            </button>
        </div>
    `;
    
    return card;
}

function applyFilters() {
    const brandFilter = document.getElementById('brandFilter').value;
    const serviceFilter = document.getElementById('serviceFilter').value;
    const ratingFilter = document.getElementById('ratingFilter').value;
    const distanceFilter = document.getElementById('distanceFilter').value;
    
    filteredDealers = dealersData.filter(dealer => {
        let matches = true;
        
        if (brandFilter && !dealer.brands.some(brand => brand.toLowerCase().includes(brandFilter.toLowerCase()))) {
            matches = false;
        }
        
        if (serviceFilter) {
            const serviceMap = {
                'sales': 'New Cars',
                'used': 'Used Cars',
                'service': 'Service',
                'parts': 'Parts',
                'financing': 'Financing'
            };
            if (!dealer.services.includes(serviceMap[serviceFilter])) {
                matches = false;
            }
        }
        
        if (ratingFilter && dealer.rating < parseFloat(ratingFilter)) {
            matches = false;
        }
        
        if (distanceFilter && dealer.distance > parseFloat(distanceFilter)) {
            matches = false;
        }
        
        return matches;
    });
    
    loadDealers();
    if (currentView === 'map') {
        loadMapDealers();
    }
}

function sortDealers(sortBy) {
    switch (sortBy) {
        case 'distance':
            filteredDealers.sort((a, b) => a.distance - b.distance);
            break;
        case 'rating':
            filteredDealers.sort((a, b) => b.rating - a.rating);
            break;
        case 'name':
            filteredDealers.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'reviews':
            filteredDealers.sort((a, b) => b.reviews - a.reviews);
            break;
    }
    
    loadDealers();
    if (currentView === 'map') {
        loadMapDealers();
    }
}

function searchByLocation(query) {
    if (query.length < 2) {
        filteredDealers = [...dealersData];
    } else {
        filteredDealers = dealersData.filter(dealer => 
            dealer.address.toLowerCase().includes(query.toLowerCase()) ||
            dealer.name.toLowerCase().includes(query.toLowerCase())
        );
    }
    
    loadDealers();
    if (currentView === 'map') {
        loadMapDealers();
    }
}

function searchDealers() {
    const location = document.getElementById('locationSearch').value;
    if (location) {
        searchByLocation(location);
        showMessage(`Searching for dealers near "${location}"`, 'info');
    }
}

function updateResultsCount() {
    const resultsCount = document.getElementById('resultsCount');
    if (resultsCount) {
        resultsCount.textContent = `${filteredDealers.length} dealers found`;
    }
}

// Map Functions
function initializeMap() {
    // Map is now embedded directly in HTML
    showMessage('Map loaded successfully', 'success');
}

function loadMapDealers() {
    const mapDealersList = document.getElementById('mapDealersList');
    if (!mapDealersList) return;
    
    mapDealersList.innerHTML = '';
    
    filteredDealers.forEach(dealer => {
        const dealerItem = document.createElement('div');
        dealerItem.className = 'map-dealer-item';
        dealerItem.innerHTML = `
            <h4>${dealer.name}</h4>
            <div class="dealer-rating">
                <span class="stars">${'★'.repeat(Math.floor(dealer.rating))}</span>
                <span class="rating-text">${dealer.rating} (${dealer.reviews})</span>
            </div>
            <p><i class="fas fa-map-marker-alt"></i> ${dealer.address}</p>
            <p><i class="fas fa-route"></i> ${dealer.distance} miles away</p>
        `;
        
        dealerItem.addEventListener('click', function() {
            selectMapDealer(dealer.id);
        });
        
        mapDealersList.appendChild(dealerItem);
    });
}

function selectMapDealer(dealerId) {
    // Remove active class from all items
    document.querySelectorAll('.map-dealer-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Add active class to selected item
    const selectedItem = Array.from(document.querySelectorAll('.map-dealer-item'))
        .find(item => item.querySelector('h4').textContent === dealersData.find(d => d.id === dealerId).name);
    
    if (selectedItem) {
        selectedItem.classList.add('active');
    }
    
    // Center map on selected dealer (simulated)
    showMessage(`Centered map on ${dealersData.find(d => d.id === dealerId).name}`, 'info');
}

function centerMap() {
    showMessage('Map centered on your location', 'info');
}

function toggleSatellite() {
    showMessage('Switched to satellite view', 'info');
}

function findNearby() {
    showMessage('Finding nearby dealers...', 'info');
    // Simulate finding nearby dealers
    setTimeout(() => {
        showMessage('Found 12 dealers within 10 miles', 'success');
    }, 1500);
}

// Dealer Actions
function contactDealer(dealerId) {
    const dealer = dealersData.find(d => d.id === dealerId);
    if (dealer) {
        showMessage(`Calling ${dealer.name} at ${dealer.phone}`, 'info');
        // In a real app, this would initiate a phone call or open contact form
    }
}

function viewDealerDetails(dealerId) {
    const dealer = dealersData.find(d => d.id === dealerId);
    if (dealer) {
        showMessage(`Opening details for ${dealer.name}`, 'info');
        // In a real app, this would navigate to dealer details page
        window.open(`dealer-details.html?id=${dealerId}`, '_blank');
    }
}

function getDirections(dealerId) {
    const dealer = dealersData.find(d => d.id === dealerId);
    if (dealer) {
        showMessage(`Getting directions to ${dealer.name}`, 'info');
        // In a real app, this would open maps with directions
        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(dealer.address)}`;
        window.open(mapsUrl, '_blank');
    }
}

// Dealer Application Modal
function openDealerApplication() {
    const modal = document.getElementById('dealerApplicationModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeDealerApplication() {
    const modal = document.getElementById('dealerApplicationModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
    
    // Reset form
    const form = document.getElementById('dealerApplicationForm');
    if (form) form.reset();
}

function downloadBrochure() {
    showMessage('Downloading dealer brochure...', 'info');
    // In a real app, this would download a PDF brochure
    setTimeout(() => {
        showMessage('Brochure downloaded successfully!', 'success');
    }, 1500);
}

// Form submission
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('dealerApplicationForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleDealerApplication();
        });
    }
});

function handleDealerApplication() {
    showMessage('Submitting application...', 'info');
    
    // Simulate form submission
    setTimeout(() => {
        showMessage('Application submitted successfully! We will contact you within 2 business days.', 'success');
        closeDealerApplication();
    }, 2000);
}

function showMessage(text, type = 'info') {
    const message = document.createElement('div');
    message.className = `message message-${type} show`;
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.classList.remove('show');
        setTimeout(() => message.remove(), 300);
    }, 3000);
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('dealerApplicationModal');
    if (e.target === modal) {
        closeDealerApplication();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeDealerApplication();
    }
});

// Add message styles
const messageStyles = `
.message {
    position: fixed;
    top: 100px;
    right: 20px;
    padding: 1rem 1.5rem;
    border-radius: 10px;
    color: white;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.8rem;
    transform: translateX(400px);
    transition: all 0.3s ease;
    z-index: 2000;
    min-width: 300px;
}

.message.show {
    transform: translateX(0);
}

.message-success { background: #28a745; }
.message-error { background: #dc3545; }
.message-info { background: #17a2b8; }
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = messageStyles;
document.head.appendChild(styleSheet);