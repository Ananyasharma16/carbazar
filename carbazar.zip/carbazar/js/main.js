// Main JavaScript for CarBazar

// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
}

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Featured Cars Data with correct image paths
const featuredCars = [
    {
        id: 1,
        brand: "Mercedes-Benz",
        model: "S-Class 2023",
        price: "$95,000",
        image: "images/cars/mercedes-s-class.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "5,000",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Luxury sedan with advanced technology and premium comfort features."
    },
    {
        id: 2,
        brand: "BMW",
        model: "7 Series 2023",
        price: "$89,500",
        image: "images/cars/bmw-7-series.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "3,200",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Executive sedan combining performance with luxury and cutting-edge technology."
    },
    {
        id: 3,
        brand: "Audi",
        model: "A8 L 2023",
        price: "$87,000",
        image: "images/cars/audi-a8.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "4,500",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Premium luxury sedan with Quattro all-wheel drive and innovative features."
    },
    {
        id: 4,
        brand: "Tesla",
        model: "Model S 2023",
        price: "$94,000",
        image: "images/cars/tesla-model-s.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "2,100",
        fuel: "Electric",
        transmission: "Automatic",
        description: "High-performance electric sedan with autopilot and over-the-air updates."
    },
    {
        id: 5,
        brand: "Porsche",
        model: "Panamera 2023",
        price: "$102,000",
        image: "images/cars/porsche-panamera.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "1,800",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Sports sedan delivering exceptional performance and luxury in perfect harmony."
    },
    {
        id: 6,
        brand: "Lexus",
        model: "LS 500 2023",
        price: "$78,000",
        image: "images/cars/lexus-ls.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "6,200",
        fuel: "Hybrid",
        transmission: "Automatic",
        description: "Luxury hybrid sedan offering refined comfort and exceptional reliability."
    }
];

// Brands Data
const brands = [
    { name: "Mercedes-Benz", image: "images/brands/mercedes.png.avif", cars: 45 },
    { name: "BMW", image: "images/brands/bmw.png.avif", cars: 38 },
    { name: "Audi", image: "images/brands/audi.png.avif", cars: 42 },
    { name: "Toyota", image: "images/brands/toyota.png.avif", cars: 67 },
    { name: "Honda", image: "images/brands/honda.png.avif", cars: 52 },
    { name: "Ford", image: "images/brands/ford.png.avif", cars: 34 },
    { name: "Tesla", image: "images/brands/tesla.png.avif", cars: 28 },
    { name: "Porsche", image: "images/brands/porsche.png.avif", cars: 23 },
    { name: "Lexus", image: "images/brands/lexus.png.avif", cars: 31 }
];

// Enhanced image loading with fallback
function createImageWithFallback(src, fallback, alt, className = '') {
    const img = document.createElement('img');
    img.alt = alt;
    if (className) img.className = className;
    
    img.onerror = function() {
        this.onerror = null;
        this.src = fallback || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkNhciBJbWFnZTwvdGV4dD48L3N2Zz4=';
    };
    
    img.src = src;
    return img;
}

// Load Featured Cars with enhanced functionality
function loadFeaturedCars() {
    const carsGrid = document.getElementById('featured-cars-grid');
    if (!carsGrid) return;
    
    carsGrid.innerHTML = '';
    
    featuredCars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        
        const carImage = document.createElement('div');
        carImage.className = 'car-image';
        const img = createImageWithFallback(car.image, car.fallback, `${car.brand} ${car.model}`);
        carImage.appendChild(img);
        
        carCard.innerHTML = `
            <div class="car-info">
                <h3 class="car-title">${car.brand} ${car.model}</h3>
                <div class="car-price">${car.price}</div>
                <div class="car-features">
                    <span><i class="fas fa-calendar-alt"></i> ${car.year}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${car.mileage} km</span>
                    <span><i class="fas fa-gas-pump"></i> ${car.fuel}</span>
                </div>
                <a href="car-details.html?id=${car.id}" class="btn-primary">View Details</a>
            </div>
        `;
        
        carCard.insertBefore(carImage, carCard.firstChild);
        carsGrid.appendChild(carCard);
    });
}

// Load Brands
function loadBrands() {
    const brandsGrid = document.getElementById('brands-grid');
    if (!brandsGrid) return;
    
    brandsGrid.innerHTML = '';
    
    brands.forEach(brand => {
        const brandCard = document.createElement('div');
        brandCard.className = 'brand-card';
        
        const img = createImageWithFallback(brand.image, 'images/cars/default-car.jpg.avif', brand.name);
        
        brandCard.appendChild(img);
        brandCard.innerHTML += `
            <h3>${brand.name}</h3>
            <p>${brand.cars} cars available</p>
        `;
        
        brandsGrid.appendChild(brandCard);
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    loadFeaturedCars();
    loadBrands();
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Get car data by ID
function getCarById(id) {
    return featuredCars.find(car => car.id === parseInt(id));
}

// Search functionality
const searchInput = document.querySelector('.search-bar input');
const searchButton = document.querySelector('.search-bar button');

if (searchInput && searchButton) {
    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
}

function performSearch() {
    const query = searchInput.value.trim().toLowerCase();
    if (query) {
        const filteredCars = featuredCars.filter(car => 
            car.brand.toLowerCase().includes(query) ||
            car.model.toLowerCase().includes(query) ||
            car.fuel.toLowerCase().includes(query)
        );
        
        if (filteredCars.length > 0) {
            displaySearchResults(filteredCars);
        } else {
            showMessage('No cars found matching your search.', 'error');
        }
    }
}

function displaySearchResults(cars) {
    const carsGrid = document.getElementById('featured-cars-grid');
    if (!carsGrid) return;
    
    carsGrid.innerHTML = '';
    cars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        
        const carImage = document.createElement('div');
        carImage.className = 'car-image';
        const img = createImageWithFallback(car.image, car.fallback, `${car.brand} ${car.model}`);
        carImage.appendChild(img);
        
        carCard.innerHTML = `
            <div class="car-info">
                <h3 class="car-title">${car.brand} ${car.model}</h3>
                <div class="car-price">${car.price}</div>
                <div class="car-features">
                    <span><i class="fas fa-calendar-alt"></i> ${car.year}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${car.mileage} km</span>
                    <span><i class="fas fa-gas-pump"></i> ${car.fuel}</span>
                </div>
                <a href="car-details.html?id=${car.id}" class="btn-primary">View Details</a>
            </div>
        `;
        
        carCard.insertBefore(carImage, carCard.firstChild);
        carsGrid.appendChild(carCard);
    });
    
    document.getElementById('featured').scrollIntoView({ behavior: 'smooth' });
}

function showMessage(text, type = 'success') {
    const message = document.createElement('div');
    message.className = `message message-${type} show`;
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.classList.remove('show');
        setTimeout(() => message.remove(), 300);
    }, 3000);
}