// AI Chatbot Functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeChatbot();
});

function initializeChatbot() {
    const chatbotToggle = document.getElementById('chatbotToggle');
    const chatbotContainer = document.getElementById('chatbotContainer');
    const closeChatbot = document.getElementById('closeChatbot');
    const sendMessageBtn = document.getElementById('sendMessage');
    const chatbotInput = document.getElementById('chatbotInput');
    
    // Toggle chatbot visibility
    chatbotToggle.addEventListener('click', function() {
        chatbotContainer.style.display = 'flex';
        chatbotToggle.style.display = 'none';
        chatbotInput.focus();
    });
    
    closeChatbot.addEventListener('click', function() {
        chatbotContainer.style.display = 'none';
        chatbotToggle.style.display = 'flex';
    });
    
    // Send message functionality
    sendMessageBtn.addEventListener('click', sendMessage);
    chatbotInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

function sendMessage() {
    const input = document.getElementById('chatbotInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message to chat
    addMessage(message, 'user');
    input.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Get bot response
    setTimeout(() => {
        removeTypingIndicator();
        const response = getBotResponse(message);
        addMessage(response, 'bot');
    }, 1000 + Math.random() * 1000); // Simulate thinking time
}

function addMessage(text, sender) {
    const messagesContainer = document.getElementById('chatbotMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `${sender}-message`;
    
    const messageContent = document.createElement('p');
    messageContent.innerHTML = text; // Use innerHTML to support rich formatting
    messageDiv.appendChild(messageContent);
    
    // Add timestamp
    const timestamp = document.createElement('small');
    timestamp.textContent = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    timestamp.style.opacity = '0.7';
    timestamp.style.fontSize = '0.8em';
    messageDiv.appendChild(timestamp);
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Add animation
    messageDiv.style.opacity = '0';
    messageDiv.style.transform = 'translateY(20px)';
    setTimeout(() => {
        messageDiv.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        messageDiv.style.opacity = '1';
        messageDiv.style.transform = 'translateY(0)';
    }, 10);
}

function showTypingIndicator() {
    const messagesContainer = document.getElementById('chatbotMessages');
    const typingDiv = document.createElement('div');
    typingDiv.className = 'bot-message typing-indicator';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = '<p>CarBazar Assistant is typing...</p>';
    
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function getBotResponse(userMessage) {
    const message = userMessage.toLowerCase();
    
    // Enhanced car knowledge with current page context
    const currentPage = window.location.pathname;
    const isCarDetailsPage = currentPage.includes('car-details.html');
    
    // Car-specific responses for details page
    if (isCarDetailsPage) {
        const carTitle = document.getElementById('carTitle')?.textContent || '';
        const carPrice = document.getElementById('carPrice')?.textContent || '';
        
        if (message.includes('price') || message.includes('cost')) {
            return `This ${carTitle} is priced at ${carPrice}. The price includes premium features, warranty, and our quality guarantee. Would you like information about financing options or trade-in value?`;
        }
        
        if (message.includes('feature') || message.includes('spec')) {
            return `This ${carTitle} comes with premium features including advanced safety systems, luxury interior, and cutting-edge technology. Check the Features tab above for complete details. Any specific feature you'd like to know about?`;
        }
        
        if (message.includes('test drive') || message.includes('drive')) {
            return `You can schedule a test drive for this ${carTitle} by clicking the 'Schedule Test Drive' button. We'll arrange a convenient time for you to experience this amazing vehicle. When would you prefer to test drive?`;
        }
    }
    
    // Brand-specific responses with enhanced details
    if (message.includes('mercedes') || message.includes('benz')) {
        return "Mercedes-Benz represents the pinnacle of luxury automotive engineering. Our inventory includes S-Class ($95,000+), E-Class ($55,000+), and C-Class ($42,000+). Each model features advanced safety systems, premium materials, and cutting-edge technology. Which Mercedes model interests you most?";
    }
    
    if (message.includes('bmw')) {
        return "BMW delivers 'The Ultimate Driving Machine' experience with perfect balance of performance and luxury. Available models: 7 Series ($89,500), 5 Series ($54,000), 3 Series ($35,000). All feature BMW's signature kidney grille, precise handling, and innovative iDrive system. Looking for sport or luxury focus?";
    }
    
    if (message.includes('audi')) {
        return "Audi's 'Vorsprung durch Technik' philosophy brings you advanced Quattro AWD and cutting-edge technology. Our A8 L ($87,000) offers flagship luxury, while Q-series SUVs provide versatility. All models feature Virtual Cockpit and premium Bang & Olufsen audio. Interested in sedan or SUV?";
    }
    
    if (message.includes('tesla')) {
        return "Tesla revolutionizes driving with Model S ($94,000) offering 405-mile range, 0-60 in 1.99s, and Autopilot. Features include 17-inch touchscreen, over-the-air updates, and Supercharger network access. Our Tesla inventory includes Full Self-Driving capability. Want to know about charging or performance?";
    }
    
    if (message.includes('porsche')) {
        return "Porsche Panamera ($102,000) combines sports car DNA with luxury sedan practicality. Features include adaptive air suspension, Sport Chrono package, and Porsche Communication Management. Available in various powertrains from V6 to Turbo S. Interested in performance specs or luxury features?";
    }
    
    if (message.includes('lexus')) {
        return "Lexus LS 500 ($78,000) delivers Japanese luxury with hybrid efficiency, ultra-quiet cabin, and legendary reliability. Features include Mark Levinson audio, massage seats, and Lexus Safety System+ 2.5. Known for exceptional build quality and customer service. Want to know about hybrid technology?";
    }
    
    // Enhanced feature responses
    if (message.includes('fuel') || message.includes('mileage') || message.includes('mpg')) {
        return "Fuel efficiency by category: Luxury sedans (20-25 MPG), Hybrid luxury (35-45 MPG), Electric vehicles (300+ mile range), Performance cars (15-20 MPG). Our inventory includes EPA ratings and real-world efficiency data. Which fuel type interests you most?";
    }
    
    if (message.includes('safety') || message.includes('crash')) {
        return "All our premium vehicles feature 5-star safety ratings with advanced systems: adaptive cruise control, lane keeping assist, automatic emergency braking, blind spot monitoring, and 360° cameras. Many include night vision and traffic sign recognition. Safety is our top priority!";
    }
    
    if (message.includes('warranty') || message.includes('guarantee')) {
        return "Our vehicles come with comprehensive coverage: manufacturer warranty (4 years/50,000 miles), extended warranty options available, 150-point inspection guarantee, and 7-day return policy. We also offer maintenance packages and roadside assistance. Want warranty details for a specific car?";
    }
    
    // Financing and purchasing
    if (message.includes('finance') || message.includes('loan') || message.includes('payment')) {
        return "We offer flexible financing: 0.9% APR for qualified buyers, lease options from $599/month, trade-in evaluations, and partnerships with major banks. Our finance team can pre-approve you in minutes. What's your preferred monthly payment range?";
    }
    
    if (message.includes('trade') || message.includes('exchange')) {
        return "Trade-in your current vehicle! We accept all makes/models, provide instant online valuations, handle all paperwork, and offer competitive trade values. Our appraisers use current market data. What vehicle are you looking to trade in?";
    }
    
    // Enhanced buying guidance
    if (message.includes('buy') || message.includes('purchase')) {
        return "Smart car buying checklist: Set budget (including insurance/maintenance), choose fuel type, prioritize features, check safety ratings, compare warranties, and schedule test drives. Our consultants provide personalized recommendations. What's your budget range and must-have features?";
    }
    
    if (message.includes('sell') || message.includes('selling')) {
        return "Maximize your car's value: professional detailing, gather maintenance records, get pre-sale inspection, research market value, take quality photos, and consider our consignment service. We handle everything for premium vehicles. What car are you looking to sell?";
    }
    
    // Technology and features
    if (message.includes('technology') || message.includes('tech') || message.includes('infotainment')) {
        return "Latest automotive tech: wireless Apple CarPlay/Android Auto, heads-up displays, gesture controls, voice assistants, wireless charging, premium audio systems, and smartphone integration. Our luxury vehicles feature the most advanced systems available. Any specific tech feature you're interested in?";
    }
    
    // Maintenance and service
    if (message.includes('maintenance') || message.includes('service')) {
        return "Luxury car maintenance: European brands ($1,200-2,000/year), Japanese luxury ($800-1,200/year), Electric vehicles ($400-600/year). We provide service records, recommend certified technicians, and offer maintenance packages. Proper maintenance preserves value and performance!";
    }
    
    // Greetings with enhanced context
    if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
        const responses = [
            "Hello! I'm your CarBazar AI assistant. I can help you find the perfect luxury vehicle, explain features, arrange test drives, and answer any car-related questions. What brings you to CarBazar today?",
            "Hi there! Welcome to CarBazar, where luxury meets excellence. I'm here to help you discover our premium vehicle collection and find your dream car. What type of vehicle are you interested in?",
            "Hey! I'm your personal car expert at CarBazar. Whether you're buying, selling, or just exploring, I can provide detailed information about our luxury inventory. How can I assist you today?"
        ];
        return responses[Math.floor(Math.random() * responses.length)];
    }
    
    if (message.includes('thank') || message.includes('thanks')) {
        return "You're very welcome! I'm here whenever you need car advice, want to schedule a test drive, or have questions about our inventory. Feel free to ask about specific models, financing, or anything else car-related. Happy car shopping!";
    }
    
    // Enhanced default responses
    const defaultResponses = [
        "I'm your CarBazar specialist with expertise in luxury vehicles, financing, and automotive technology. I can help you compare models, understand features, or find the perfect car for your needs. What specific information can I provide?",
        "As your automotive consultant, I have detailed knowledge of our premium inventory, market trends, and car technologies. Whether you're interested in performance, luxury, or efficiency, I can guide you to the right choice. What matters most to you in a vehicle?",
        "I'm here to make your car shopping experience exceptional! I can provide detailed specifications, arrange viewings, explain financing options, and answer technical questions. What would you like to explore first?",
        "Welcome to the future of car shopping! I combine AI intelligence with automotive expertise to help you find your ideal vehicle. From luxury sedans to electric innovations, I'm your guide. What type of driving experience are you seeking?"
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
}