// 360° Car Rotation Functionality

let currentRotation = 0;
let isRotating = false;
let rotationImages = [];
let currentImageIndex = 0;

document.addEventListener('DOMContentLoaded', function() {
    initializeRotationViewer();
});

function initializeRotationViewer() {
    const rotationViewer = document.getElementById('rotationViewer');
    const rotateLeftBtn = document.getElementById('rotateLeft');
    const rotateRightBtn = document.getElementById('rotateRight');
    const mainImage = document.getElementById('mainCarImage');
    
    if (!rotationViewer || !mainImage) return;
    
    // Initialize rotation images
    setupRotationImages();
    
    // Mouse drag rotation
    let isDragging = false;
    let startX = 0;
    let startRotation = 0;
    
    rotationViewer.addEventListener('mousedown', (e) => {
        isDragging = true;
        startX = e.clientX;
        startRotation = currentRotation;
        rotationViewer.style.cursor = 'grabbing';
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const deltaX = e.clientX - startX;
        const rotationDelta = deltaX * 0.5; // Adjust sensitivity
        currentRotation = startRotation + rotationDelta;
        
        // Normalize rotation (0-360)
        currentRotation = ((currentRotation % 360) + 360) % 360;
        
        updateRotationImage();
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
        rotationViewer.style.cursor = 'grab';
    });
    
    // Touch events for mobile
    rotationViewer.addEventListener('touchstart', (e) => {
        isDragging = true;
        startX = e.touches[0].clientX;
        startRotation = currentRotation;
        e.preventDefault();
    });
    
    rotationViewer.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        
        const deltaX = e.touches[0].clientX - startX;
        const rotationDelta = deltaX * 0.5;
        currentRotation = startRotation + rotationDelta;
        
        currentRotation = ((currentRotation % 360) + 360) % 360;
        updateRotationImage();
        e.preventDefault();
    });
    
    rotationViewer.addEventListener('touchend', () => {
        isDragging = false;
    });
    
    // Button controls
    if (rotateLeftBtn) {
        rotateLeftBtn.addEventListener('click', () => {
            rotateLeft();
        });
    }
    
    if (rotateRightBtn) {
        rotateRightBtn.addEventListener('click', () => {
            rotateRight();
        });
    }
    
    // Keyboard controls
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            rotateLeft();
        } else if (e.key === 'ArrowRight') {
            rotateRight();
        }
    });
    
    // Auto-rotation demo
    startAutoRotation();
}

function setupRotationImages() {
    const mainImage = document.getElementById('mainCarImage');
    if (!mainImage) return;
    
    const baseSrc = mainImage.src;
    
    // Create array of rotation images (simulated 360° views)
    rotationImages = [
        baseSrc,
        baseSrc.replace('.jpg.avif', '-side.jpg.avif'),
        baseSrc.replace('.jpg.avif', '-back.jpg.avif'),
        baseSrc.replace('.jpg.avif', '-other-side.jpg.avif')
    ];
    
    // Preload images for smooth rotation
    rotationImages.forEach(src => {
        const img = new Image();
        img.src = src;
    });
}

function updateRotationImage() {
    const imageIndex = Math.floor((currentRotation / 360) * rotationImages.length) % rotationImages.length;
    
    if (imageIndex !== currentImageIndex) {
        currentImageIndex = imageIndex;
        const mainImage = document.getElementById('mainCarImage');
        if (mainImage) {
            mainImage.src = rotationImages[currentImageIndex];
        }
    }
    
    // Update rotation info
    const rotationInfo = document.getElementById('rotationInfo');
    if (rotationInfo) {
        rotationInfo.textContent = `360° View - ${Math.round(currentRotation)}°`;
    }
}

function rotateLeft() {
    currentRotation -= 45;
    currentRotation = ((currentRotation % 360) + 360) % 360;
    updateRotationImage();
    animateRotation();
}

function rotateRight() {
    currentRotation += 45;
    currentRotation = ((currentRotation % 360) + 360) % 360;
    updateRotationImage();
    animateRotation();
}

function animateRotation() {
    const mainImage = document.getElementById('mainCarImage');
    if (!mainImage) return;
    
    mainImage.style.transform = `scale(1.05)`;
    setTimeout(() => {
        mainImage.style.transform = `scale(1)`;
    }, 200);
}

function startAutoRotation() {
    let autoRotationInterval;
    
    // Start auto-rotation after 3 seconds of inactivity
    function resetAutoRotation() {
        clearInterval(autoRotationInterval);
        setTimeout(() => {
            if (!isRotating) {
                autoRotationInterval = setInterval(() => {
                    if (!isDragging && !isRotating) {
                        currentRotation += 2;
                        currentRotation = currentRotation % 360;
                        updateRotationImage();
                    }
                }, 100);
            }
        }, 3000);
    }
    
    // Stop auto-rotation on user interaction
    document.addEventListener('mousedown', () => {
        clearInterval(autoRotationInterval);
        isRotating = true;
    });
    
    document.addEventListener('mouseup', () => {
        isRotating = false;
        resetAutoRotation();
    });
    
    document.addEventListener('touchstart', () => {
        clearInterval(autoRotationInterval);
        isRotating = true;
    });
    
    document.addEventListener('touchend', () => {
        isRotating = false;
        resetAutoRotation();
    });
    
    // Initial auto-rotation
    resetAutoRotation();
}

// Fullscreen rotation viewer
function toggleFullscreen() {
    const rotationViewer = document.getElementById('rotationViewer');
    
    if (!document.fullscreenElement) {
        rotationViewer.requestFullscreen().catch(err => {
            console.log('Error attempting to enable fullscreen:', err);
        });
    } else {
        document.exitFullscreen();
    }
}

// Add fullscreen button functionality
document.addEventListener('DOMContentLoaded', function() {
    const rotationControls = document.querySelector('.rotation-controls');
    if (rotationControls) {
        const fullscreenBtn = document.createElement('button');
        fullscreenBtn.innerHTML = '<i class="fas fa-expand"></i>';
        fullscreenBtn.title = 'Fullscreen';
        fullscreenBtn.addEventListener('click', toggleFullscreen);
        rotationControls.appendChild(fullscreenBtn);
    }
});

// Handle fullscreen changes
document.addEventListener('fullscreenchange', function() {
    const fullscreenBtn = document.querySelector('.rotation-controls button:last-child i');
    if (fullscreenBtn) {
        if (document.fullscreenElement) {
            fullscreenBtn.className = 'fas fa-compress';
        } else {
            fullscreenBtn.className = 'fas fa-expand';
        }
    }
});