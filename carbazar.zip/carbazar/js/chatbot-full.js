// Full Chatbot Functionality for chatbot.html
document.addEventListener('DOMContentLoaded', function() {
    initializeFullChatbot();
    setupQuickQuestions();
    setupVoiceInput();
});

function initializeFullChatbot() {
    const sendButton = document.getElementById('sendMessageFull');
    const inputField = document.getElementById('chatbotInputFull');
    const messagesContainer = document.getElementById('chatbotMessagesFull');
    
    if (!sendButton || !inputField || !messagesContainer) return;
    
    // Send message on button click
    sendButton.addEventListener('click', sendFullMessage);
    
    // Send message on Enter key
    inputField.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendFullMessage();
        }
    });
    
    // Auto-focus input field
    inputField.focus();
}

function sendFullMessage() {
    const inputField = document.getElementById('chatbotInputFull');
    const message = inputField.value.trim();
    
    if (!message) return;
    
    // Add user message
    addFullMessage(message, 'user');
    inputField.value = '';
    
    // Show typing indicator
    showFullTypingIndicator();
    
    // Get AI response
    setTimeout(() => {
        removeFullTypingIndicator();
        const response = getEnhancedBotResponse(message);
        addFullMessage(response, 'bot');
        
        // Auto-scroll to bottom
        scrollToBottom();
    }, 1000 + Math.random() * 1000);
}

function addFullMessage(text, sender) {
    const messagesContainer = document.getElementById('chatbotMessagesFull');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `${sender}-message ${sender}-message-full`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = sender === 'user' ? 
        '<i class="fas fa-user"></i>' : 
        '<i class="fas fa-robot"></i>';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    
    // Format message with basic markdown
    const formattedText = formatMessage(text);
    content.innerHTML = formattedText;
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    messagesContainer.appendChild(messageDiv);
    
    scrollToBottom();
}

function formatMessage(text) {
    // Simple markdown formatting
    return text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br>')
        .replace(/- (.*?)(?=\n|$)/g, '<li>$1</li>')
        .replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
}

function showFullTypingIndicator() {
    const messagesContainer = document.getElementById('chatbotMessagesFull');
    
    const typingDiv = document.createElement('div');
    typingDiv.className = 'bot-message bot-message-full typing-indicator';
    typingDiv.id = 'fullTypingIndicator';
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = '<i class="fas fa-robot"></i>';
    
    const content = document.createElement('div');
    content.className = 'message-content';
    content.innerHTML = `
        <div class="typing-dots">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <p>CarBazar AI is thinking...</p>
    `;
    
    typingDiv.appendChild(avatar);
    typingDiv.appendChild(content);
    messagesContainer.appendChild(typingDiv);
    
    scrollToBottom();
}

function removeFullTypingIndicator() {
    const typingIndicator = document.getElementById('fullTypingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

function scrollToBottom() {
    const messagesContainer = document.getElementById('chatbotMessagesFull');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function setupQuickQuestions() {
    const quickQuestions = document.querySelectorAll('.quick-question');
    const suggestions = document.querySelectorAll('.suggestion');
    
    // Quick questions in sidebar
    quickQuestions.forEach(button => {
        button.addEventListener('click', function() {
            const question = this.getAttribute('data-question');
            document.getElementById('chatbotInputFull').value = question;
            sendFullMessage();
        });
    });
    
    // Suggestions below input
    suggestions.forEach(button => {
        button.addEventListener('click', function() {
            const question = this.getAttribute('data-question');
            document.getElementById('chatbotInputFull').value = question;
            sendFullMessage();
        });
    });
}

function setupVoiceInput() {
    const voiceBtn = document.getElementById('voiceInput');
    const inputField = document.getElementById('chatbotInputFull');
    
    if (!voiceBtn || !('webkitSpeechRecognition' in window)) {
        if (voiceBtn) voiceBtn.style.display = 'none';
        return;
    }
    
    const recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    voiceBtn.addEventListener('click', function() {
        if (voiceBtn.classList.contains('listening')) {
            recognition.stop();
            voiceBtn.classList.remove('listening');
            voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        } else {
            recognition.start();
            voiceBtn.classList.add('listening');
            voiceBtn.innerHTML = '<i class="fas fa-stop"></i>';
        }
    });
    
    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        inputField.value = transcript;
        voiceBtn.classList.remove('listening');
        voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        
        // Auto-send after voice input
        setTimeout(sendFullMessage, 500);
    };
    
    recognition.onerror = function() {
        voiceBtn.classList.remove('listening');
        voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
    };
}

// Enhanced AI responses for full chatbot
function getEnhancedBotResponse(userMessage) {
    const message = userMessage.toLowerCase();
    
    // Car recommendation engine
    if (message.includes('best') || message.includes('recommend') || message.includes('suggest')) {
        return getCarRecommendation(message);
    }
    
    // Price analysis
    if (message.includes('price') || message.includes('cost') || message.includes('expensive')) {
        return getPriceAnalysis(message);
    }
    
    // Comparison queries
    if (message.includes('vs') || message.includes('compare') || message.includes('difference')) {
        return getCarComparison(message);
    }
    
    // Maintenance advice
    if (message.includes('maintenance') || message.includes('service') || message.includes('repair')) {
        return getMaintenanceAdvice(message);
    }
    
    // Default to general car knowledge
    return getGeneralCarResponse(message);
}

function getCarRecommendation(query) {
    const recommendations = {
        family: "**Best Family Cars:**\n\n🚗 **Toyota Highlander** - Spacious, reliable, great safety\n• 3-row seating\n• Excellent crash test ratings\n• Good fuel economy\n\n🚙 **Honda CR-V** - Practical and efficient\n• Smart interior storage\n• Smooth ride quality\n• High resale value\n\n🚘 **Kia Telluride** - Premium features at great price\n• Upscale interior\n• Loaded with tech\n• Comfortable third row",
        
        luxury: "**Best Luxury Cars:**\n\n🏎️ **Mercedes S-Class** - The benchmark\n• Incredible comfort\n• Cutting-edge tech\n• Smooth powerful engines\n\n🚘 **BMW 7 Series** - Sporty luxury\n• Engaging drive\n• Luxurious interior\n• Advanced features\n\n🚙 **Audi A8** - Tech-forward\n• Virtual cockpit\n• Quattro AWD\n• Premium materials",
        
        electric: "**Best Electric Vehicles:**\n\n⚡ **Tesla Model 3** - Performance & range\n• 0-60 in 3.1s\n• 350+ mile range\n• Supercharger network\n\n🔋 **Ford Mustang Mach-E** - American EV\n• Sporty styling\n• 300 mile range\n• Great handling\n\n🌟 **Hyundai Ioniq 5** - Futuristic design\n• Ultra-fast charging\n• Spacious interior\n• Advanced safety",
        
        budget: "**Best Budget Cars:**\n\n💰 **Toyota Corolla** - Reliability king\n• 30+ MPG\n• Low maintenance\n• Great resale\n\n💵 **Honda Civic** - Fun and efficient\n• Sporty handling\n• Quality interior\n• Good features\n\n🎯 **Hyundai Elantra** - Value packed\n• Long warranty\n• Modern tech\n• Fuel efficient"
    };
    
    if (query.includes('family') || query.includes('kids')) return recommendations.family;
    if (query.includes('luxury') || query.includes('premium')) return recommendations.luxury;
    if (query.includes('electric') || query.includes('ev')) return recommendations.electric;
    if (query.includes('budget') || query.includes('cheap')) return recommendations.budget;
    
    return "I'd be happy to recommend a car! Could you tell me:\n• Your budget range\n• Primary use (family, commute, etc.)\n• Must-have features\n• Fuel preference (petrol/diesel/electric)";
}

function getPriceAnalysis(query) {
    return "**Car Pricing Guide:**\n\n💡 **New Cars:**\n• Expect to pay MSRP or slightly below\n• Best deals at month/quarter ends\n• Consider previous model years for discounts\n\n💡 **Used Cars:**\n• 1-3 year old: 20-40% depreciation\n• Look for certified pre-owned for warranty\n• Check vehicle history reports\n\n💡 **Negotiation Tips:**\n• Research market prices first\n• Be ready to walk away\n• Consider total cost, not just monthly payment\n\n*Want a specific price analysis for a particular car?*";
}

function getCarComparison(query) {
    if (query.includes('camry') && query.includes('accord')) {
        return "**Toyota Camry vs Honda Accord:**\n\n🏆 **Camry Advantages:**\n• Slightly more reliable\n• Better resale value\n• More conservative styling\n\n🏆 **Accord Advantages:**\n• More engaging to drive\n• More spacious interior\n• Better fuel economy (hybrid)\n\n**Verdict:** Choose Camry for reliability, Accord for driving enjoyment";
    }
    
    if (query.includes('electric') && query.includes('petrol')) {
        return "**Electric vs Petrol Cars:**\n\n⚡ **Electric Advantages:**\n• Lower running costs\n• Instant torque\n• Zero emissions\n• Less maintenance\n\n⛽ **Petrol Advantages:**\n• Lower purchase price\n• More refueling stations\n• Longer range\n• Faster refueling\n\n**Consider:** Your daily mileage, charging access, and environmental priorities";
    }
    
    return "I can compare cars based on:\n• **Performance** - acceleration, handling\n• **Efficiency** - fuel economy, running costs\n• **Features** - tech, comfort, safety\n• **Value** - price, resale, maintenance\n\n*Which two cars would you like me to compare?*";
}

function getMaintenanceAdvice(query) {
    return "**Car Maintenance Guide:**\n\n🔧 **Regular Maintenance:**\n• Oil change: Every 5,000-7,500 miles\n• Tire rotation: Every 6,000-8,000 miles\n• Air filter: Every 15,000-30,000 miles\n• Brake inspection: Every 10,000 miles\n\n⚠️ **Warning Signs:**\n• Strange noises - get immediate inspection\n• Warning lights - don't ignore them\n• Performance changes - address promptly\n\n💰 **Cost Saving Tips:**\n• Follow maintenance schedule\n• Use quality parts\n• Keep maintenance records\n• Address small issues early\n\n*Need specific advice for your car?*";
}

function getGeneralCarResponse(message) {
    const responses = [
        "As your car expert, I can help with recommendations, pricing, comparisons, maintenance, and buying/selling advice. What specific area would you like to explore?",
        
        "I specialize in all things automotive! Whether you're buying, selling, or just curious about cars, I'm here to help. What would you like to know?",
        
        "From fuel efficiency to luxury features, I can provide detailed information about any car-related topic. What's on your mind today?",
        
        "I'm your personal car consultant! I can analyze your needs, compare options, and provide market insights. How can I assist you with your car journey?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
}