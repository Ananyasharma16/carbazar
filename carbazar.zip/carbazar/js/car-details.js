// Car Details Page Functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeCarDetails();
    initializeTabs();
});

function initializeCarDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const carId = urlParams.get('id');
    
    if (carId) {
        loadCarDetails(carId);
    } else {
        // Redirect to home if no car ID
        window.location.href = 'index.html';
    }
}

function loadCarDetails(carId) {
    // Get car data (in real app, this would be an API call)
    const car = getCarById(carId);
    
    if (!car) {
        alert('Car not found!');
        window.location.href = 'index.html';
        return;
    }
    
    // Update page title
    document.title = `${car.brand} ${car.model} - CarBazar`;
    
    // Load car information
    document.getElementById('carTitle').textContent = `${car.brand} ${car.model}`;
    document.getElementById('carPrice').textContent = car.price;
    document.getElementById('carDescription').textContent = car.description;
    
    // Load car specifications
    loadCarSpecs(car);
    
    // Load car images
    loadCarImages(car);
    
    // Load similar cars
    loadSimilarCars(car.id);
}

function loadCarSpecs(car) {
    const specsContainer = document.getElementById('carSpecs');
    const specs = [
        { icon: 'fas fa-calendar-alt', label: 'Year', value: car.year },
        { icon: 'fas fa-tachometer-alt', label: 'Mileage', value: `${car.mileage} km` },
        { icon: 'fas fa-gas-pump', label: 'Fuel Type', value: car.fuel },
        { icon: 'fas fa-cogs', label: 'Transmission', value: car.transmission },
        { icon: 'fas fa-car', label: 'Body Type', value: 'Sedan' },
        { icon: 'fas fa-palette', label: 'Color', value: 'Black' }
    ];
    
    specsContainer.innerHTML = '';
    specs.forEach(spec => {
        const specItem = document.createElement('div');
        specItem.className = 'spec-item';
        specItem.innerHTML = `
            <i class="${spec.icon}"></i>
            <span>${spec.label}:</span>
            <strong>${spec.value}</strong>
        `;
        specsContainer.appendChild(specItem);
    });
}

function loadCarImages(car) {
    const mainImage = document.getElementById('mainCarImage');
    const thumbnailsContainer = document.getElementById('imageThumbnails');
    
    // Car image variations for 360° view
    const imageVariations = [
        car.image,
        car.image.replace('.jpg.avif', '-interior.jpg.avif'),
        car.image.replace('.jpg.avif', '-back.jpg.avif'),
        car.image.replace('.jpg.avif', '-side.jpg.avif'),
        car.image.replace('.jpg.avif', '-engine.jpg.avif'),
        car.image.replace('.jpg.avif', '-other-side.jpg.avif')
    ].map(imageSrc => {
        // Check if specific variation exists, otherwise use main image
        return imageSrc;
    });
    
    // Set main image
    mainImage.src = car.image;
    mainImage.onerror = function() {
        this.src = car.fallback;
    };
    
    // Create thumbnails
    thumbnailsContainer.innerHTML = '';
    imageVariations.forEach((imageSrc, index) => {
        const thumbnail = document.createElement('div');
        thumbnail.className = `thumbnail ${index === 0 ? 'active' : ''}`;
        
        const img = document.createElement('img');
        img.src = imageSrc;
        img.onerror = function() {
            this.src = car.fallback;
        };
        
        thumbnail.appendChild(img);
        thumbnail.addEventListener('click', () => {
            // Update main image
            mainImage.src = imageSrc;
            
            // Update active thumbnail
            document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
            thumbnail.classList.add('active');
        });
        
        thumbnailsContainer.appendChild(thumbnail);
    });
}

function loadSimilarCars(currentCarId) {
    const similarCarsGrid = document.getElementById('similar-cars-grid');
    if (!similarCarsGrid) return;
    
    // Get similar cars (exclude current car)
    const similarCars = featuredCars.filter(car => car.id !== parseInt(currentCarId)).slice(0, 3);
    
    similarCarsGrid.innerHTML = '';
    similarCars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        
        const carImage = document.createElement('div');
        carImage.className = 'car-image';
        const img = createImageWithFallback(car.image, car.fallback, `${car.brand} ${car.model}`);
        carImage.appendChild(img);
        
        carCard.innerHTML = `
            <div class="car-info">
                <h3 class="car-title">${car.brand} ${car.model}</h3>
                <div class="car-price">${car.price}</div>
                <div class="car-features">
                    <span><i class="fas fa-calendar-alt"></i> ${car.year}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${car.mileage} km</span>
                    <span><i class="fas fa-gas-pump"></i> ${car.fuel}</span>
                </div>
                <a href="car-details.html?id=${car.id}" class="btn-primary">View Details</a>
            </div>
        `;
        
        carCard.insertBefore(carImage, carCard.firstChild);
        similarCarsGrid.appendChild(carCard);
    });
}

function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Remove active class from all buttons and panes
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));
            
            // Add active class to clicked button and corresponding pane
            button.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Action button handlers
document.addEventListener('DOMContentLoaded', function() {
    // Schedule test drive
    document.querySelector('.car-actions .btn-primary').addEventListener('click', function() {
        showMessage('Test drive scheduled! We will contact you soon.', 'success');
    });
    
    // Add to favorites
    document.querySelector('.car-actions .btn-accent').addEventListener('click', function() {
        const icon = this.querySelector('i');
        if (icon.classList.contains('fas')) {
            icon.classList.remove('fas');
            icon.classList.add('far');
            this.innerHTML = '<i class="far fa-heart"></i> Add to Favorites';
            showMessage('Removed from favorites', 'success');
        } else {
            icon.classList.remove('far');
            icon.classList.add('fas');
            this.innerHTML = '<i class="fas fa-heart"></i> Added to Favorites';
            showMessage('Added to favorites!', 'success');
        }
    });
    
    // Share car
    document.querySelector('.car-actions .btn-secondary').addEventListener('click', function() {
        if (navigator.share) {
            navigator.share({
                title: document.getElementById('carTitle').textContent,
                text: 'Check out this amazing car!',
                url: window.location.href
            });
        } else {
            // Fallback for browsers that don't support Web Share API
            navigator.clipboard.writeText(window.location.href);
            showMessage('Link copied to clipboard!', 'success');
        }
    });
    
    // Seller actions
    document.querySelector('.seller-actions .btn-primary').addEventListener('click', function() {
        showMessage('Calling seller...', 'success');
    });
    
    document.querySelector('.seller-actions .btn-accent').addEventListener('click', function() {
        showMessage('Message sent to seller!', 'success');
    });
});

// Show notification messages
function showMessage(text, type = 'success') {
    const message = document.createElement('div');
    message.className = `message message-${type} show`;
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.classList.remove('show');
        setTimeout(() => message.remove(), 300);
    }, 3000);
}