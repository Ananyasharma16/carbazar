// Financing Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeFinancing();
    initializeCalculator();
    initializePreApproval();
});

let currentStep = 1;
const maxSteps = 3;

function initializeFinancing() {
    // Calculator tab switching
    const calcTabs = document.querySelectorAll('.calc-tab');
    calcTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            calcTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const type = this.getAttribute('data-type');
            switchCalculatorType(type);
        });
    });

    // Credit score buttons
    const scoreBtns = document.querySelectorAll('.score-btn');
    scoreBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            scoreBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const score = this.getAttribute('data-score');
            updateInterestRate(score);
            calculatePayment();
        });
    });
}

function initializeCalculator() {
    // Input synchronization
    const vehiclePrice = document.getElementById('vehiclePrice');
    const priceSlider = document.getElementById('priceSlider');
    const downPayment = document.getElementById('downPayment');
    const downSlider = document.getElementById('downSlider');

    if (vehiclePrice && priceSlider) {
        vehiclePrice.addEventListener('input', function() {
            priceSlider.value = this.value;
            updateDownPaymentMax();
            calculatePayment();
        });

        priceSlider.addEventListener('input', function() {
            vehiclePrice.value = this.value;
            updateDownPaymentMax();
            calculatePayment();
        });
    }

    if (downPayment && downSlider) {
        downPayment.addEventListener('input', function() {
            downSlider.value = this.value;
            calculatePayment();
        });

        downSlider.addEventListener('input', function() {
            downPayment.value = this.value;
            calculatePayment();
        });
    }

    // Other inputs
    const loanTerm = document.getElementById('loanTerm');
    const interestRate = document.getElementById('interestRate');

    if (loanTerm) {
        loanTerm.addEventListener('change', calculatePayment);
    }

    if (interestRate) {
        interestRate.addEventListener('input', calculatePayment);
    }

    // Initial calculation
    calculatePayment();
}

function updateDownPaymentMax() {
    const vehiclePrice = parseFloat(document.getElementById('vehiclePrice').value) || 0;
    const downSlider = document.getElementById('downSlider');
    
    if (downSlider) {
        downSlider.max = vehiclePrice;
        
        // Adjust down payment if it exceeds vehicle price
        const currentDown = parseFloat(document.getElementById('downPayment').value) || 0;
        if (currentDown > vehiclePrice) {
            document.getElementById('downPayment').value = vehiclePrice * 0.2; // 20% default
            downSlider.value = vehiclePrice * 0.2;
        }
    }
}

function updateInterestRate(creditScore) {
    const interestRate = document.getElementById('interestRate');
    if (!interestRate) return;

    const rates = {
        'excellent': 2.9,
        'good': 4.5,
        'fair': 8.2,
        'poor': 12.9
    };

    interestRate.value = rates[creditScore] || 4.5;
}

function calculatePayment() {
    const vehiclePrice = parseFloat(document.getElementById('vehiclePrice')?.value) || 45000;
    const downPayment = parseFloat(document.getElementById('downPayment')?.value) || 9000;
    const loanTerm = parseInt(document.getElementById('loanTerm')?.value) || 60;
    const interestRate = parseFloat(document.getElementById('interestRate')?.value) || 4.5;

    const loanAmount = vehiclePrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const numPayments = loanTerm;

    let monthlyPayment = 0;
    if (monthlyRate > 0) {
        monthlyPayment = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
                        (Math.pow(1 + monthlyRate, numPayments) - 1);
    } else {
        monthlyPayment = loanAmount / numPayments;
    }

    const totalCost = monthlyPayment * numPayments;
    const totalInterest = totalCost - loanAmount;

    // Update display
    updatePaymentDisplay(monthlyPayment, loanAmount, totalInterest, totalCost);
    updatePaymentChart(loanAmount, totalInterest);
}

function updatePaymentDisplay(monthly, loan, interest, total) {
    const monthlyEl = document.getElementById('monthlyPayment');
    const loanEl = document.getElementById('loanAmount');
    const interestEl = document.getElementById('totalInterest');
    const totalEl = document.getElementById('totalCost');

    if (monthlyEl) monthlyEl.textContent = `$${Math.round(monthly).toLocaleString()}`;
    if (loanEl) loanEl.textContent = `$${Math.round(loan).toLocaleString()}`;
    if (interestEl) interestEl.textContent = `$${Math.round(interest).toLocaleString()}`;
    if (totalEl) totalEl.textContent = `$${Math.round(total).toLocaleString()}`;
}

function updatePaymentChart(principal, interest) {
    const canvas = document.getElementById('paymentChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = 60;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const total = principal + interest;
    const principalAngle = (principal / total) * 2 * Math.PI;
    const interestAngle = (interest / total) * 2 * Math.PI;

    // Draw principal arc
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, principalAngle);
    ctx.lineTo(centerX, centerY);
    ctx.fillStyle = '#667eea';
    ctx.fill();

    // Draw interest arc
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, principalAngle, principalAngle + interestAngle);
    ctx.lineTo(centerX, centerY);
    ctx.fillStyle = '#764ba2';
    ctx.fill();

    // Add labels
    ctx.fillStyle = '#fff';
    ctx.font = '12px Inter';
    ctx.textAlign = 'center';
    ctx.fillText('Principal', centerX - 30, centerY + 80);
    ctx.fillText('Interest', centerX + 30, centerY + 80);
}

function switchCalculatorType(type) {
    // This would switch between loan, lease, and refinance calculators
    // For now, we'll just show a message
    if (type === 'lease') {
        showMessage('Lease calculator coming soon!', 'info');
    } else if (type === 'refinance') {
        showMessage('Refinance calculator coming soon!', 'info');
    }
}

function scrollToCalculator() {
    document.getElementById('calculator').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

// Pre-Approval Modal Functions
function initializePreApproval() {
    const form = document.getElementById('preApprovalForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handlePreApprovalSubmission();
        });
    }
}

function openPreApprovalModal() {
    const modal = document.getElementById('preApprovalModal');
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Reset to first step
    currentStep = 1;
    updateApprovalSteps();
}

function closePreApprovalModal() {
    const modal = document.getElementById('preApprovalModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
    
    // Reset form
    const form = document.getElementById('preApprovalForm');
    if (form) form.reset();
    
    currentStep = 1;
    updateApprovalSteps();
}

function nextApprovalStep() {
    if (validateCurrentStep()) {
        currentStep++;
        updateApprovalSteps();
    }
}

function prevApprovalStep() {
    currentStep--;
    updateApprovalSteps();
}

function updateApprovalSteps() {
    // Update step indicators
    const steps = document.querySelectorAll('.approval-steps .step');
    steps.forEach((step, index) => {
        if (index + 1 <= currentStep) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });

    // Update form steps
    const formSteps = document.querySelectorAll('.form-step');
    formSteps.forEach((step, index) => {
        if (index + 1 === currentStep) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });
}

function validateCurrentStep() {
    const currentFormStep = document.querySelector(`.form-step[data-step="${currentStep}"]`);
    if (!currentFormStep) return false;

    const requiredInputs = currentFormStep.querySelectorAll('input[required], select[required]');
    let isValid = true;

    requiredInputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = '#dc3545';
            isValid = false;
        } else {
            input.style.borderColor = '#e9ecef';
        }
    });

    if (!isValid) {
        showMessage('Please fill in all required fields.', 'error');
    }

    return isValid;
}

function handlePreApprovalSubmission() {
    if (!validateCurrentStep()) return;

    // Simulate pre-approval process
    showPreApprovalResult();
    closePreApprovalModal();
}

function showPreApprovalResult() {
    const result = document.createElement('div');
    result.className = 'approval-result';
    result.innerHTML = `
        <div class="result-content">
            <div class="result-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Congratulations!</h3>
            <p>You've been pre-approved for up to <strong>$75,000</strong></p>
            <div class="result-details">
                <div class="detail">
                    <span>Estimated Rate:</span>
                    <span>3.9% APR</span>
                </div>
                <div class="detail">
                    <span>Monthly Payment:</span>
                    <span>$678 - $892</span>
                </div>
                <div class="detail">
                    <span>Pre-approval Valid:</span>
                    <span>60 days</span>
                </div>
            </div>
            <div class="result-actions">
                <button class="btn-primary" onclick="this.parentElement.parentElement.parentElement.remove()">
                    Start Shopping
                </button>
                <button class="btn-secondary" onclick="this.parentElement.parentElement.parentElement.remove()">
                    View Details
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(result);

    // Auto remove after 10 seconds
    setTimeout(() => {
        if (result.parentNode) {
            result.remove();
        }
    }, 10000);
}

function showMessage(text, type = 'info') {
    const message = document.createElement('div');
    message.className = `message message-${type} show`;
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.classList.remove('show');
        setTimeout(() => message.remove(), 300);
    }, 3000);
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('preApprovalModal');
    if (e.target === modal) {
        closePreApprovalModal();
    }
});

// Close modal with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePreApprovalModal();
    }
});

// Add styles for approval result and messages
const additionalStyles = `
.approval-result {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3000;
    animation: fadeIn 0.3s ease;
}

.result-content {
    background: white;
    padding: 3rem;
    border-radius: 20px;
    text-align: center;
    max-width: 500px;
    margin: 2rem;
}

.result-icon {
    font-size: 4rem;
    color: #28a745;
    margin-bottom: 1rem;
}

.result-content h3 {
    font-size: 2rem;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 1rem;
}

.result-content p {
    font-size: 1.2rem;
    color: #6c757d;
    margin-bottom: 2rem;
}

.result-details {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}

.detail {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.8rem;
    font-weight: 500;
}

.detail:last-child {
    margin-bottom: 0;
}

.result-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.message {
    position: fixed;
    top: 100px;
    right: 20px;
    padding: 1rem 1.5rem;
    border-radius: 10px;
    color: white;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.8rem;
    transform: translateX(400px);
    transition: all 0.3s ease;
    z-index: 2000;
    min-width: 300px;
}

.message.show {
    transform: translateX(0);
}

.message-success { background: #28a745; }
.message-error { background: #dc3545; }
.message-info { background: #17a2b8; }

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);