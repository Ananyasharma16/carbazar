// Enhanced Authentication with XAMPP Backend
const API_BASE_URL = 'http://localhost/carbazar/backend';

// Login function
async function loginUser(email, password) {
    const submitBtn = document.querySelector('#loginForm button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Logging in...';
    submitBtn.disabled = true;

    try {
        const response = await fetch(`${API_BASE_URL}/login.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                email: email, 
                password: password 
            })
        });

        // Check if response is OK
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            showMessage('Login successful! Redirecting...', 'success');
            
            // Store user data in localStorage
            localStorage.setItem('user', JSON.stringify({
                ...data.user,
                loggedIn: true
            }));

            // Redirect after success
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1500);
        } else {
            showMessage(data.message || 'Login failed. Please try again.', 'error');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Login error:', error);
        showMessage('Network error. Please check if backend is running.', 'error');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Registration function
async function registerUser(fullName, email, phone, password) {
    const submitBtn = document.querySelector('#signupForm button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Creating Account...';
    submitBtn.disabled = true;

    try {
        const response = await fetch(`${API_BASE_URL}/signup.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                fullName: fullName,
                email: email,
                phone: phone,
                password: password 
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            showMessage('Account created successfully!', 'success');
            
            // Store user data
            localStorage.setItem('user', JSON.stringify({
                ...data.user,
                loggedIn: true
            }));

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1500);
        } else {
            showMessage(data.message || 'Registration failed. Please try again.', 'error');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    } catch (error) {
        console.error('Registration error:', error);
        showMessage('Network error. Please check if backend is running.', 'error');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Check authentication status
function checkAuthStatus() {
    const user = localStorage.getItem('user');
    if (user) {
        try {
            const userData = JSON.parse(user);
            if (userData.loggedIn) {
                updateNavigationForLoggedInUser(userData);
                return true;
            }
        } catch (e) {
            console.error('Error parsing user data:', e);
            localStorage.removeItem('user');
        }
    }
    return false;
}

// Initialize authentication
document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    
    // Add form event listeners
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            loginUser(email, password);
        });
    }
    
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                showMessage('Passwords do not match!', 'error');
                return;
            }
            
            registerUser(fullName, email, phone, password);
        });
    }
});