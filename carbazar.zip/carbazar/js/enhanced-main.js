// Enhanced CarBazar Main JavaScript

// Car data with unique images
const featuredCars = [
    {
        id: 1,
        brand: "Mercedes-Benz",
        model: "S-Class 2023",
        price: "₹75,00,000",
        image: "images/cars/mercedes-s-class.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "5,000",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Luxury sedan with advanced technology and premium comfort features.",
        certified: true
    },
    {
        id: 2,
        brand: "BMW",
        model: "7 Series 2023",
        price: "₹71,00,000",
        image: "images/cars/bmw-7-series.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "3,200",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Executive sedan combining performance with luxury and cutting-edge technology.",
        certified: true
    },
    {
        id: 3,
        brand: "Audi",
        model: "A8 L 2023",
        price: "₹69,00,000",
        image: "images/cars/audi-a8.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "4,500",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Premium luxury sedan with Quattro all-wheel drive and innovative features.",
        certified: true
    },
    {
        id: 4,
        brand: "Tesla",
        model: "Model S 2023",
        price: "₹74,50,000",
        image: "images/cars/tesla-model-s.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "2,100",
        fuel: "Electric",
        transmission: "Automatic",
        description: "High-performance electric sedan with autopilot and over-the-air updates.",
        certified: true
    },
    {
        id: 5,
        brand: "Porsche",
        model: "Panamera 2023",
        price: "₹81,00,000",
        image: "images/cars/porsche-panamera.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "1,800",
        fuel: "Petrol",
        transmission: "Automatic",
        description: "Sports sedan delivering exceptional performance and luxury in perfect harmony.",
        certified: true
    },
    {
        id: 6,
        brand: "Lexus",
        model: "LS 500 2023",
        price: "₹62,00,000",
        image: "images/cars/lexus-ls.jpg.avif",
        fallback: "images/cars/default-car.jpg.avif",
        year: 2023,
        mileage: "6,200",
        fuel: "Hybrid",
        transmission: "Automatic",
        description: "Luxury hybrid sedan offering refined comfort and exceptional reliability.",
        certified: true
    }
];

// Brands data with unique images
const brands = [
    { name: "Mercedes-Benz", image: "images/brands/mercedes.png.avif", cars: 45 },
    { name: "BMW", image: "images/brands/bmw.png.avif", cars: 38 },
    { name: "Audi", image: "images/brands/audi.png.avif", cars: 42 },
    { name: "Toyota", image: "images/brands/toyota.png.avif", cars: 67 },
    { name: "Honda", image: "images/brands/honda.png.avif", cars: 52 },
    { name: "Ford", image: "images/brands/ford.png.avif", cars: 34 },
    { name: "Tesla", image: "images/brands/tesla.png.avif", cars: 28 },
    { name: "Porsche", image: "images/brands/porsche.png.avif", cars: 23 },
    { name: "Lexus", image: "images/brands/lexus.png.avif", cars: 31 }
];

document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    loadFeaturedCars();
    loadBrands();
    initializeSearch();
    initializeChatbot();
});

function initializeNavigation() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger?.classList.remove('active');
            navMenu?.classList.remove('active');
        });
    });
}

function createImageWithFallback(src, fallback, alt, className = '') {
    const img = document.createElement('img');
    img.alt = alt;
    if (className) img.className = className;
    
    img.onerror = function() {
        this.onerror = null;
        this.src = fallback || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkNhciBJbWFnZTwvdGV4dD48L3N2Zz4=';
    };
    
    img.src = src;
    return img;
}

function loadFeaturedCars() {
    const carsGrid = document.getElementById('featured-cars-grid');
    if (!carsGrid) return;
    
    carsGrid.innerHTML = '';
    
    featuredCars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        
        const carImage = document.createElement('div');
        carImage.className = 'car-image';
        const img = createImageWithFallback(car.image, car.fallback, `${car.brand} ${car.model}`);
        carImage.appendChild(img);
        
        // Add badges
        const badges = document.createElement('div');
        badges.className = 'car-badges';
        if (car.certified) {
            badges.innerHTML += '<span class="badge certified">Certified</span>';
        }
        if (car.fuel === 'Electric') {
            badges.innerHTML += '<span class="badge electric">Electric</span>';
        }
        carImage.appendChild(badges);
        
        carCard.appendChild(carImage);
        
        carCard.innerHTML += `
            <div class="car-info">
                <h3 class="car-title">${car.brand} ${car.model}</h3>
                <div class="car-price">${car.price}</div>
                <div class="car-features">
                    <span><i class="fas fa-calendar-alt"></i> ${car.year}</span>
                    <span><i class="fas fa-tachometer-alt"></i> ${car.mileage} km</span>
                    <span><i class="fas fa-gas-pump"></i> ${car.fuel}</span>
                </div>
                <div class="car-actions">
                    <a href="car-details.html?id=${car.id}" class="btn-primary">View Details</a>
                    <button class="btn-secondary" onclick="scheduleTestDrive(${car.id})">
                        <i class="fas fa-calendar"></i> Test Drive
                    </button>
                </div>
            </div>
        `;
        
        carsGrid.appendChild(carCard);
        
        // Add hover animation
        carCard.addEventListener('mouseenter', () => {
            carCard.style.transform = 'translateY(-10px)';
        });
        
        carCard.addEventListener('mouseleave', () => {
            carCard.style.transform = 'translateY(0)';
        });
    });
}

function loadBrands() {
    const brandsGrid = document.getElementById('brands-grid');
    if (!brandsGrid) return;
    
    brandsGrid.innerHTML = '';
    
    brands.forEach(brand => {
        const brandCard = document.createElement('div');
        brandCard.className = 'brand-card';
        
        const img = createImageWithFallback(brand.image, 'images/cars/default-car.jpg.avif', brand.name);
        
        brandCard.appendChild(img);
        brandCard.innerHTML += `
            <h3>${brand.name}</h3>
            <p>${brand.cars} cars available</p>
        `;
        
        brandsGrid.appendChild(brandCard);
        
        // Add click functionality
        brandCard.addEventListener('click', () => {
            window.location.href = `marketplace.html?brand=${encodeURIComponent(brand.name)}`;
        });
    });
}

function initializeSearch() {
    const searchInput = document.querySelector('.search-bar input');
    const searchButton = document.querySelector('.search-bar button');
    
    if (searchInput && searchButton) {
        searchButton.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
}

function performSearch() {
    const searchInput = document.querySelector('.search-bar input');
    const query = searchInput.value.trim();
    
    if (query) {
        // Redirect to marketplace with search query
        window.location.href = `marketplace.html?search=${encodeURIComponent(query)}`;
    }
}

function scheduleTestDrive(carId) {
    const car = featuredCars.find(c => c.id === carId);
    if (car) {
        showMessage(`Test drive scheduled for ${car.brand} ${car.model}! We'll contact you soon.`, 'success');
    }
}

function initializeChatbot() {
    const chatbotToggle = document.getElementById('chatbotToggle');
    const chatbotContainer = document.getElementById('chatbotContainer');
    const closeChatbot = document.getElementById('closeChatbot');
    
    if (chatbotToggle) {
        chatbotToggle.addEventListener('click', function() {
            chatbotContainer.style.display = 'flex';
            chatbotToggle.style.display = 'none';
        });
    }
    
    if (closeChatbot) {
        closeChatbot.addEventListener('click', function() {
            chatbotContainer.style.display = 'none';
            chatbotToggle.style.display = 'flex';
        });
    }
}

function getCarById(id) {
    return featuredCars.find(car => car.id === parseInt(id));
}

function showMessage(text, type = 'success') {
    const message = document.createElement('div');
    message.className = `message message-${type}`;
    message.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        transform: translateX(400px);
        transition: transform 0.3s ease;
    `;
    
    message.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span style="margin-left: 0.5rem;">${text}</span>
    `;
    
    document.body.appendChild(message);
    
    // Animate in
    setTimeout(() => {
        message.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        message.style.transform = 'translateX(400px)';
        setTimeout(() => message.remove(), 300);
    }, 4000);
}

// Smooth scrolling for anchor links
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});