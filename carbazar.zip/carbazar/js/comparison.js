// Simple Car Comparison JavaScript

const comparisonCars = [
    {
        id: 1,
        name: "Mercedes-Benz S-Class 2023",
        brand: "Mercedes-Benz",
        image: "images/cars/mercedes-s-class.jpg.avif",
        price: "₹75,00,000",
        specs: {
            engine: "3.0L V6 Turbo",
            power: "429 HP",
            torque: "384 lb-ft",
            fuelType: "Petrol",
            mileage: "23 MPG",
            topSpeed: "155 mph",
            acceleration: "4.4 sec",
            safety: "5 Stars",
            warranty: "4 Years",
            seating: "5 Seats",
            cargo: "16.3 cu ft"
        }
    },
    {
        id: 2,
        name: "BMW 7 Series 2023",
        brand: "BMW",
        image: "images/cars/bmw-7-series.jpg.avif",
        price: "₹71,00,000",
        specs: {
            engine: "3.0L I6 Turbo",
            power: "375 HP",
            torque: "383 lb-ft",
            fuelType: "Petrol",
            mileage: "25 MPG",
            topSpeed: "155 mph",
            acceleration: "5.3 sec",
            safety: "5 Stars",
            warranty: "4 Years",
            seating: "5 Seats",
            cargo: "18.2 cu ft"
        }
    },
    {
        id: 3,
        name: "Audi A8 L 2023",
        brand: "Audi",
        image: "images/cars/audi-a8.jpg.avif",
        price: "₹69,00,000",
        specs: {
            engine: "3.0L V6 Turbo",
            power: "335 HP",
            torque: "369 lb-ft",
            fuelType: "Petrol",
            mileage: "24 MPG",
            topSpeed: "155 mph",
            acceleration: "5.6 sec",
            safety: "5 Stars",
            warranty: "4 Years",
            seating: "5 Seats",
            cargo: "17.0 cu ft"
        }
    },
    {
        id: 4,
        name: "Tesla Model S 2023",
        brand: "Tesla",
        image: "images/cars/tesla-model-s.jpg.avif",
        price: "₹74,50,000",
        specs: {
            engine: "Dual Motor Electric",
            power: "670 HP",
            torque: "713 lb-ft",
            fuelType: "Electric",
            mileage: "120 MPGe",
            topSpeed: "200 mph",
            acceleration: "3.1 sec",
            safety: "5 Stars",
            warranty: "8 Years",
            seating: "5 Seats",
            cargo: "28.0 cu ft"
        }
    },
    {
        id: 5,
        name: "Porsche Panamera 2023",
        brand: "Porsche",
        image: "images/cars/porsche-panamera.jpg.avif",
        price: "₹81,00,000",
        specs: {
            engine: "2.9L V6 Turbo",
            power: "440 HP",
            torque: "405 lb-ft",
            fuelType: "Petrol",
            mileage: "22 MPG",
            topSpeed: "168 mph",
            acceleration: "4.2 sec",
            safety: "5 Stars",
            warranty: "4 Years",
            seating: "4 Seats",
            cargo: "17.6 cu ft"
        }
    },
    {
        id: 6,
        name: "Lexus LS 500 2023",
        brand: "Lexus",
        image: "images/cars/lexus-ls.jpg.avif",
        price: "₹62,00,000",
        specs: {
            engine: "3.5L V6 Hybrid",
            power: "354 HP",
            torque: "348 lb-ft",
            fuelType: "Hybrid",
            mileage: "32 MPG",
            topSpeed: "155 mph",
            acceleration: "5.4 sec",
            safety: "5 Stars",
            warranty: "6 Years",
            seating: "5 Seats",
            cargo: "17.0 cu ft"
        }
    }
];

// Simple comparison functionality
function initComparison() {
    console.log('Comparison initialized with', comparisonCars.length, 'cars');
}

// Initialize when DOM loads
document.addEventListener('DOMContentLoaded', initComparison);