// Load cars from MongoDB and display in marketplace
async function loadMarketplaceCars() {
    const carsGrid = document.getElementById('marketplaceCarsGrid');
    
    try {
        const response = await fetch('http://localhost:3001/api/cars');
        const data = await response.json();
        
        if (data.success && data.cars.length > 0) {
            displayMarketplaceCars(data.cars);
            document.getElementById('resultsCount').textContent = `${data.cars.length} cars found`;
        } else {
            carsGrid.innerHTML = '<div style="text-align: center; padding: 3rem; color: #666;"><i class="fas fa-car" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.3;"></i><h3>No cars available</h3><p><a href="sell-car.html">Be the first to list your car!</a></p></div>';
        }
    } catch (error) {
        carsGrid.innerHTML = '<div style="text-align: center; padding: 3rem; color: #e74c3c;"><i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 1rem;"></i><h3>Error loading cars</h3><p>Please check if the server is running</p></div>';
    }
}

function displayMarketplaceCars(cars) {
    const carsGrid = document.getElementById('marketplaceCarsGrid');
    carsGrid.innerHTML = '';
    
    cars.forEach(car => {
        const carCard = document.createElement('div');
        carCard.className = 'car-card';
        carCard.innerHTML = `
            <div class="car-image">
                <img src="${car.primaryImage ? 'http://localhost:3001' + car.primaryImage : 'images/cars/default-car.jpg.avif'}" 
                     alt="${car.brand} ${car.model}" 
                     onerror="this.src='images/cars/default-car.jpg.avif'">
                <div class="car-badge">${car.year}</div>
                <div class="car-actions">
                    <button class="action-btn" onclick="addToCompare('${car._id}')" title="Compare">
                        <i class="fas fa-balance-scale"></i>
                    </button>
                    <button class="action-btn" onclick="addToWishlist('${car._id}')" title="Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
            <div class="car-info">
                <div class="car-header">
                    <h3 class="car-title">${car.brand} ${car.model}</h3>
                    <div class="car-price">₹${parseInt(car.expectedPrice).toLocaleString()}</div>
                </div>
                <div class="car-details">
                    <div class="detail-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>${car.year}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>${car.mileage.toLocaleString()} km</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-gas-pump"></i>
                        <span>${car.fuelType}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-cogs"></i>
                        <span>${car.transmission}</span>
                    </div>
                </div>
                <div class="car-location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${car.sellerCity}</span>
                </div>
                <div class="car-footer">
                    <button class="btn-primary" onclick="viewCarDetails('${car._id}')">
                        <i class="fas fa-eye"></i> View Details
                    </button>
                    <button class="btn-secondary" onclick="contactSeller('${car._id}')">
                        <i class="fas fa-phone"></i> Contact
                    </button>
                </div>
            </div>
        `;
        carsGrid.appendChild(carCard);
    });
}

function viewCarDetails(carId) {
    window.location.href = `car-details.html?id=${carId}`;
}

function contactSeller(carId) {
    // Show contact modal or redirect to contact page
    alert('Contact seller functionality - would show seller contact details');
}

function addToCompare(carId) {
    alert('Added to comparison - comparison feature would be implemented here');
}

function addToWishlist(carId) {
    alert('Added to wishlist - wishlist feature would be implemented here');
}

// Load cars when page loads
document.addEventListener('DOMContentLoaded', loadMarketplaceCars);