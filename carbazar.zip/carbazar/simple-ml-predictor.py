from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)

# Load and prepare data
df = pd.read_csv('cars.csv')

# Create price mapping based on brand
brand_prices = {
    'Toyota': 25000, 'Honda': 24000, 'Ford': 22000, 'Chevrolet': 21000,
    'BMW': 45000, 'Mercedes-Benz': 50000, 'Audi': 42000, 'Lexus': 40000,
    'Porsche': 80000, 'Lamborghini': 200000, 'Bentley': 180000,
    'Cadillac': 35000, 'Jaguar': 55000, 'Nissan': 23000, 'Mazda': 22000,
    'Hyundai': 20000, 'Kia': 19000, 'Volkswagen': 26000, 'Volvo': 35000,
    'Mitsubishi': 21000, 'Dodge': 24000, 'Jeep': 28000, 'GMC': 30000,
    'Buick': 32000, 'Pontiac': 20000, 'Oldsmobile': 18000, 'Saturn': 17000,
    'Suzuki': 16000, 'Isuzu': 22000, 'Acura': 35000, 'Lincoln': 40000,
    'Mercury': 20000, 'Hummer': 45000, 'Maybach': 300000, 'MINI': 28000,
    'Scion': 18000, 'Land Rover': 50000, 'Infiniti': 38000
}

# Add prices to dataframe
df['Price'] = df.apply(lambda row: 
    brand_prices.get(row['Car Brand'], 20000) - 
    (2024 - row['Year of Manufacture']) * 800 + 
    np.random.randint(-3000, 5000), axis=1)

df['Price'] = df['Price'].clip(lower=5000)
df['Car_Age'] = 2024 - df['Year of Manufacture']

print(f"Dataset loaded: {len(df)} cars")

@app.route('/predict-price', methods=['POST'])
def predict_price():
    try:
        data = request.json
        brand = data.get('brand')
        color = data.get('color')
        year = int(data.get('year'))
        country = data.get('country')
        
        # Simple prediction logic
        base_price = brand_prices.get(brand, 20000)
        age = 2024 - year
        
        # Calculate price
        predicted_price = base_price - (age * 800)
        
        # Color adjustment
        color_bonus = {'Red': 1000, 'Blue': 500, 'Black': 1500, 'White': 800}.get(color, 0)
        predicted_price += color_bonus
        
        # Ensure minimum price
        predicted_price = max(5000, predicted_price)
        
        return jsonify({
            'predicted_price': int(predicted_price),
            'confidence': 85,
            'algorithm': 'Statistical Model'
        })
    except Exception as e:
        return jsonify({'error': str(e), 'predicted_price': 25000})

@app.route('/market-analysis', methods=['GET'])
def market_analysis():
    try:
        # Brand analysis
        brand_stats = df.groupby('Car Brand').agg({
            'Price': ['mean', 'count'],
            'Car_Age': 'mean'
        }).round(0)
        
        brand_stats.columns = ['avg_price', 'count', 'avg_age']
        top_brands = brand_stats.sort_values('avg_price', ascending=False).head(10)
        
        brand_analysis = []
        for brand, row in top_brands.iterrows():
            brand_analysis.append({
                'brand': brand,
                'avg_price': int(row['avg_price']),
                'count': int(row['count']),
                'avg_age': int(row['avg_age'])
            })
        
        # Age analysis
        age_groups = pd.cut(df['Car_Age'], bins=[0, 5, 10, 15, 50], labels=['0-5 years', '6-10 years', '11-15 years', '15+ years'])
        age_analysis = []
        for age_group in age_groups.cat.categories:
            group_data = df[age_groups == age_group]
            if len(group_data) > 0:
                age_analysis.append({
                    'age_group': age_group,
                    'avg_price': int(group_data['Price'].mean()),
                    'count': len(group_data)
                })
        
        return jsonify({
            'brand_analysis': brand_analysis,
            'age_analysis': age_analysis,
            'total_cars': len(df),
            'total_brands': df['Car Brand'].nunique()
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/clustering', methods=['GET'])
def clustering():
    try:
        # Simple clustering based on price ranges
        df['Price_Segment'] = pd.cut(df['Price'], 
                                   bins=[0, 15000, 30000, 50000, 100000, float('inf')],
                                   labels=['Budget', 'Economy', 'Mid-Range', 'Premium', 'Luxury'])
        
        cluster_analysis = []
        segment_names = ['Budget Cars', 'Economy Cars', 'Mid-Range Cars', 'Premium Cars', 'Luxury Cars']
        
        for i, segment in enumerate(['Budget', 'Economy', 'Mid-Range', 'Premium', 'Luxury']):
            cluster_data = df[df['Price_Segment'] == segment]
            if len(cluster_data) > 0:
                top_brand = cluster_data['Car Brand'].value_counts().head(1)
                cluster_analysis.append({
                    'cluster_id': i,
                    'name': segment_names[i],
                    'size': len(cluster_data),
                    'percentage': round(len(cluster_data) / len(df) * 100, 1),
                    'top_brand': top_brand.index[0] if len(top_brand) > 0 else 'Unknown',
                    'avg_price': int(cluster_data['Price'].mean()),
                    'avg_age': round(cluster_data['Car_Age'].mean(), 1)
                })
        
        return jsonify({
            'clusters': cluster_analysis,
            'algorithm': 'Price-Based Segmentation',
            'total_clusters': 5
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'running',
        'cars_loaded': len(df),
        'message': 'Simple ML predictor ready'
    })

if __name__ == '__main__':
    print("Simple ML Predictor Starting...")
    print("No sklearn required - using statistical methods")
    app.run(host='0.0.0.0', port=5001, debug=True)