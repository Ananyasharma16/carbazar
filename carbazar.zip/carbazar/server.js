const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// MongoDB connection
const MONGO_URI = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';

let db;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Connect to MongoDB (optional)
MongoClient.connect(MONGO_URI)
  .then(client => {
    console.log('✅ Connected to MongoDB');
    db = client.db(DB_NAME);
    initializeData();
  })
  .catch(error => {
    console.log('⚠️ MongoDB not available, using hardcoded authentication');
    db = null;
  });

// Initialize sample data
async function initializeData() {
  try {
    const users = db.collection('users');
    const existingUser = await users.findOne({ email: 'ananya.sharma@email.com' });
    
    if (!existingUser) {
      await users.insertOne({
        name: 'Ananya Sharma',
        email: 'ananya.sharma@email.com',
        password: 'password',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
        createdAt: new Date(),
        lastLogin: null
      });
      console.log('✅ Sample user created');
    }
    
    // Initialize cars collection
    const cars = db.collection('cars');
    const carCount = await cars.countDocuments();
    
    if (carCount === 0) {
      await cars.insertMany([
        {
          brand: 'Mercedes-Benz',
          model: 'S-Class',
          year: 2023,
          price: 95000,
          mileage: 15000,
          fuelType: 'Petrol',
          transmission: 'Automatic',
          description: 'Luxury sedan with premium features',
          imageUrl: 'images/cars/mercedes-s-class.jpg',
          status: 'available',
          createdAt: new Date()
        },
        {
          brand: 'BMW',
          model: '7 Series',
          year: 2022,
          price: 87000,
          mileage: 22000,
          fuelType: 'Petrol',
          transmission: 'Automatic',
          description: 'Executive luxury car',
          imageUrl: 'images/cars/bmw-7-series.jpg',
          status: 'available',
          createdAt: new Date()
        },
        {
          brand: 'Tesla',
          model: 'Model S',
          year: 2023,
          price: 95000,
          mileage: 12000,
          fuelType: 'Electric',
          transmission: 'Automatic',
          description: 'Electric luxury sedan',
          imageUrl: 'images/cars/tesla-model-s.jpg',
          status: 'available',
          createdAt: new Date()
        }
      ]);
      console.log('✅ Sample cars created');
    }
    

  } catch (error) {
    console.error('❌ Error initializing data:', error);
  }
}

// Routes

// Login API
app.post('/api/login', async (req, res) => {
  try {
    console.log('Login attempt:', req.body);
    const { email, password } = req.body;
    
    if (!email || !password) {
      console.log('Missing email or password');
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }
    
    // Simple hardcoded authentication for testing
    if (email === 'ananya.sharma@email.com' && password === 'password') {
      console.log('✅ Login successful with hardcoded credentials');
      
      res.json({
        success: true,
        message: 'Login successful',
        user: {
          id: '1',
          name: 'Ananya Sharma',
          email: 'ananya.sharma@email.com',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
          lastLogin: 'Just now'
        }
      });
      return;
    }
    
    // If MongoDB is available, try database authentication
    if (db) {
      const users = db.collection('users');
      const user = await users.findOne({ email });
      console.log('User found in DB:', user ? 'Yes' : 'No');
      
      if (user && user.password === password) {
        console.log('✅ Login successful with database credentials');
        
        await users.updateOne(
          { _id: user._id },
          { $set: { lastLogin: new Date() } }
        );
        
        res.json({
          success: true,
          message: 'Login successful',
          user: {
            id: user._id,
            name: user.name,
            email: user.email,
            avatar: user.avatar,
            lastLogin: 'Just now'
          }
        });
        return;
      }
    }
    
    console.log('❌ Invalid credentials');
    res.status(401).json({ success: false, message: 'Invalid email or password' });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get all cars
app.get('/api/cars', async (req, res) => {
  try {
    const cars = db.collection('cars');
    const allCars = await cars.find({}).toArray();
    
    res.json({
      success: true,
      cars: allCars.map(car => ({
        ...car,
        id: car._id
      }))
    });
  } catch (error) {
    console.error('Get cars error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Add new car
app.post('/api/cars', async (req, res) => {
  try {
    const { brand, model, year, price, mileage, fuelType, transmission, description } = req.body;
    
    if (!brand || !model || !year || !price) {
      return res.status(400).json({ success: false, message: 'Required fields missing' });
    }
    
    const cars = db.collection('cars');
    const result = await cars.insertOne({
      brand,
      model,
      year: parseInt(year),
      price: parseFloat(price),
      mileage: parseInt(mileage) || 0,
      fuelType: fuelType || 'Petrol',
      transmission: transmission || 'Manual',
      description: description || '',
      status: 'available',
      createdAt: new Date()
    });
    
    res.status(201).json({
      success: true,
      message: 'Car added successfully',
      carId: result.insertedId
    });
    
  } catch (error) {
    console.error('Add car error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});



// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({
    success: true,
    message: 'Node.js MongoDB server is running!',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 CarBazar server running on http://localhost:${PORT}`);
  console.log(`📊 Test API: http://localhost:${PORT}/api/test`);
  console.log(`🔐 Login API: http://localhost:${PORT}/api/login`);
  console.log(`🚗 Cars API: http://localhost:${PORT}/api/cars`);

});