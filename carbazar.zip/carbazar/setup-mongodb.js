const { MongoClient } = require('mongodb');

const MONGO_URI = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';

async function setupMongoDB() {
    try {
        const client = new MongoClient(MONGO_URI);
        await client.connect();
        console.log('✅ Connected to MongoDB');
        
        const db = client.db(DB_NAME);
        
        // Create collections
        await db.createCollection('users');
        await db.createCollection('auction_bids');
        await db.createCollection('cars');
        
        // Insert sample user
        await db.collection('users').insertOne({
            name: 'Ananya Sharma',
            email: 'ananya.sharma@email.com',
            password: 'password',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
            createdAt: new Date()
        });
        
        // Insert sample cars for auction
        await db.collection('cars').insertMany([
            {
                _id: 'mercedes-s-class',
                brand: 'Mercedes-Benz',
                model: 'S-Class',
                year: 2023,
                startingBid: 85000,
                currentBid: 87500,
                auctionEnd: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
                status: 'active'
            },
            {
                _id: 'bmw-7-series',
                brand: 'BMW',
                model: '7 Series',
                year: 2023,
                startingBid: 75000,
                currentBid: 75000,
                auctionEnd: new Date(Date.now() + 4 * 60 * 60 * 1000), // 4 hours from now
                status: 'upcoming'
            }
        ]);
        
        console.log('✅ MongoDB setup complete');
        await client.close();
        
    } catch (error) {
        console.error('❌ MongoDB setup failed:', error);
    }
}

setupMongoDB();