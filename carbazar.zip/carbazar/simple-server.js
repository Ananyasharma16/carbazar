const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Sample cars data
const cars = [
  {
    id: '1',
    brand: 'Mercedes-Benz',
    model: 'S-Class',
    year: 2023,
    price: 95000,
    mileage: 15000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    description: 'Luxury sedan with premium features',
    imageUrl: 'images/cars/mercedes-s-class.jpg',
    status: 'available'
  },
  {
    id: '2',
    brand: 'BMW',
    model: '7 Series',
    year: 2022,
    price: 87000,
    mileage: 22000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    description: 'Executive luxury car',
    imageUrl: 'images/cars/bmw-7-series.jpg',
    status: 'available'
  },
  {
    id: '3',
    brand: 'Tesla',
    model: 'Model S',
    year: 2023,
    price: 95000,
    mileage: 12000,
    fuelType: 'Electric',
    transmission: 'Automatic',
    description: 'Electric luxury sedan',
    imageUrl: 'images/cars/tesla-model-s.jpg',
    status: 'available'
  }
];

// Login API
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  if (email === 'ananya.sharma@email.com' && password === 'password') {
    res.json({
      success: true,
      message: 'Login successful',
      user: {
        id: '1',
        name: 'Ananya Sharma',
        email: 'ananya.sharma@email.com',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
        lastLogin: 'Just now'
      }
    });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

// Get all cars
app.get('/api/cars', (req, res) => {
  res.json({
    success: true,
    cars: cars
  });
});

// Add new car
app.post('/api/cars', (req, res) => {
  const { brand, model, year, price, mileage, fuelType, transmission, description } = req.body;
  
  const newCar = {
    id: (cars.length + 1).toString(),
    brand,
    model,
    year: parseInt(year),
    price: parseFloat(price),
    mileage: parseInt(mileage) || 0,
    fuelType: fuelType || 'Petrol',
    transmission: transmission || 'Manual',
    description: description || '',
    status: 'available'
  };
  
  cars.push(newCar);
  
  res.status(201).json({
    success: true,
    message: 'Car added successfully',
    car: newCar
  });
});

// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({
    success: true,
    message: 'CarBazar server is running!',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 CarBazar server running on http://localhost:${PORT}`);
  console.log(`📊 Test API: http://localhost:${PORT}/api/test`);
  console.log(`🔐 Login API: http://localhost:${PORT}/api/login`);
  console.log(`🚗 Cars API: http://localhost:${PORT}/api/cars`);
});