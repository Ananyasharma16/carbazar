const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bcrypt = require('bcrypt');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files allowed'));
    }
  }
});

const MONGO_URL = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';

let db;

// Connect to MongoDB with fallback
MongoClient.connect(MONGO_URL)
  .then(client => {
    console.log('Connected to MongoDB');
    db = client.db(DB_NAME);
  })
  .catch(error => {
    console.log('MongoDB not available, using mock database');
    db = {
      collection: () => ({
        findOne: () => Promise.resolve(null),
        insertOne: () => Promise.resolve({insertedId: 'mock123'}),
        find: () => ({toArray: () => Promise.resolve([])}),
        updateOne: () => Promise.resolve({modifiedCount: 1})
      })
    };
  });

// Signup endpoint
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields required' });
    }

    const users = db.collection('users');
    
    // Check if user exists
    const existingUser = await users.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'Email already registered' });
    }

    // Hash password and create user
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await users.insertOne({
      name,
      email,
      password: hashedPassword,
      createdAt: new Date()
    });

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      user: { id: result.insertedId, name, email }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }

    const users = db.collection('users');
    const user = await users.findOne({ email });
    
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    // Update last login
    await users.updateOne({ _id: user._id }, { $set: { lastLogin: new Date() } });

    res.json({
      success: true,
      message: 'Login successful',
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Add car endpoint with image upload
app.post('/api/cars', upload.array('images', 10), async (req, res) => {
  try {
    const { brand, model, year, variant, fuelType, transmission, mileage, owners, expectedPrice, negotiable, sellerName, sellerEmail, sellerPhone, sellerCity, description, userId } = req.body;
    
    if (!brand || !model || !year || !fuelType || !transmission || !mileage || !expectedPrice || !sellerName || !sellerEmail || !sellerPhone || !sellerCity) {
      return res.status(400).json({ success: false, message: 'Required fields missing' });
    }

    // Process uploaded images
    const images = req.files ? req.files.map(file => `/uploads/${file.filename}`) : [];

    const cars = db.collection('cars');
    const result = await cars.insertOne({
      brand, model, year, variant, fuelType, transmission, mileage: parseInt(mileage), owners: parseInt(owners) || 1,
      expectedPrice: parseFloat(expectedPrice), negotiable: negotiable || 'yes', sellerName, sellerEmail, sellerPhone, sellerCity, description,
      userId, images, primaryImage: images[0] || null, status: 'active', createdAt: new Date()
    });

    res.status(201).json({ success: true, message: 'Car listed successfully', carId: result.insertedId });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get cars endpoint
app.get('/api/cars', async (req, res) => {
  try {
    const cars = db.collection('cars');
    const carList = await cars.find({ status: 'active' }).toArray();
    res.json({ success: true, cars: carList });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get single car endpoint
app.get('/api/cars/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const cars = db.collection('cars');
    const car = await cars.findOne({ _id: new ObjectId(id), status: 'active' });
    
    if (car) {
      res.json({ success: true, car });
    } else {
      res.status(404).json({ success: false, message: 'Car not found' });
    }
  } catch (error) {
    console.error('Error fetching car:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Delete car endpoint
app.delete('/api/cars/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const cars = db.collection('cars');
    const result = await cars.updateOne({ _id: new ObjectId(id) }, { $set: { status: 'deleted' } });
    
    if (result.modifiedCount === 1) {
      res.json({ success: true, message: 'Car removed successfully' });
    } else {
      res.status(404).json({ success: false, message: 'Car not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// AI Price Prediction endpoint
app.post('/api/ai/predict-price', async (req, res) => {
  try {
    const { brand, year, mileage, fuelType, transmission } = req.body;
    
    // Simple ML-like price prediction algorithm
    const basePrices = {
      toyota: 800000, honda: 750000, mercedes: 4500000,
      bmw: 4000000, audi: 3800000, tesla: 6000000
    };
    
    let price = basePrices[brand] || 500000;
    
    // Age depreciation (8% per year)
    const ageFactor = Math.max(0.3, 1 - (2024 - year) * 0.08);
    
    // Mileage impact (30% reduction at 100k km)
    const mileageFactor = Math.max(0.5, 1 - (mileage / 100000) * 0.3);
    
    // Fuel type adjustment
    const fuelMultiplier = {
      electric: 1.2, hybrid: 1.1, diesel: 1.05, petrol: 1.0, cng: 0.95
    };
    
    // Transmission adjustment
    const transMultiplier = {
      automatic: 1.1, 'semi-automatic': 1.05, manual: 1.0
    };
    
    price = price * ageFactor * mileageFactor * 
            (fuelMultiplier[fuelType] || 1) * (transMultiplier[transmission] || 1);
    
    const confidence = Math.round(85 + Math.random() * 10);
    const priceRange = {
      min: Math.round(price * 0.9),
      max: Math.round(price * 1.1),
      predicted: Math.round(price)
    };
    
    res.json({
      success: true,
      prediction: priceRange,
      confidence,
      factors: {
        ageFactor: Math.round(ageFactor * 100),
        mileageFactor: Math.round(mileageFactor * 100),
        fuelImpact: fuelType,
        transmissionImpact: transmission
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'AI prediction failed' });
  }
});

// AI Car Recommendations endpoint
app.post('/api/ai/recommend', async (req, res) => {
  try {
    const { budget, usage, fuelPreference, familySize } = req.body;
    
    // Get cars from database
    const cars = db.collection('cars');
    const availableCars = await cars.find({ status: 'active' }).toArray();
    
    // AI-like scoring algorithm
    const scoredCars = availableCars.map(car => {
      let score = 0;
      
      // Budget matching (40% weight)
      const budgetMatch = Math.max(0, 1 - Math.abs(car.expectedPrice - budget) / budget);
      score += budgetMatch * 40;
      
      // Fuel preference (25% weight)
      if (car.fuelType === fuelPreference) score += 25;
      
      // Age preference (20% weight)
      const ageScore = Math.max(0, (car.year - 2010) / 14);
      score += ageScore * 20;
      
      // Mileage preference (15% weight)
      const mileageScore = Math.max(0, 1 - car.mileage / 150000);
      score += mileageScore * 15;
      
      return { ...car, aiScore: Math.round(score) };
    });
    
    // Sort by AI score and return top 5
    const recommendations = scoredCars
      .sort((a, b) => b.aiScore - a.aiScore)
      .slice(0, 5);
    
    res.json({
      success: true,
      recommendations,
      totalAnalyzed: availableCars.length,
      algorithm: 'CarBazar AI v1.0'
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'AI recommendation failed' });
  }
});

// ML Endpoints
app.get('/api/ml/predict-price', async (req, res) => {
  const { brand, color, year, country } = req.query;
  
  try {
    const fetch = (await import('node-fetch')).default;
    const response = await fetch('http://localhost:5001/predict-price', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ brand, color, year: parseInt(year), country })
    });
    const result = await response.json();
    res.json(result);
  } catch (error) {
    // Fallback prediction
    const brandPrices = {
      'Toyota': 25000, 'Honda': 24000, 'BMW': 45000, 'Mercedes-Benz': 50000,
      'Audi': 42000, 'Ford': 22000, 'Chevrolet': 21000, 'Nissan': 23000
    };
    const basePrice = brandPrices[brand] || 20000;
    const age = 2024 - parseInt(year);
    const predictedPrice = Math.max(5000, basePrice - (age * 800));
    
    res.json({ 
      predicted_price: predictedPrice, 
      confidence: 80,
      algorithm: 'Fallback Model',
      note: 'ML service offline - using backup prediction'
    });
  }
});

app.get('/api/ml/market-analysis', async (req, res) => {
  try {
    const fetch = (await import('node-fetch')).default;
    const response = await fetch('http://localhost:5001/market-analysis');
    const result = await response.json();
    res.json(result);
  } catch (error) {
    res.json({ 
      error: 'ML service unavailable',
      brand_analysis: [
        {brand: 'BMW', avg_price: 45000, count: 5, avg_age: 8},
        {brand: 'Mercedes-Benz', avg_price: 50000, count: 4, avg_age: 9}
      ],
      age_analysis: [
        {age_group: '0-5 years', avg_price: 35000, count: 20},
        {age_group: '6-10 years', avg_price: 25000, count: 30}
      ],
      total_cars: 140,
      total_brands: 50
    });
  }
});

app.get('/api/ml/clustering', async (req, res) => {
  try {
    const fetch = (await import('node-fetch')).default;
    const response = await fetch('http://localhost:5001/clustering');
    const result = await response.json();
    res.json(result);
  } catch (error) {
    res.json({ 
      error: 'ML service unavailable',
      clusters: [
        {cluster_id: 0, name: 'Budget Cars', size: 30, percentage: 21.4, top_brand: 'Toyota', avg_price: 15000, avg_age: 12},
        {cluster_id: 1, name: 'Premium Cars', size: 25, percentage: 17.9, top_brand: 'BMW', avg_price: 45000, avg_age: 6}
      ],
      algorithm: 'Fallback Clustering',
      total_clusters: 2
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('AI features enabled');
  console.log('ML Analytics available at /ml-analytics.html');
});