const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// File-based storage
const dataDir = './data';
const bidsFile = path.join(dataDir, 'bids.json');
const carsFile = path.join(dataDir, 'cars.json');

// Create data directory if it doesn't exist
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

// Initialize data files
function initializeData() {
    if (!fs.existsSync(bidsFile)) {
        fs.writeFileSync(bidsFile, JSON.stringify([]));
    }
    
    if (!fs.existsSync(carsFile)) {
        const initialCars = [
            {
                id: 'mercedes-s-class',
                brand: 'Mercedes-Benz',
                model: 'S-Class',
                year: 2023,
                currentBid: 87500,
                startingBid: 85000,
                status: 'active'
            }
        ];
        fs.writeFileSync(carsFile, JSON.stringify(initialCars));
    }
}

// Read data from files
function readBids() {
    return JSON.parse(fs.readFileSync(bidsFile, 'utf8'));
}

function readCars() {
    return JSON.parse(fs.readFileSync(carsFile, 'utf8'));
}

// Write data to files
function writeBids(bids) {
    fs.writeFileSync(bidsFile, JSON.stringify(bids, null, 2));
}

function writeCars(cars) {
    fs.writeFileSync(carsFile, JSON.stringify(cars, null, 2));
}

// Login API
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    
    if (email === 'ananya.sharma@email.com' && password === 'password') {
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: '1',
                name: 'Ananya Sharma',
                email: 'ananya.sharma@email.com'
            }
        });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

// Place auction bid
app.post('/api/auction/bid', (req, res) => {
    try {
        const { carId, bidAmount, bidderName, bidderEmail } = req.body;
        
        if (!carId || !bidAmount || !bidderName || !bidderEmail) {
            return res.status(400).json({ success: false, message: 'Missing required fields' });
        }

        const bids = readBids();
        const cars = readCars();
        
        const newBid = {
            id: Date.now().toString(),
            carId,
            bidAmount: parseFloat(bidAmount),
            bidderName,
            bidderEmail,
            bidTime: new Date().toISOString(),
            status: 'active'
        };
        
        // Add bid to storage
        bids.push(newBid);
        writeBids(bids);
        
        // Update car's current bid
        const carIndex = cars.findIndex(car => car.id === carId);
        if (carIndex !== -1) {
            cars[carIndex].currentBid = parseFloat(bidAmount);
            writeCars(cars);
        }
        
        console.log('✅ Bid stored:', newBid.id);
        
        res.json({
            success: true,
            message: 'Bid placed successfully',
            bidId: newBid.id,
            currentBid: bidAmount
        });
        
    } catch (error) {
        console.error('Bid error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get bids for a car
app.get('/api/auction/bids/:carId', (req, res) => {
    try {
        const { carId } = req.params;
        const bids = readBids();
        const cars = readCars();
        
        const carBids = bids
            .filter(bid => bid.carId === carId)
            .sort((a, b) => b.bidAmount - a.bidAmount);
        
        const car = cars.find(car => car.id === carId);
        
        res.json({
            success: true,
            bids: carBids,
            highestBid: car ? car.currentBid : 0,
            totalBids: carBids.length
        });
        
    } catch (error) {
        console.error('Get bids error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get auction cars
app.get('/api/auction/cars', (req, res) => {
    try {
        const cars = readCars();
        res.json({ success: true, cars });
    } catch (error) {
        console.error('Get cars error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Initialize and start server
initializeData();

app.listen(PORT, () => {
    console.log(`🚀 CarBazar Auction Server running on http://localhost:${PORT}`);
    console.log(`🏁 Auction API: http://localhost:${PORT}/api/auction/bid`);
    console.log(`📊 Bids API: http://localhost:${PORT}/api/auction/bids/:carId`);
    console.log(`💾 Data stored in: ${path.resolve(dataDir)}`);
});