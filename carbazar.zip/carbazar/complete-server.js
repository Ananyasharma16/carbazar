const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = 3000;

// MongoDB connection
const MONGO_URI = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';

let db;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Helper function to calculate time ago
function getTimeAgo(date) {
  const now = new Date();
  const diffInSeconds = Math.floor((now - date) / 1000);
  
  if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  return `${Math.floor(diffInSeconds / 86400)} days ago`;
}

// Connect to MongoDB
async function connectMongoDB() {
  try {
    const client = new MongoClient(MONGO_URI);
    await client.connect();
    console.log('✅ Connected to MongoDB');
    db = client.db(DB_NAME);
    db.client = client; // Store client reference for transactions
    await initializeData();
  } catch (error) {
    console.log('⚠️ MongoDB connection failed:', error.message);
    console.log('Server will run with limited functionality');
    db = null;
  }
}

// Initialize sample data
async function initializeData() {
  if (!db) return;
  
  try {
    // Create indexes for better performance
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('cars').createIndex({ status: 1 });
    await db.collection('auction_bids').createIndex({ carId: 1, bidAmount: -1 });
    
    // Check if sample data exists
    const userCount = await db.collection('users').countDocuments();
    const carCount = await db.collection('cars').countDocuments();
    
    if (userCount === 0) {
      const hashedPassword = await bcrypt.hash('password', 10);
      await db.collection('users').insertOne({
        name: 'Ananya Sharma',
        email: 'ananya.sharma@email.com',
        password: hashedPassword,
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face',
        createdAt: new Date(),
        lastLogin: null
      });
      console.log('✅ Sample user created');
    }
    
    if (carCount === 0) {
      await db.collection('cars').insertMany([
        {
          brand: 'Mercedes-Benz',
          model: 'S-Class',
          year: 2023,
          price: 95000,
          mileage: 15000,
          fuelType: 'Petrol',
          transmission: 'Automatic',
          description: 'Luxury sedan with premium features',
          imageUrl: 'images/cars/mercedes-s-class.jpg',
          status: 'available',
          sellerId: 'system',
          sellerName: 'CarBazar',
          currentHighBid: 0,
          totalBids: 0,
          auctionEndTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
          createdAt: new Date()
        },
        {
          brand: 'BMW',
          model: '7 Series',
          year: 2022,
          price: 87000,
          mileage: 22000,
          fuelType: 'Petrol',
          transmission: 'Automatic',
          description: 'Executive luxury car',
          imageUrl: 'images/cars/bmw-7-series.jpg',
          status: 'available',
          sellerId: 'system',
          sellerName: 'CarBazar',
          currentHighBid: 0,
          totalBids: 0,
          auctionEndTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
          createdAt: new Date()
        },
        {
          brand: 'Tesla',
          model: 'Model S',
          year: 2023,
          price: 95000,
          mileage: 12000,
          fuelType: 'Electric',
          transmission: 'Automatic',
          description: 'Electric luxury sedan',
          imageUrl: 'images/cars/tesla-model-s.jpg',
          status: 'available',
          sellerId: 'system',
          sellerName: 'CarBazar',
          currentHighBid: 0,
          totalBids: 0,
          auctionEndTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
          createdAt: new Date()
        }
      ]);
      console.log('✅ Sample cars created');
    }
  } catch (error) {
    console.error('❌ Error initializing data:', error);
  }
}

// AUTHENTICATION ROUTES

// Signup API
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database not available' });
    }
    
    // Check if user already exists
    const existingUser = await db.collection('users').findOne({ email });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'User already exists with this email' });
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create user
    const result = await db.collection('users').insertOne({
      name,
      email,
      password: hashedPassword,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
      createdAt: new Date(),
      lastLogin: null
    });
    
    console.log('✅ New user registered:', email);
    
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      user: {
        id: result.insertedId,
        name,
        email,
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`
      }
    });
    
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ success: false, message: 'Server error during registration' });
  }
});

// Login API
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required' });
    }
    
    if (!db) {
      // Fallback authentication when MongoDB is not available
      if (email === 'ananya.sharma@email.com' && password === 'password') {
        return res.json({
          success: true,
          message: 'Login successful (demo mode)',
          user: {
            id: 'demo-user',
            name: 'Ananya Sharma',
            email: 'ananya.sharma@email.com',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face'
          }
        });
      }
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    
    // Find user in database
    const user = await db.collection('users').findOne({ email });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
    
    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
    
    // Update last login
    await db.collection('users').updateOne(
      { _id: user._id },
      { $set: { lastLogin: new Date() } }
    );
    
    console.log('✅ User logged in:', email);
    
    res.json({
      success: true,
      message: 'Login successful',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error during login' });
  }
});

// CAR MANAGEMENT ROUTES

// Get all cars
app.get('/api/cars', async (req, res) => {
  try {
    if (!db) {
      return res.json({
        success: true,
        cars: [
          {
            id: 'demo-1',
            brand: 'Mercedes-Benz',
            model: 'S-Class',
            year: 2023,
            price: 95000,
            mileage: 15000,
            fuelType: 'Petrol',
            transmission: 'Automatic',
            description: 'Luxury sedan (demo)',
            imageUrl: 'images/cars/mercedes-s-class.jpg',
            status: 'available'
          }
        ]
      });
    }
    
    const cars = await db.collection('cars').find({ status: 'available' }).toArray();
    
    res.json({
      success: true,
      cars: cars.map(car => ({
        ...car,
        id: car._id
      }))
    });
    
  } catch (error) {
    console.error('Get cars error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Add new car (sell car)
app.post('/api/cars', upload.single('image'), async (req, res) => {
  try {
    const { brand, model, year, price, mileage, fuelType, transmission, description, sellerId, sellerName } = req.body;
    
    if (!brand || !model || !year || !price) {
      return res.status(400).json({ success: false, message: 'Required fields missing' });
    }
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database not available' });
    }
    
    const carData = {
      brand,
      model,
      year: parseInt(year),
      price: parseFloat(price),
      mileage: parseInt(mileage) || 0,
      fuelType: fuelType || 'Petrol',
      transmission: transmission || 'Manual',
      description: description || '',
      imageUrl: req.file ? `uploads/${req.file.filename}` : 'images/cars/default-car.jpg',
      status: 'available',
      sellerId: sellerId || 'anonymous',
      sellerName: sellerName || 'Anonymous Seller',
      currentHighBid: 0,
      totalBids: 0,
      auctionEndTime: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      createdAt: new Date()
    };
    
    const result = await db.collection('cars').insertOne(carData);
    
    console.log('✅ New car added:', `${brand} ${model}`);
    
    res.status(201).json({
      success: true,
      message: 'Car added successfully',
      carId: result.insertedId,
      car: { ...carData, id: result.insertedId }
    });
    
  } catch (error) {
    console.error('Add car error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get car by ID
app.get('/api/cars/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database not available' });
    }
    
    const car = await db.collection('cars').findOne({ _id: new ObjectId(id) });
    
    if (!car) {
      return res.status(404).json({ success: false, message: 'Car not found' });
    }
    
    res.json({
      success: true,
      car: { ...car, id: car._id }
    });
    
  } catch (error) {
    console.error('Get car error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// AUCTION/BIDDING ROUTES

// Place auction bid
app.post('/api/auction/bid', async (req, res) => {
  try {
    const { carId, bidAmount, bidderName, bidderEmail, bidderId, autoBid, maxAutoBid } = req.body;
    
    if (!carId || !bidAmount || !bidderName || !bidderEmail) {
      return res.status(400).json({ success: false, message: 'Required fields missing' });
    }
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database connection required for bidding' });
    }
    
    const bidAmountNum = parseFloat(bidAmount);
    
    // Validate bid amount
    if (bidAmountNum <= 0) {
      return res.status(400).json({ success: false, message: 'Bid amount must be greater than 0' });
    }
    
    // Check if car exists
    const car = await db.collection('cars').findOne({ _id: new ObjectId(carId) });
    if (!car) {
      return res.status(404).json({ success: false, message: 'Car not found' });
    }
    
    // Get current highest bid for this car
    const currentHighestBid = await db.collection('auction_bids')
      .findOne({ carId }, { sort: { bidAmount: -1 } });
    
    const minimumBid = currentHighestBid ? currentHighestBid.bidAmount + 100 : car.price * 0.8; // 80% of car price as starting bid
    
    if (bidAmountNum < minimumBid) {
      return res.status(400).json({ 
        success: false, 
        message: `Bid must be at least $${minimumBid}`,
        minimumBid: minimumBid,
        currentHighBid: currentHighestBid ? currentHighestBid.bidAmount : 0
      });
    }
    
    // Create bid data
    const bidData = {
      carId,
      carBrand: car.brand,
      carModel: car.model,
      carYear: car.year,
      bidAmount: bidAmountNum,
      bidderName,
      bidderEmail,
      bidderId: bidderId || null,
      autoBid: autoBid || false,
      maxAutoBid: maxAutoBid ? parseFloat(maxAutoBid) : null,
      bidTime: new Date(),
      status: 'active',
      isWinning: true // Will be updated after insertion
    };
    
    // Start transaction for atomic operations
    const session = db.client ? db.client.startSession() : null;
    
    try {
      if (session) {
        await session.withTransaction(async () => {
          // Insert new bid
          const result = await db.collection('auction_bids').insertOne(bidData, { session });
          
          // Mark all other bids for this car as not winning
          await db.collection('auction_bids').updateMany(
            { carId, _id: { $ne: result.insertedId } },
            { $set: { isWinning: false } },
            { session }
          );
          
          // Update car with current highest bid
          await db.collection('cars').updateOne(
            { _id: new ObjectId(carId) },
            { 
              $set: { 
                currentHighBid: bidAmountNum,
                lastBidTime: new Date(),
                totalBids: await db.collection('auction_bids').countDocuments({ carId })
              }
            },
            { session }
          );
        });
      } else {
        // Fallback without transaction
        const result = await db.collection('auction_bids').insertOne(bidData);
        
        await db.collection('auction_bids').updateMany(
          { carId, _id: { $ne: result.insertedId } },
          { $set: { isWinning: false } }
        );
        
        await db.collection('cars').updateOne(
          { _id: new ObjectId(carId) },
          { 
            $set: { 
              currentHighBid: bidAmountNum,
              lastBidTime: new Date()
            },
            $inc: { totalBids: 1 }
          }
        );
      }
      
      console.log('✅ New bid placed:', `$${bidAmountNum} for ${car.brand} ${car.model} by ${bidderName}`);
      
      // Get updated bid count
      const totalBids = await db.collection('auction_bids').countDocuments({ carId });
      
      res.status(201).json({
        success: true,
        message: 'Bid placed successfully',
        bid: {
          ...bidData,
          id: bidData._id
        },
        currentHighBid: bidAmountNum,
        totalBids: totalBids,
        car: {
          brand: car.brand,
          model: car.model,
          year: car.year
        }
      });
      
    } finally {
      if (session) {
        await session.endSession();
      }
    }
    
  } catch (error) {
    console.error('Bid placement error:', error);
    res.status(500).json({ success: false, message: 'Server error during bid placement' });
  }
});

// Get auction bids for a car
app.get('/api/auction/bids/:carId', async (req, res) => {
  try {
    const { carId } = req.params;
    const { limit = 50, sort = 'amount' } = req.query;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database connection required' });
    }
    
    // Get car details
    const car = await db.collection('cars').findOne({ _id: new ObjectId(carId) });
    if (!car) {
      return res.status(404).json({ success: false, message: 'Car not found' });
    }
    
    // Determine sort order
    let sortOrder = {};
    if (sort === 'time') {
      sortOrder = { bidTime: -1 };
    } else {
      sortOrder = { bidAmount: -1, bidTime: -1 };
    }
    
    // Get bids for this car
    const carBids = await db.collection('auction_bids')
      .find({ carId })
      .sort(sortOrder)
      .limit(parseInt(limit))
      .toArray();
    
    // Get bid statistics
    const bidStats = await db.collection('auction_bids').aggregate([
      { $match: { carId } },
      {
        $group: {
          _id: null,
          totalBids: { $sum: 1 },
          highestBid: { $max: '$bidAmount' },
          lowestBid: { $min: '$bidAmount' },
          averageBid: { $avg: '$bidAmount' },
          uniqueBidders: { $addToSet: '$bidderEmail' }
        }
      }
    ]).toArray();
    
    const stats = bidStats[0] || {
      totalBids: 0,
      highestBid: 0,
      lowestBid: 0,
      averageBid: 0,
      uniqueBidders: []
    };
    
    // Get winning bid
    const winningBid = await db.collection('auction_bids')
      .findOne({ carId, isWinning: true });
    
    res.json({
      success: true,
      car: {
        id: car._id,
        brand: car.brand,
        model: car.model,
        year: car.year,
        price: car.price
      },
      bids: carBids.map(bid => ({
        ...bid,
        id: bid._id,
        timeAgo: getTimeAgo(bid.bidTime)
      })),
      statistics: {
        totalBids: stats.totalBids,
        highestBid: stats.highestBid,
        lowestBid: stats.lowestBid,
        averageBid: Math.round(stats.averageBid || 0),
        uniqueBidders: stats.uniqueBidders.length
      },
      winningBid: winningBid ? {
        ...winningBid,
        id: winningBid._id
      } : null,
      auctionStatus: 'active' // You can implement auction end time logic here
    });
    
  } catch (error) {
    console.error('Get bids error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get all bids (for admin/monitoring)
app.get('/api/auction/bids', async (req, res) => {
  try {
    const { page = 1, limit = 20, status = 'all', carId } = req.query;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database connection required' });
    }
    
    // Build query filter
    let filter = {};
    if (status !== 'all') {
      filter.status = status;
    }
    if (carId) {
      filter.carId = carId;
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Get bids with pagination
    const allBids = await db.collection('auction_bids')
      .find(filter)
      .sort({ bidTime: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .toArray();
    
    // Get total count for pagination
    const totalBids = await db.collection('auction_bids').countDocuments(filter);
    
    // Get overall statistics
    const overallStats = await db.collection('auction_bids').aggregate([
      { $match: filter },
      {
        $group: {
          _id: null,
          totalBids: { $sum: 1 },
          totalValue: { $sum: '$bidAmount' },
          averageBid: { $avg: '$bidAmount' },
          highestBid: { $max: '$bidAmount' },
          uniqueCars: { $addToSet: '$carId' },
          uniqueBidders: { $addToSet: '$bidderEmail' }
        }
      }
    ]).toArray();
    
    const stats = overallStats[0] || {
      totalBids: 0,
      totalValue: 0,
      averageBid: 0,
      highestBid: 0,
      uniqueCars: [],
      uniqueBidders: []
    };
    
    res.json({
      success: true,
      bids: allBids.map(bid => ({
        ...bid,
        id: bid._id,
        timeAgo: getTimeAgo(bid.bidTime)
      })),
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(totalBids / parseInt(limit)),
        totalBids: totalBids,
        limit: parseInt(limit)
      },
      statistics: {
        totalBids: stats.totalBids,
        totalValue: stats.totalValue,
        averageBid: Math.round(stats.averageBid || 0),
        highestBid: stats.highestBid,
        uniqueCars: stats.uniqueCars.length,
        uniqueBidders: stats.uniqueBidders.length
      }
    });
    
  } catch (error) {
    console.error('Get all bids error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Update bid status (for admin operations)
app.put('/api/auction/bid/:bidId', async (req, res) => {
  try {
    const { bidId } = req.params;
    const { status, adminNotes } = req.body;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database connection required' });
    }
    
    const validStatuses = ['active', 'cancelled', 'accepted', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }
    
    const updateData = {
      status,
      updatedAt: new Date()
    };
    
    if (adminNotes) {
      updateData.adminNotes = adminNotes;
    }
    
    const result = await db.collection('auction_bids').updateOne(
      { _id: new ObjectId(bidId) },
      { $set: updateData }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ success: false, message: 'Bid not found' });
    }
    
    console.log(`✅ Bid ${bidId} status updated to ${status}`);
    
    res.json({
      success: true,
      message: 'Bid status updated successfully'
    });
    
  } catch (error) {
    console.error('Update bid error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Delete bid (admin only)
app.delete('/api/auction/bid/:bidId', async (req, res) => {
  try {
    const { bidId } = req.params;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database connection required' });
    }
    
    const bid = await db.collection('auction_bids').findOne({ _id: new ObjectId(bidId) });
    if (!bid) {
      return res.status(404).json({ success: false, message: 'Bid not found' });
    }
    
    await db.collection('auction_bids').deleteOne({ _id: new ObjectId(bidId) });
    
    // Update car statistics
    const remainingBids = await db.collection('auction_bids')
      .find({ carId: bid.carId })
      .sort({ bidAmount: -1 })
      .toArray();
    
    const newHighestBid = remainingBids.length > 0 ? remainingBids[0].bidAmount : 0;
    
    await db.collection('cars').updateOne(
      { _id: new ObjectId(bid.carId) },
      { 
        $set: { 
          currentHighBid: newHighestBid,
          totalBids: remainingBids.length
        }
      }
    );
    
    console.log(`✅ Bid ${bidId} deleted`);
    
    res.json({
      success: true,
      message: 'Bid deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete bid error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// USER MANAGEMENT ROUTES

// Get user profile
app.get('/api/user/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!db) {
      return res.status(500).json({ success: false, message: 'Database not available' });
    }
    
    const user = await db.collection('users').findOne(
      { _id: new ObjectId(id) },
      { projection: { password: 0 } } // Exclude password
    );
    
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    
    res.json({
      success: true,
      user: { ...user, id: user._id }
    });
    
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get user's cars
app.get('/api/user/:id/cars', async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!db) {
      return res.json({ success: true, cars: [] });
    }
    
    const userCars = await db.collection('cars').find({ sellerId: id }).toArray();
    
    res.json({
      success: true,
      cars: userCars.map(car => ({ ...car, id: car._id }))
    });
    
  } catch (error) {
    console.error('Get user cars error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get user's bid history
app.get('/api/user/:id/bids', async (req, res) => {
  try {
    const { id } = req.params;
    const { status = 'all', limit = 20, page = 1 } = req.query;
    
    if (!db) {
      return res.json({ success: true, bids: [] });
    }
    
    // Build filter
    let filter = {};
    if (id !== 'all') {
      filter = { $or: [{ bidderId: id }, { bidderEmail: id }] };
    }
    if (status !== 'all') {
      filter.status = status;
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    // Get user's bids with car details
    const userBids = await db.collection('auction_bids').aggregate([
      { $match: filter },
      { $sort: { bidTime: -1 } },
      { $skip: skip },
      { $limit: parseInt(limit) },
      {
        $lookup: {
          from: 'cars',
          localField: 'carId',
          foreignField: '_id',
          as: 'carDetails'
        }
      },
      {
        $addFields: {
          car: { $arrayElemAt: ['$carDetails', 0] }
        }
      },
      {
        $project: {
          carDetails: 0
        }
      }
    ]).toArray();
    
    // Get total count
    const totalBids = await db.collection('auction_bids').countDocuments(filter);
    
    res.json({
      success: true,
      bids: userBids.map(bid => ({
        ...bid,
        id: bid._id,
        timeAgo: getTimeAgo(bid.bidTime)
      })),
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(totalBids / parseInt(limit)),
        totalBids: totalBids,
        limit: parseInt(limit)
      }
    });
    
  } catch (error) {
    console.error('Get user bids error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get bidding statistics for a user
app.get('/api/user/:id/bid-stats', async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!db) {
      return res.json({ success: true, stats: {} });
    }
    
    const filter = { $or: [{ bidderId: id }, { bidderEmail: id }] };
    
    const stats = await db.collection('auction_bids').aggregate([
      { $match: filter },
      {
        $group: {
          _id: null,
          totalBids: { $sum: 1 },
          totalAmount: { $sum: '$bidAmount' },
          averageBid: { $avg: '$bidAmount' },
          highestBid: { $max: '$bidAmount' },
          winningBids: {
            $sum: {
              $cond: [{ $eq: ['$isWinning', true] }, 1, 0]
            }
          },
          activeBids: {
            $sum: {
              $cond: [{ $eq: ['$status', 'active'] }, 1, 0]
            }
          }
        }
      }
    ]).toArray();
    
    const userStats = stats[0] || {
      totalBids: 0,
      totalAmount: 0,
      averageBid: 0,
      highestBid: 0,
      winningBids: 0,
      activeBids: 0
    };
    
    res.json({
      success: true,
      stats: {
        ...userStats,
        averageBid: Math.round(userStats.averageBid || 0),
        winRate: userStats.totalBids > 0 ? Math.round((userStats.winningBids / userStats.totalBids) * 100) : 0
      }
    });
    
  } catch (error) {
    console.error('Get user bid stats error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// UTILITY ROUTES

// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({
    success: true,
    message: 'CarBazar Complete Server is running!',
    timestamp: new Date().toISOString(),
    database: db ? 'Connected' : 'Not Available',
    features: [
      'User Registration & Login with bcrypt',
      'Car Selling with Image Upload',
      'Car Browsing & Search',
      'Advanced Auction Bidding System',
      'Bid Management & History',
      'Real-time Bid Statistics',
      'User Profiles & Bid Analytics',
      'MongoDB Integration with Transactions',
      'File Upload Support',
      'Admin Bid Management'
    ]
  });
});

// Health check
app.get('/api/health', async (req, res) => {
  const health = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    database: 'Disconnected',
    collections: {}
  };
  
  if (db) {
    try {
      await db.admin().ping();
      health.database = 'Connected';
      
      health.collections = {
        users: await db.collection('users').countDocuments(),
        cars: await db.collection('cars').countDocuments(),
        bids: await db.collection('auction_bids').countDocuments()
      };
    } catch (error) {
      health.database = 'Error: ' + error.message;
    }
  }
  
  res.json(health);
});

// Start server
connectMongoDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 CarBazar Complete Server running on http://localhost:${PORT}`);
    console.log(`📊 Test API: http://localhost:${PORT}/api/test`);
    console.log(`💚 Health Check: http://localhost:${PORT}/api/health`);
    console.log(`🔐 Authentication: /api/login, /api/signup`);
    console.log(`🚗 Cars: /api/cars (GET/POST)`);
    console.log(`🏁 Auctions: /api/auction/bid, /api/auction/bids/:carId`);
    console.log(`👤 Users: /api/user/:id, /api/user/:id/cars`);
    console.log('');
    console.log('✅ All features enabled:');
    console.log('   - User Registration & Login with bcrypt');
    console.log('   - Car Selling with Image Upload');
    console.log('   - Auction Bidding System');
    console.log('   - MongoDB Integration');
    console.log('   - Complete API Coverage');
  });
});