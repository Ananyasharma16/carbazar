const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');

const app = express();
const PORT = 3000;

// MongoDB connection
const MONGO_URI = 'mongodb://localhost:27017';
const DB_NAME = 'carbazar';
let db;

app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Connect to MongoDB
async function connectMongoDB() {
    try {
        const client = new MongoClient(MONGO_URI);
        await client.connect();
        db = client.db(DB_NAME);
        console.log('✅ Connected to MongoDB');
        return true;
    } catch (error) {
        console.error('❌ MongoDB connection failed:', error);
        return false;
    }
}

// Login API
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    
    if (email === 'ananya.sharma@email.com' && password === 'password') {
        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: '1',
                name: 'Ananya Sharma',
                email: 'ananya.sharma@email.com',
                avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=120&h=120&fit=crop&crop=face'
            }
        });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

// Place auction bid
app.post('/api/auction/bid', async (req, res) => {
    try {
        const { carId, bidAmount, bidderName, bidderEmail } = req.body;
        
        if (!carId || !bidAmount || !bidderName || !bidderEmail) {
            return res.status(400).json({ success: false, message: 'Missing required fields' });
        }

        const bidData = {
            carId,
            bidAmount: parseFloat(bidAmount),
            bidderName,
            bidderEmail,
            bidTime: new Date(),
            status: 'active'
        };

        if (db) {
            // Store in MongoDB
            const result = await db.collection('auction_bids').insertOne(bidData);
            
            // Update car's current bid
            await db.collection('cars').updateOne(
                { _id: carId },
                { $set: { currentBid: parseFloat(bidAmount) } }
            );
            
            console.log('✅ Bid stored in MongoDB:', result.insertedId);
            
            res.json({
                success: true,
                message: 'Bid placed successfully',
                bidId: result.insertedId,
                currentBid: bidAmount
            });
        } else {
            res.status(500).json({ success: false, message: 'Database not available' });
        }
        
    } catch (error) {
        console.error('Bid error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get bids for a car
app.get('/api/auction/bids/:carId', async (req, res) => {
    try {
        const { carId } = req.params;
        
        if (db) {
            const bids = await db.collection('auction_bids')
                .find({ carId })
                .sort({ bidAmount: -1 })
                .toArray();
            
            const car = await db.collection('cars').findOne({ _id: carId });
            
            res.json({
                success: true,
                bids: bids,
                highestBid: car ? car.currentBid : 0,
                totalBids: bids.length
            });
        } else {
            res.json({
                success: true,
                bids: [],
                highestBid: 87500,
                totalBids: 0
            });
        }
        
    } catch (error) {
        console.error('Get bids error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Get auction cars
app.get('/api/auction/cars', async (req, res) => {
    try {
        if (db) {
            const cars = await db.collection('cars').find({}).toArray();
            res.json({ success: true, cars });
        } else {
            res.json({
                success: true,
                cars: [
                    {
                        _id: 'mercedes-s-class',
                        brand: 'Mercedes-Benz',
                        model: 'S-Class',
                        currentBid: 87500,
                        status: 'active'
                    }
                ]
            });
        }
    } catch (error) {
        console.error('Get cars error:', error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

// Start server
app.listen(PORT, async () => {
    console.log(`🚀 CarBazar Auction Server running on http://localhost:${PORT}`);
    await connectMongoDB();
    console.log(`🏁 Auction API: http://localhost:${PORT}/api/auction/bid`);
    console.log(`📊 Bids API: http://localhost:${PORT}/api/auction/bids/:carId`);
});