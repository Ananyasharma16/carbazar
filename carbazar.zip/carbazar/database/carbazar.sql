-- Create database
CREATE DATABASE IF NOT EXISTS carbazar;
USE carbazar;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Cars table
CREATE TABLE cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    variant VARCHAR(50),
    fuel_type ENUM('petrol', 'diesel', 'electric', 'hybrid', 'cng') NOT NULL,
    transmission ENUM('manual', 'automatic', 'semi-automatic') NOT NULL,
    mileage INT NOT NULL,
    owners INT DEFAULT 1,
    expected_price DECIMAL(10,2) NOT NULL,
    negotiable ENUM('yes', 'no') DEFAULT 'yes',
    description TEXT,
    seller_name VARCHAR(100) NOT NULL,
    seller_email VARCHAR(100) NOT NULL,
    seller_phone VARCHAR(20) NOT NULL,
    seller_city VARCHAR(50) NOT NULL,
    status ENUM('pending', 'approved', 'sold') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Car images table
CREATE TABLE car_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_id INT,
    image_path VARCHAR(255) NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO users (full_name, email, phone, password) VALUES 
('John Doe', 'john@example.com', '+1234567890', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Jane Smith', 'jane@example.com', '+0987654321', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

INSERT INTO cars (user_id, brand, model, year, fuel_type, transmission, mileage, expected_price, seller_name, seller_email, seller_phone, seller_city, status) VALUES 
(1, 'Mercedes-Benz', 'S-Class', 2023, 'petrol', 'automatic', 5000, 95000.00, 'John Doe', 'john@example.com', '+1234567890', 'New York', 'approved'),
(2, 'BMW', '7 Series', 2023, 'petrol', 'automatic', 3200, 89500.00, 'Jane Smith', 'jane@example.com', '+0987654321', 'Los Angeles', 'approved');