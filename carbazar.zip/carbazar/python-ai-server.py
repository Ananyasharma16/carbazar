from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import joblib
import os
from datetime import datetime
import cv2
import base64
from io import BytesIO
from PIL import Image

app = Flask(__name__)
CORS(app)

# Initialize ML models
price_model = None
recommendation_model = None
label_encoders = {}

# Sample car data for training
def create_sample_data():
    np.random.seed(42)
    brands = ['Toyota', 'Honda', 'Mercedes', 'BMW', 'Audi', 'Hyundai', 'Maruti', 'Tata']
    fuel_types = ['Petrol', 'Diesel', 'Electric', 'Hybrid']
    transmissions = ['Manual', 'Automatic']
    
    data = []
    for _ in range(1000):
        brand = np.random.choice(brands)
        year = np.random.randint(2010, 2025)
        mileage = np.random.randint(5000, 150000)
        fuel_type = np.random.choice(fuel_types)
        transmission = np.random.choice(transmissions)
        
        # Price calculation with realistic factors
        base_price = {
            'Toyota': 800000, 'Honda': 750000, 'Mercedes': 4500000,
            'BMW': 4000000, 'Audi': 3800000, 'Hyundai': 600000,
            'Maruti': 500000, 'Tata': 700000
        }[brand]
        
        # Age depreciation
        age_factor = max(0.3, 1 - (2024 - year) * 0.08)
        # Mileage factor
        mileage_factor = max(0.5, 1 - (mileage / 100000) * 0.3)
        # Fuel type factor
        fuel_factor = {'Electric': 1.2, 'Hybrid': 1.1, 'Diesel': 1.05, 'Petrol': 1.0}[fuel_type]
        # Transmission factor
        trans_factor = {'Automatic': 1.1, 'Manual': 1.0}[transmission]
        
        price = base_price * age_factor * mileage_factor * fuel_factor * trans_factor
        price += np.random.normal(0, price * 0.1)  # Add noise
        
        data.append({
            'brand': brand, 'year': year, 'mileage': mileage,
            'fuel_type': fuel_type, 'transmission': transmission, 'price': max(100000, price)
        })
    
    return pd.DataFrame(data)

# Train ML models
def train_models():
    global price_model, label_encoders
    
    print("Training ML models...")
    df = create_sample_data()
    
    # Prepare features for price prediction
    features = ['brand', 'year', 'mileage', 'fuel_type', 'transmission']
    X = df[features].copy()
    y = df['price']
    
    # Encode categorical variables
    for col in ['brand', 'fuel_type', 'transmission']:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le
    
    # Train price prediction model
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    price_model = RandomForestRegressor(n_estimators=100, random_state=42)
    price_model.fit(X_train, y_train)
    
    # Calculate accuracy
    y_pred = price_model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    print(f"Price prediction model trained. MAE: ₹{mae:,.0f}")
    
    # Save models
    joblib.dump(price_model, 'price_model.pkl')
    joblib.dump(label_encoders, 'label_encoders.pkl')

# Load or train models
def initialize_models():
    global price_model, label_encoders
    
    if os.path.exists('price_model.pkl') and os.path.exists('label_encoders.pkl'):
        print("Loading existing models...")
        price_model = joblib.load('price_model.pkl')
        label_encoders = joblib.load('label_encoders.pkl')
    else:
        train_models()

@app.route('/api/python/predict-price', methods=['POST'])
def predict_price():
    try:
        data = request.json
        brand = data.get('brand', 'Toyota')
        year = int(data.get('year', 2020))
        mileage = int(data.get('mileage', 50000))
        fuel_type = data.get('fuel_type', 'Petrol')
        transmission = data.get('transmission', 'Manual')
        
        # Prepare input for model
        input_data = pd.DataFrame({
            'brand': [brand],
            'year': [year],
            'mileage': [mileage],
            'fuel_type': [fuel_type],
            'transmission': [transmission]
        })
        
        # Encode categorical variables
        for col in ['brand', 'fuel_type', 'transmission']:
            if col in label_encoders:
                try:
                    input_data[col] = label_encoders[col].transform(input_data[col])
                except ValueError:
                    # Handle unknown categories
                    input_data[col] = 0
        
        # Predict price
        predicted_price = price_model.predict(input_data)[0]
        confidence = min(95, max(75, 90 - abs(year - 2020) * 2))
        
        # Calculate price range
        margin = predicted_price * 0.1
        price_range = {
            'min': max(100000, predicted_price - margin),
            'max': predicted_price + margin,
            'predicted': predicted_price
        }
        
        return jsonify({
            'success': True,
            'prediction': {k: int(v) for k, v in price_range.items()},
            'confidence': int(confidence),
            'algorithm': 'Random Forest Regressor',
            'features_used': ['brand', 'year', 'mileage', 'fuel_type', 'transmission']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/python/market-analysis', methods=['POST'])
def market_analysis():
    try:
        data = request.json
        brand = data.get('brand', 'Toyota')
        
        # Generate market analysis using statistical algorithms
        df = create_sample_data()
        brand_data = df[df['brand'] == brand]
        
        if len(brand_data) == 0:
            return jsonify({'success': False, 'error': 'Brand not found'})
        
        analysis = {
            'average_price': int(brand_data['price'].mean()),
            'median_price': int(brand_data['price'].median()),
            'price_std': int(brand_data['price'].std()),
            'total_listings': len(brand_data),
            'avg_year': int(brand_data['year'].mean()),
            'avg_mileage': int(brand_data['mileage'].mean()),
            'fuel_distribution': brand_data['fuel_type'].value_counts().to_dict(),
            'transmission_distribution': brand_data['transmission'].value_counts().to_dict(),
            'price_trend': 'stable',  # Could implement time series analysis
            'market_position': 'competitive'
        }
        
        return jsonify({
            'success': True,
            'analysis': analysis,
            'algorithm': 'Statistical Analysis',
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/python/car-clustering', methods=['POST'])
def car_clustering():
    try:
        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler
        
        data = request.json
        budget = float(data.get('budget', 1000000))
        
        # Create sample data and perform clustering
        df = create_sample_data()
        
        # Prepare features for clustering
        features = ['year', 'mileage', 'price']
        X = df[features]
        
        # Standardize features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Perform K-means clustering
        kmeans = KMeans(n_clusters=5, random_state=42)
        clusters = kmeans.fit_predict(X_scaled)
        df['cluster'] = clusters
        
        # Find the cluster closest to user's budget
        cluster_centers = scaler.inverse_transform(kmeans.cluster_centers_)
        budget_distances = [abs(center[2] - budget) for center in cluster_centers]
        best_cluster = np.argmin(budget_distances)
        
        # Get cars from the best cluster
        cluster_cars = df[df['cluster'] == best_cluster].head(10)
        
        recommendations = []
        for _, car in cluster_cars.iterrows():
            recommendations.append({
                'brand': car['brand'],
                'year': int(car['year']),
                'mileage': int(car['mileage']),
                'price': int(car['price']),
                'fuel_type': car['fuel_type'],
                'transmission': car['transmission'],
                'cluster_id': int(car['cluster'])
            })
        
        return jsonify({
            'success': True,
            'recommendations': recommendations,
            'algorithm': 'K-Means Clustering',
            'cluster_info': {
                'total_clusters': 5,
                'recommended_cluster': int(best_cluster),
                'cluster_center_price': int(cluster_centers[best_cluster][2])
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/python/depreciation-analysis', methods=['POST'])
def depreciation_analysis():
    try:
        data = request.json
        brand = data.get('brand', 'Toyota')
        purchase_year = int(data.get('purchase_year', 2020))
        
        # Generate depreciation curve using exponential decay
        years = list(range(purchase_year, 2030))
        
        # Different depreciation rates for different brands
        depreciation_rates = {
            'Toyota': 0.08, 'Honda': 0.09, 'Mercedes': 0.12,
            'BMW': 0.13, 'Audi': 0.12, 'Hyundai': 0.11,
            'Maruti': 0.10, 'Tata': 0.11
        }
        
        rate = depreciation_rates.get(brand, 0.10)
        
        # Calculate depreciation curve
        base_price = 1000000  # Normalized base price
        depreciation_curve = []
        
        for year in years:
            age = year - purchase_year
            value = base_price * (1 - rate) ** age
            depreciation_curve.append({
                'year': year,
                'value_percentage': round((value / base_price) * 100, 1),
                'depreciation_percentage': round(((base_price - value) / base_price) * 100, 1)
            })
        
        # Calculate key metrics
        value_after_5_years = base_price * (1 - rate) ** 5
        total_depreciation_5_years = ((base_price - value_after_5_years) / base_price) * 100
        
        return jsonify({
            'success': True,
            'analysis': {
                'brand': brand,
                'annual_depreciation_rate': round(rate * 100, 1),
                'depreciation_curve': depreciation_curve,
                'value_after_5_years': round((value_after_5_years / base_price) * 100, 1),
                'total_depreciation_5_years': round(total_depreciation_5_years, 1),
                'best_selling_year': purchase_year + 3,  # Optimal selling time
                'algorithm': 'Exponential Decay Model'
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/python/image-analysis', methods=['POST'])
def analyze_car_image():
    try:
        data = request.json
        image_data = data.get('image')
        
        if not image_data:
            return jsonify({'success': False, 'error': 'No image provided'})
        
        # Decode base64 image
        image_data = image_data.split(',')[1]  # Remove data:image/jpeg;base64,
        image_bytes = base64.b64decode(image_data)
        image = Image.open(BytesIO(image_bytes))
        
        # Convert to OpenCV format
        opencv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        
        # Simple image analysis (in production, use deep learning models)
        height, width = opencv_image.shape[:2]
        
        # Calculate image quality metrics
        gray = cv2.cvtColor(opencv_image, cv2.COLOR_BGR2GRAY)
        blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
        brightness = np.mean(gray)
        
        # Simulate damage detection using edge detection
        edges = cv2.Canny(gray, 50, 150)
        edge_density = np.sum(edges > 0) / (height * width)
        
        # Determine condition based on metrics
        if blur_score > 500 and brightness > 100 and edge_density < 0.1:
            condition = 'Excellent'
            condition_score = 95
        elif blur_score > 300 and brightness > 80:
            condition = 'Good'
            condition_score = 80
        elif blur_score > 100:
            condition = 'Fair'
            condition_score = 65
        else:
            condition = 'Poor'
            condition_score = 40
        
        # Simulate damage detection
        damages = []
        if edge_density > 0.15:
            damages.append('Surface scratches detected')
        if brightness < 60:
            damages.append('Poor lighting - may hide defects')
        if blur_score < 100:
            damages.append('Image quality too low for accurate analysis')
        
        return jsonify({
            'success': True,
            'analysis': {
                'condition': condition,
                'condition_score': condition_score,
                'damages': damages,
                'metrics': {
                    'blur_score': round(blur_score, 2),
                    'brightness': round(brightness, 2),
                    'edge_density': round(edge_density, 4),
                    'image_size': f"{width}x{height}"
                },
                'price_impact': {
                    'Excellent': '+10%',
                    'Good': '0%',
                    'Fair': '-15%',
                    'Poor': '-30%'
                }[condition],
                'algorithm': 'Computer Vision Analysis'
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'models_loaded': price_model is not None,
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("Initializing Python AI Server...")
    initialize_models()
    print("Starting Flask server on port 5000...")
    app.run(debug=True, port=5000)